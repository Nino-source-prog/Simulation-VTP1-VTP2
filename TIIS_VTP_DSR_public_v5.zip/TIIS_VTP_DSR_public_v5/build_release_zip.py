#!/usr/bin/env python3
"""Freeze a deterministic ZIP and write its external SHA-256 sidecar.

Run only once the inputs have been checked. Re-running after changing any
archived file produces a new ZIP and therefore a new manuscript hash.
"""

import hashlib
import os
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
ZIP = ROOT.parent / f"{ROOT.name}.zip"
FIXED_TIME = (2026, 11, 2, 0, 0, 0)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    paths = sorted(p for p in ROOT.rglob("*") if p.is_file() and
                   p.name != "SHA256SUMS.txt" and
                   "reproduced" not in p.relative_to(ROOT).parts and
                   "__pycache__" not in p.parts and p.suffix != ".pyc")
    manifest = "".join(f"{digest(p)}  {p.relative_to(ROOT).as_posix()}\n"
                       for p in paths)
    (ROOT / "SHA256SUMS.txt").write_text(manifest, encoding="utf-8")
    with ZipFile(ZIP, "w", compression=ZIP_DEFLATED, compresslevel=9) as z:
        for path in paths + [ROOT / "SHA256SUMS.txt"]:
            rel = path.relative_to(ROOT)
            item = ZipInfo(f"{ROOT.name}/{rel.as_posix()}", FIXED_TIME)
            item.compress_type = ZIP_DEFLATED
            item.external_attr = ((0o100755 if os.access(path, os.X_OK)
                                   else 0o100644) << 16)
            z.writestr(item, path.read_bytes(), compress_type=ZIP_DEFLATED,
                       compresslevel=9)
    sha = digest(ZIP)
    sidecar = ZIP.with_suffix(".sha256")
    sidecar.write_text(f"{sha}  {ZIP.name}\n", encoding="utf-8")
    print(f"{len(paths)+1} files; ZIP {ZIP.stat().st_size} bytes; SHA-256 {sha}")
    print(sidecar)


if __name__ == "__main__":
    main()

# Diagnostic ciblé : mobilité-route, 20 m/s, run 8

Extraction analytique de l'archive transmise par l'auteur `tiis-route20-run8.tar(1).gz`.
SHA-256 de l'archive source : `3f11704cfae798fcee7f7a31b7e23d8b9b3db98c8823218ed46dbef004c880c5`. Les traces 0 m/s de cette même
archive ont été exclues. Les CSV `main.csv`, `packet/`, `radio/` et `episodes/`
contiennent uniquement la vitesse 20 m/s, le run 8 et les politiques TRAD,
VTP1 et VTP2. `radio_summary.csv` et `recovery_paths.csv` ont été recalculés
à partir de ces trois runs avec `analysis/analyze-tiis-diagnostics.py` ; leurs
lignes sont identiques aux lignes 20 m/s des deux CSV de l'archive source.

## Validation

- Scénario `mobility-route`, vitesse 20 m/s, phase 7,5 s, graine 12345 ;
  configuration_hash `8a02813d23ab6ded` pour les trois politiques.
- Parité avec `vtp-v4.6.3-run8-route-only.csv` : 3/3. Les 165 champs du CSV
  principal sont identiques à ceux de la référence, sauf `campaign_id`.
  SHA-256 de cette référence locale : `d322a4e0ee952c73d73a77e53404c3633c416b9503a31ebd6cb30e6ce817803a`.
- Les 50 radios par politique conservent chacune 300 s d'état ; la somme
  vaut 15 000 secondes-noeuds. La reconstruction V × I × durée diffère de
  l'énergie de la source de −0,03406 J (TRAD/VTP1) et −0,03445 J (VTP2).
- `recovery_paths.csv` contient 289 chemins VTP2 ayant un premier PHY après
  l'armement ; 9 autres séquences armées sont censurées sans premier PHY
  ultérieur observé. Ce fichier ne mesure pas la livraison au récepteur.

Commande de contrôle, depuis la racine de cet extrait :

```bash
python3 analysis/analyze-tiis-diagnostics.py --diag-dir . \
  --expect-scenario mobility-route --expect-speed 20 --expect-run 8 \
  --expect-policies TRAD,VTP1,VTP2
```

Pour refaire la parité 3/3, ajouter `--reference-csv` suivi du chemin local vers
la référence historique de même nom et de SHA-256 indiqué ci-dessus.

## Interprétation bornée par les mesures

Sur 255 s d'observation de la route DSR, l'indisponibilité du cache totalise
137,7 s (π_p = 0,54) sur cinq intervalles inclus dans la statistique. Les
21 expirations du temporisateur RREQ donnent f_R = 21/255 = 0,082352941 s⁻¹ ;
ce nombre n'est pas celui des intervalles sans route. La sonde graphe était
désactivée (`graph_path_samples=0`) : aucune absence de chemin physique n'est
établie par ce run.

TRAD et VTP1 ont 5 465 soumissions de retransmission mais 65 premiers PHY de
retransmission ; VTP2 a respectivement 404 et 326. Les événements DSR
`enqueue` et `dequeue` documentent seulement les chemins observés, pas les
purges possibles du tampon. Une soumission acceptée ne prouve pas une émission.

Exemple apparié TRAD (seq=410, tentative 1) : soumission et entrée DSR à
51,100000000 s, sortie DSR à 52,115273373 s, premier PHY à 52,117899871 s.
Pour VTP2, seq=2411 est armée à 253,320000000 s ; soumission cadencée à
254,900000000 s sans PHY correspondant ; premier PHY à 268,900050000 s après
plusieurs expirations RTO, soit une latence observée de 15 580,05 ms. L'entrée
DSR de sa première tentative n'a pas de sortie DSR appariée dans ces traces :
ne pas imputer cette traîne à une vidange DSR démontrée.

Il s'agit d'une seule graine sévère. L'archive ne contient pas les empreintes
des fichiers C++ effectivement compilés sur la machine de simulation ni un
commit public immuable : la fixation de la version du code reste à compléter.

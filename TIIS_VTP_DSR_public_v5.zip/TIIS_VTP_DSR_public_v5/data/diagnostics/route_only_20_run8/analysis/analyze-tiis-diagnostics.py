#!/usr/bin/env python3
"""Validate paired radio/packet diagnostics and extract representative paths.

No observation is promoted to a causal DSR explanation without an explicit
send-buffer enqueue/dequeue pair for the same (sequence, attempt) identifier.
"""
import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path

STATES = ("idle", "cca_busy", "tx", "rx", "switching", "sleep", "off")


def rows(path):
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError(f"Fichier vide: {path}")
        result = list(reader)
        if not result or any(None in r for r in result):
            raise ValueError(f"CSV vide/incoherent: {path}")
        return result


def check(close, actual, expected, label, rel=1e-5, absolute=1e-6):
    if not math.isclose(float(actual), float(expected), rel_tol=rel, abs_tol=absolute):
        raise ValueError(f"{label}: {actual} != {expected}")


def file_tag(main):
    return f"{main['scenario']}-{float(main['speed']):.9f}-{int(main['run'])}-{main['policy']}.csv"


def identity(main):
    return (main["scenario"], main["policy"],
            float(main["speed"]), int(main["run"]),
            float(main["outage_phase_s"]))


def verify_reference(main_rows, reference_path):
    if reference_path is None:
        return
    reference = {identity(r): r for r in rows(reference_path)}
    found = 0
    for current in main_rows:
        old = reference.get(identity(current))
        if old is None:
            raise ValueError(f"Aucun run correspondant dans la reference: {identity(current)}")
        if old["configuration_hash"] != current["configuration_hash"]:
            raise ValueError(f"Parametres modifies: {identity(current)}")
        for field in ("generated", "rx_unique", "rto_expirations",
                      "phy_original_attempts", "phy_retrans_attempts"):
            check(True, current[field], old[field], f"Parite {identity(current)}/{field}",
                  rel=0, absolute=0)
        for field in ("network_energy_j", "pdr_pct", "recovery_latency_max_ms"):
            if math.isfinite(float(old[field])) and math.isfinite(float(current[field])):
                check(True, current[field], old[field],
                      f"Parite {identity(current)}/{field}", rel=1e-7, absolute=1e-6)
        found += 1
    print(f"Parite avec les runs historiques: {found}/{len(main_rows)}")


def radio_summary(main, data):
    n = int(main["nodes"])
    if len(data) != n or sorted(int(r["node"]) for r in data) != list(range(n)):
        raise ValueError(f"Nombre de radios incorrect: {identity(main)}")
    measured, reconstructed = 0.0, 0.0
    state_totals = defaultdict(float)
    currents = set()
    voltage = set()
    for row in data:
        for field in ("configuration_hash", "policy", "scenario", "rng_seed"):
            if row[field] != main[field]:
                raise ValueError(f"Metadonnees radio non appariees: {identity(main)}/{field}")
        check(True, row["delivered_payload_bits"],
              int(main["rx_unique"]) * int(main["packet_size_bytes"]) * 8,
              "Denominateur en bits", rel=0, absolute=0)
        duration = sum(float(row[f"{state}_s"]) for state in STATES)
        stop = float(row["window_end_s"]) - float(row["window_start_s"])
        check(True, duration + float(row["unaccounted_s"]), stop,
              "Conservation des durees radio", rel=0, absolute=1e-6)
        if float(row["unaccounted_s"]) > 1e-6 or float(row["overlap_s"]) > 1e-6:
            raise ValueError(f"Traces d'etats incompletes: {identity(main)} / node {row['node']}")
        energy = sum(float(row[f"{state}_s"]) * float(row["voltage_v"]) *
                     (0.0 if state == "off" else float(row[f"i_{state}_a"]))
                     for state in STATES)
        check(True, energy, row["energy_reconstructed_j"], "Bilan I*V*t",
              rel=1e-8, absolute=1e-6)
        measured += float(row["energy_source_j"])
        reconstructed += energy
        for state in STATES:
            state_totals[state] += float(row[f"{state}_s"])
        currents.add(tuple(float(row[f"i_{state}_a"]) for state in STATES if state != "off"))
        voltage.add(float(row["voltage_v"]))
    if len(currents) != 1 or len(voltage) != 1:
        raise ValueError("Courants/tension heterogenes entre radios: verifier le modele")
    check(True, measured, main["network_energy_j"], "Energie reseau vs CSV principal",
          rel=1e-7, absolute=1e-5)
    # A larger discrepancy requires inspecting the PHY/energy-model state semantics.
    # It cannot be silently attributed to radio traffic.
    if abs(reconstructed - measured) > max(0.005, 0.01 * measured):
        raise ValueError(f"Energie non reconstruite {identity(main)}: "
                         f"reconstruit={reconstructed:.6f}, mesure={measured:.6f}")
    denominator = int(main["rx_unique"]) * int(main["packet_size_bytes"]) * 8
    return {"scenario": main["scenario"], "policy": main["policy"],
            "speed": main["speed"], "run": main["run"],
            "rng_seed": main["rng_seed"], "outage_phase_s": main["outage_phase_s"],
            "configuration_hash": main["configuration_hash"],
            "energy_source_j": measured, "energy_reconstructed_j": reconstructed,
            "energy_difference_j": reconstructed-measured,
            "rx_unique": main["rx_unique"], "payload_bytes": main["packet_size_bytes"],
            "delivered_payload_bits": denominator,
            "energy_uj_per_delivered_bit": measured * 1e6 / denominator if denominator else "",
            **{f"{state}_node_seconds": state_totals[state] for state in STATES},
            **{f"i_{state}_a": value for state, value in
               zip((s for s in STATES if s != "off"), next(iter(currents)))},
            "voltage_v": next(iter(voltage))}


def packet_paths(main, events):
    attempts = defaultdict(lambda: defaultdict(list))
    by_seq = defaultdict(list)
    for row in events:
        key = int(row["seq"]), int(row["attempt_id"])
        time_ns = int(row["time_ns"])
        attempts[key][row["event"]].append(time_ns)
        by_seq[key[0]].append(row)
    paths = []
    for key, grouped in attempts.items():
        if "transport_submit" in grouped and len(grouped["transport_submit"]) != 1:
            raise ValueError(f"Soumission non unique: {identity(main)}/{key}")
        if "phy_first" in grouped:
            if len(grouped["phy_first"]) != 1 or "transport_submit" not in grouped:
                raise ValueError(f"PHY sans soumission unique: {identity(main)}/{key}")
            if grouped["transport_submit"][0] > grouped["phy_first"][0]:
                raise ValueError(f"Horodatages inverses transport/PHY: {identity(main)}/{key}")
        if "dsr_enqueue" in grouped and "transport_submit" not in grouped:
            raise ValueError(f"DSR sans soumission: {identity(main)}/{key}")
        for leave in ("dsr_dequeue", "dsr_scheduled_removal"):
            for t in grouped.get(leave, []):
                if not any(enter <= t for enter in grouped.get("dsr_enqueue", [])):
                    raise ValueError(f"DSR retire sans entree: {identity(main)}/{key}")
        for t in grouped.get("phy_first", []):
            if grouped.get("dsr_enqueue") and not any(
                enter <= leave <= t for enter in grouped["dsr_enqueue"]
                for leave in grouped.get("dsr_dequeue", []) +
                             grouped.get("dsr_scheduled_removal", [])):
                raise ValueError(f"PHY sans liberation DSR observee: {identity(main)}/{key}")

    n_phy = sum("phy_first" in group for group in attempts.values())
    expected = int(main["phy_original_attempts"]) + int(main["phy_retrans_attempts"])
    check(True, n_phy, expected, f"Conservation des premieres emissions PHY {identity(main)}",
          rel=0, absolute=0)

    for seq, seq_events in by_seq.items():
        for armed in (r for r in seq_events if r["event"] == "recovery_armed"):
            favorable = int(armed["detail"])
            physical = sorted(
                (r for r in seq_events if r["event"] == "phy_first" and
                 int(r["time_ns"]) >= favorable), key=lambda r: int(r["time_ns"]))
            if not physical:
                continue  # right-censored recovery, never fabricate a PHY delay
            first = physical[0]
            key = seq, int(first["attempt_id"])
            group = attempts[key]
            time_ns = int(first["time_ns"])
            dequeue = sorted(t for label in ("dsr_dequeue", "dsr_scheduled_removal")
                             for t in group.get(label, []) if t <= time_ns)
            enqueue = sorted(t for t in group.get("dsr_enqueue", []) if t <= time_ns)
            paced = sorted(t for t in group.get("paced_release", []) if t <= time_ns)
            intervening_rto = sorted(int(r["time_ns"]) for r in seq_events
                                     if r["event"] == "rto_expired" and
                                     favorable <= int(r["time_ns"]) <= time_ns)
            grace = sorted(int(r["time_ns"]) for r in seq_events
                           if r["event"] == "dsr_grace_elapsed" and
                           favorable <= int(r["time_ns"]) <= time_ns)
            if enqueue and dequeue:
                classification = "dsr_buffer_release"
            elif paced and grace:
                classification = "paced_after_dsr_grace"
            elif paced:
                classification = "paced_release"
            elif intervening_rto:
                classification = "post_recovery_rto"
            else:
                classification = "unresolved_without_dsr_proof"
            paths.append({"scenario": main["scenario"], "policy": main["policy"],
                          "speed": main["speed"], "run": main["run"], "seq": seq,
                          "attempt_id_at_phy": key[1], "favorable_ns": favorable,
                          "first_phy_ns": time_ns,
                          "recovery_latency_ms": (time_ns-favorable)/1e6,
                          "transport_submit_ns": min(group.get("transport_submit", [0])),
                          "dsr_enqueue_ns": min(enqueue) if enqueue else "",
                          "dsr_dequeue_ns": min(dequeue) if dequeue else "",
                          "paced_release_ns": min(paced) if paced else "",
                          "rto_after_recovery_ns": min(intervening_rto) if intervening_rto else "",
                          "grace_elapsed_ns": min(grace) if grace else "",
                          "path": classification})
    return paths


def write(path, results):
    if not results:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--diag-dir", type=Path, required=True)
    parser.add_argument("--reference-csv", type=Path, default=None,
                        help="CSV historique pour verifier la parite des runs")
    parser.add_argument("--expect-scenario", default=None)
    parser.add_argument("--expect-speed", type=float, default=None)
    parser.add_argument("--expect-run", type=int, default=None)
    parser.add_argument("--expect-policies", default=None,
                        help="Liste exacte, par exemple TRAD,VTP1,VTP2")
    args = parser.parse_args()
    main_rows = rows(args.diag_dir / "main.csv")
    if args.expect_scenario is not None and any(
            r["scenario"] != args.expect_scenario for r in main_rows):
        raise ValueError(f"Scenario different de {args.expect_scenario}")
    if args.expect_speed is not None and any(
            not math.isclose(float(r["speed"]), args.expect_speed,
                             rel_tol=0, abs_tol=1e-9) for r in main_rows):
        raise ValueError(f"Vitesse differente de {args.expect_speed} m/s")
    if args.expect_run is not None and any(
            int(r["run"]) != args.expect_run for r in main_rows):
        raise ValueError(f"Run different de {args.expect_run}")
    if args.expect_policies is not None:
        expected_policies = sorted(args.expect_policies.split(","))
        if sorted(r["policy"] for r in main_rows) != expected_policies:
            raise ValueError("Politiques presentes differentes de " +
                             args.expect_policies)
    keys = [identity(r) for r in main_rows]
    if len(keys) != len(set(keys)):
        raise ValueError("Run duplique dans main.csv")
    verify_reference(main_rows, args.reference_csv)
    radio = []
    paths = []
    for row in main_rows:
        radio_file = args.diag_dir / "radio" / file_tag(row)
        packet_file = args.diag_dir / "packet" / file_tag(row)
        radio.append(radio_summary(row, rows(radio_file)))
        paths.extend(packet_paths(row, rows(packet_file)))
    write(args.diag_dir / "radio_summary.csv", radio)
    write(args.diag_dir / "recovery_paths.csv", paths)
    print(f"Diagnostic valide pour {len(main_rows)} runs; {len(paths)} reprises PHY tracees.")
    print("Resultats: radio_summary.csv, recovery_paths.csv")


if __name__ == "__main__":
    main()

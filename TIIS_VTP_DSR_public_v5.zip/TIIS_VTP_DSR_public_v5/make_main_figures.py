#!/usr/bin/env python3
"""Replot the numeric series behind manuscript Figures 2–7.

These are regenerated plots, not claims of pixel-identical manuscript art.
Figure 6 uses the corrected 3 V energy records. Figure 1 has its own script.
"""

import argparse
import csv
import math
import random
import statistics
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import t

ROOT = Path(__file__).resolve().parent
METRICS = {
    2: ("pdr_pct", "PDR (%)"),
    3: ("e2e_delay_ms", "Mean delivered-packet delay (ms)"),
    4: ("jitter_ms", "Mean jitter (ms)"),
    5: ("phy_retrans_attempts", "First PHY retransmission attempts"),
    6: ("energy_uj_per_delivered_bit", "Network energy per delivered payload bit (µJ/bit)"),
    7: ("penalized_delay_ms", "Mean loss-penalized delay (ms)"),
}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--main", type=Path,
                   default=ROOT / "data/energy/tiis-energy-wifi-v1/main.csv")
    p.add_argument("--output-dir", type=Path, default=ROOT / "reproduced/figures")
    p.add_argument("--series", type=Path,
                   default=ROOT / "reproduced/figure2to7_series.csv")
    args = p.parse_args()
    with args.main.open(newline="") as h:
        rows = list(csv.DictReader(h))
    assert len(rows) == 450
    args.output_dir.mkdir(parents=True, exist_ok=True)
    speeds = (0, 5, 10, 15, 20)
    colors = {"TRAD": "#1f77b4", "VTP1": "#db712b", "VTP2": "#27824b"}
    marks = {"TRAD": "o", "VTP1": "s", "VTP2": "^"}
    series = []
    for no, (field, ylabel) in METRICS.items():
        fig, ax = plt.subplots(figsize=(8, 5), dpi=180)
        for policy in ("TRAD", "VTP1", "VTP2"):
            means, intervals = [], []
            for speed in speeds:
                sample = [float(r[field]) for r in rows
                          if r["policy"] == policy and int(float(r["speed"])) == speed]
                assert len(sample) == 30 and all(math.isfinite(x) for x in sample)
                means.append(statistics.mean(sample))
                if no == 2:
                    rng = random.Random(12345 + 100 * speed + tuple(colors).index(policy))
                    sims = sorted(statistics.mean([sample[rng.randrange(30)] for _ in sample])
                                  for _ in range(10000))
                    intervals.append((means[-1] - sims[249], sims[9749] - means[-1]))
                else:
                    w = t.ppf(.975, 29) * statistics.stdev(sample) / math.sqrt(30)
                    intervals.append((w, w))
                series.append({"figure": no, "metric": field, "speed_mps": speed,
                               "policy": policy, "independent_runs": len(sample),
                               "mean": means[-1],
                               "ci95_low": means[-1] - intervals[-1][0],
                               "ci95_high": means[-1] + intervals[-1][1],
                               "ci_method": "percentile bootstrap, 10000"
                                            if no == 2 else "Student t, df=29"})
            ax.errorbar(speeds, means, yerr=([x[0] for x in intervals],
                                             [x[1] for x in intervals]),
                        label=policy, marker=marks[policy], capsize=3,
                        linewidth=1.8, color=colors[policy])
        if no == 2:
            ax.axhline(99, color="0.4", ls=":", linewidth=1,
                       label="Exploratory 99%")
        ax.set(xlabel="Speed (m/s)", ylabel=ylabel, xticks=speeds,
               xlim=(-.6, 20.6))
        ax.grid(alpha=.25, ls="--")
        ax.legend(title="Policy")
        fig.tight_layout()
        out = args.output_dir / f"Figure_{no}.png"
        fig.savefig(out)
        plt.close(fig)
        print(out)
    args.series.parent.mkdir(parents=True, exist_ok=True)
    with args.series.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(series[0]))
        writer.writeheader()
        writer.writerows(series)
    print(args.series)


if __name__ == "__main__":
    main()

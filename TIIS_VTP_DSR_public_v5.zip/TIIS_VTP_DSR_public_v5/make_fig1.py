#!/usr/bin/env python3
"""Regenerate manuscript Figure 1 from the static episode records.

The left panel compares the scheduled paced-cohort maximum with Eq. (1) plus
0.051 ms. The right compares overall first-PHY Lmax with the conditional
calendar replay (Eq. (8)); the replay's source admission rule is documented
in model.py and checked separately against the ARM=0 maintenance trace.
"""

from __future__ import annotations

import argparse
import csv
import math
import statistics
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from model import timed_prediction


ROOT = Path(__file__).resolve().parent
CASES = ("A", "B", "C", "D")
PACES = (5, 10, 20)
COLORS = {"A": "#2676a5", "B": "#dc6f2d", "C": "#3c8b59", "D": "#8f65ad"}


def read(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def series(static_dir: Path) -> list[dict[str, float | int | str]]:
    result = []
    for case in CASES:
        for pace in PACES:
            episodes = read(static_dir / f"episodes-{case}-pac{pace}ms.csv")
            runs = read(static_dir / f"run-{case}-pac{pace}ms.csv")
            assert len(episodes) == 100 and len(runs) == 30, (case, pace)
            by_policy = {p: [r for r in episodes if r["policy"] == p]
                         for p in ("VTP1", "VTP2")}
            assert all(len(v) == 50 for v in by_policy.values())
            assert all(r["episode_valid"] == "1" for r in episodes)
            reference = next(r for r in runs if r["policy"] == "VTP1"
                             and int(r["run"]) == 1)
            model = timed_prediction(reference, d0_ms=0.0)
            D = float(reference["outage_off_duration_s"])
            rate = 1 / float(reference["generation_interval_s"])
            N = round(rate * (D - float(reference["rto_initial_s"])))
            predicted_paced = (N - 1) * pace + 0.051
            predicted_max = float(model["timed_recovery_max_ms"])
            measured = {}
            for policy, rows in by_policy.items():
                assert {int(r["queue_depth_at_release"]) for r in rows} == {N}
                assert all(int(r["episode_recovery_samples"]) == N for r in rows)
                measured[policy] = (
                    statistics.mean(float(r["episode_max_paced_ms"]) for r in rows),
                    statistics.mean(float(r["episode_max_recovery_ms"]) for r in rows),
                )
                assert math.isclose(measured[policy][0], predicted_paced,
                                    abs_tol=1e-6)
                assert math.isclose(measured[policy][1], predicted_max,
                                    abs_tol=1e-6)
            assert measured["VTP1"] == measured["VTP2"]
            result.append({"condition": case, "D_s": D, "rate_pps": rate,
                           "N": N, "T_ms": pace, "episodes_per_policy": 50,
                           "VTP1_VTP2_identical": 1,
                           "observed_paced_max_ms": measured["VTP1"][0],
                           "model_paced_max_ms": predicted_paced,
                           "observed_Lmax_ms": measured["VTP1"][1],
                           "model_Lmax_ms": predicted_max})
    return result


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data", type=Path, default=ROOT / "data/static_episode")
    p.add_argument("--figure", type=Path, default=ROOT / "figures/Figure_1.png")
    p.add_argument("--series", type=Path, default=ROOT / "derived/figure1_series.csv")
    args = p.parse_args()
    rows = series(args.data)
    args.series.parent.mkdir(parents=True, exist_ok=True)
    with args.series.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.3), dpi=180,
                             sharex=True)
    for case in CASES:
        subset = [r for r in rows if r["condition"] == case]
        N = subset[0]["N"]
        rate = subset[0]["rate_pps"]
        label = f"N={N}, {rate:g}/s"
        for ax, observed, predicted in (
            (axes[0], "observed_paced_max_ms", "model_paced_max_ms"),
            (axes[1], "observed_Lmax_ms", "model_Lmax_ms"),
        ):
            x = [r["T_ms"] for r in subset]
            ax.plot(x, [r[predicted] for r in subset],
                    color=COLORS[case], lw=1.8, label=label)
            ax.scatter(x, [r[observed] for r in subset],
                       color=COLORS[case], marker="o", s=28, zorder=3)
    axes[0].set_title("(a) Paced cohort")
    axes[0].set_ylabel("Maximum first-PHY recovery time (ms)")
    axes[1].set_title("(b) All recovered attempts")
    axes[1].set_ylabel(r"Overall $L_{\max}$ (ms)")
    for ax in axes:
        ax.set_xlabel("Pacing interval T (ms)")
        ax.set_xticks(PACES)
        ax.grid(alpha=0.25, ls="--")
    axes[0].legend(fontsize=8, title="Condition", title_fontsize=8)
    fig.tight_layout()
    args.figure.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.figure)
    plt.close(fig)
    print(f"Figure 1: 12 configurations × 50 episodes per policy; {args.figure}")
    print(f"Numeric series: {args.series}")


if __name__ == "__main__":
    main()

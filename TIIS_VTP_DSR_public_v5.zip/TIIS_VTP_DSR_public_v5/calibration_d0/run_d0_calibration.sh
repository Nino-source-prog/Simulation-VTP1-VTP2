#!/usr/bin/env bash
# Base-delay (d0) calibration for Table 4: static network, no receiver refusal gate.
# Run from the root of an ns-3.35 tree in which the v5.0.4 sources are installed:
#   src/dsr/model/dsr-routing.{cc,h}  <- source/main_v4.6.3/
#   src/dsr/model/dsr-rcache.{cc,h}   <- PeekRoute from source/main_v4.6.3/dsr-rcache-peek-v4.6.patch
#   scratch/vtp-dsr-comparison.cc     <- source/static_episode/vtp-dsr-comparison.cc
# Same settings as static condition B of the queue-depth campaign (lambda = 10 packets/s,
# D = 10 s, on = 20 s), except --cycles=0: C(t) = 1 for the whole run.
# Default: RNG run 8 (the reference run); set RUN_START=1 RUN_END=10 for the spread over runs.
# Usage: path/to/run_d0_calibration.sh path/to/run-vtp-dsr-experiments.sh [OUT.csv]
set -euo pipefail
LAUNCHER="${1:?path to source/main_v4.6.3/run-vtp-dsr-experiments.sh}"
OUT="${2:-d0-calibration-static-nogate.csv}"
PROFILE=custom SCENARIO_NAME=static-nogate-calibration PHYSICAL_CHANNEL_OUTAGE=0 \
SPEEDS="0" RUNS="${RUN_END:-8}" RUN_START="${RUN_START:-8}" RUN_END="${RUN_END:-8}" \
RECOVERY_PACING=0.005 RNG_SEED=12345 OUTAGE_PHASE_MODE=fixed OUTAGE_PHASE_FIXED=0.0 \
GRAPH_PATH_DIAGNOSTIC=0 CAMPAIGN_ID=d0-calibration-static-nogate OUT="$OUT" \
EXTRA_ARGS="--cycles=0 --offDur=10 --onDur=20 --interval=0.1" \
bash "$LAUNCHER"
echo "Done: $OUT  (next: python3 compute_d0.py $OUT)"

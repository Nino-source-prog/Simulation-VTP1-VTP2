#!/usr/bin/env python3
"""Compute the base delay d0 used in Table 4 from the no-gate static calibration runs.

d0 is the mean end-to-end delay of uniquely delivered DATA packets (column e2e_delay_ms)
in a static run without receiver refusal (C(t) = 1 throughout, --cycles=0). The value used
in the manuscript is that of RNG run 8 (TRAD; VTP1 and VTP2 are checked to be identical,
since all three policies coincide when the gate never closes). The other runs are reported
to show the spread across RNG runs.

Usage: python3 compute_d0.py d0-calibration-static-nogate.csv [d0_summary.csv]
"""
import csv
import statistics
import sys

src = sys.argv[1]
dst = sys.argv[2] if len(sys.argv) > 2 else 'd0_summary.csv'
REFERENCE_RUN = 8
PUBLISHED_D0_MS = 0.681257827

rows = list(csv.DictReader(open(src, newline='')))
assert rows, 'empty file'
for r in rows:
    assert int(float(r['outage_cycles_requested'])) == 0, 'a run has refusal intervals'
    assert float(r['speed']) == 0.0, 'a run is not static'
    assert abs(float(r['generation_interval_s']) - 0.1) < 1e-12, 'generation interval is not 0.1 s'
    assert float(r['pdr_pct']) > 99.9, f"run {r['run']} {r['policy']}: PDR {r['pdr_pct']}"

by = {(r['policy'], int(r['run'])): float(r['e2e_delay_ms']) for r in rows}
runs = sorted({k[1] for k in by})
policies = sorted({k[0] for k in by})
for run in runs:
    values = {by[(p, run)] for p in policies if (p, run) in by}
    assert len(values) == 1, f'policies differ in run {run}: {values}'

d0 = by[('TRAD', REFERENCE_RUN)]
spread = [by[('TRAD', run)] for run in runs]
with open(dst, 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['quantity', 'value_ms'])
    w.writerow([f'd0 (TRAD, run {REFERENCE_RUN})', f'{d0:.9f}'])
    w.writerow(['published d0', f'{PUBLISHED_D0_MS:.9f}'])
    w.writerow(['difference', f'{d0 - PUBLISHED_D0_MS:+.9f}'])
    w.writerow([f'mean over runs {runs[0]}-{runs[-1]}', f'{statistics.mean(spread):.9f}'])
    w.writerow([f'min over runs', f'{min(spread):.9f}'])
    w.writerow([f'max over runs', f'{max(spread):.9f}'])
    for run in runs:
        w.writerow([f'run {run}', f'{by[("TRAD", run)]:.9f}'])
print(open(dst).read())

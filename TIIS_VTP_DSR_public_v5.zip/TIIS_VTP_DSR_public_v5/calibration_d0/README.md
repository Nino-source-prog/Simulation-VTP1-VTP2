# Base-delay calibration d0 (Table 4)

`d0` is the mean end-to-end delay of uniquely delivered DATA packets in a static
network **without receiver refusal** (C(t) = 1 for the whole run). Table 4 adds it
to the timer-schedule model's delays. It does not affect any count or the jitter.

## What was run

- Code: the v5.0.4 sources of this archive, unchanged —
  `source/static_episode/vtp-dsr-comparison.cc` as `scratch/vtp-dsr-comparison.cc`,
  `source/main_v4.6.3/dsr-routing.{cc,h}` in `src/dsr/model/`, and `PeekRoute` from
  `source/main_v4.6.3/dsr-rcache-peek-v4.6.patch` in `src/dsr/model/dsr-rcache.{cc,h}`.
- Settings: those of static condition B of the queue-depth campaign
  (λ = 10 packets/s, 50 nodes, speed 0, seed 12345), with `--cycles=0`
  (no refusal interval) and `--physicalChannelOutage=0`; RNG run 8; TRAD, VTP1, VTP2.
- Command (from the ns-3.35 root):
  `calibration_d0/run_d0_calibration.sh source/main_v4.6.3/run-vtp-dsr-experiments.sh`
  then `python3 calibration_d0/compute_d0.py d0-calibration-static-nogate.csv`.

## Result

`d0_summary.csv`: d0 = **0.681257827 ms** (run 8). TRAD, VTP1 and VTP2 give the
same value, as expected when the gate never closes, and it equals the value used
by `make_tables.py` and `model.py`. Table 4 is therefore unchanged.

## Files

| File | Content |
|---|---|
| `d0-calibration-static-nogate.csv` | Raw scenario output of the three calibration simulations (full configuration in each row, including its configuration hash) |
| `d0_summary.csv` | d0 computed by `compute_d0.py` |
| `run_log.txt` | Console output of the run (local paths removed) |
| `build_check_static_B_pac5ms_run1.csv` | Build check: static condition B, T = 5 ms, run 1 rerun with the same build; every column, including the configuration hash, equals the archived row of `data/static_episode/run-B-pac5ms.csv` |

## Build note

The calibration was rebuilt on 2026-11-17 from ns-3.35 (git tag `ns-3.35`). With
GCC 13 or later, configure ns-3.35 with
`CXXFLAGS="-include cstdint -include cstdlib" ./waf configure --disable-werror ...`
(older ns-3 headers omit these includes). With Python 3.13, run `waf` with an
older Python (for example `python3.11 ./waf ...`), since Python 3.13 removed the
`pipes` module that waf 2.0.21 imports. Neither change alters the simulation.

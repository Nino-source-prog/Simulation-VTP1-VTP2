#!/usr/bin/env python3
"""Recompute the source DSR maintenance analysis for the static ARM=0 rerun."""

from __future__ import annotations

import csv
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "data/diagnostics/static_arm0_run1"
ANALYZER = ROOT / "source/static_arm0_check/diagnostic_source/analyze_maintenance.py"
AUDIT = ROOT / "source/static_arm0_check/audit_static_arm0.py"
OUT = ROOT / "reproduced/static_arm0_run1"


def csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def main() -> None:
    for policy in ("VTP1", "VTP2"):
        stem = f"speed0-run1-{policy}-phase0"
        output = OUT / "analysis" / stem
        output.mkdir(parents=True, exist_ok=True)
        subprocess.run([sys.executable, str(ANALYZER), "--maintain",
                        str(RAW / "maintain" / f"{stem}.csv"), "--packet",
                        str(RAW / "packet" / f"{stem}.csv"), "--out-dir",
                        str(output)], check=True, capture_output=True, text=True)
        fixed = RAW / "analysis" / stem
        for filename in ("summary.json", "missing_first_phy_owners.csv",
                         "rejections.csv", "occupancy.csv"):
            new = output / filename
            old = fixed / filename
            if filename.endswith(".json"):
                assert json.loads(new.read_text()) == json.loads(old.read_text())
            else:
                assert csv_rows(new) == csv_rows(old), (policy, filename)
        assert json.loads((output / "summary.json").read_text())[
            "source_missing_with_owner"] == 50
        owners = csv_rows(output / "missing_first_phy_owners.csv")
        assert len(owners) == 50
        assert all(r["attempt_uid"] != r["owner_uid"] and
                   r["attempt_seq"] != r["owner_seq"] and
                   r["occupied_before_reject_ns"] == "1000" and
                   r["owner_remove_reason"] == "link_ack" and
                   r["missing_first_phy_for_attempt"] == "1"
                   for r in owners)
        assert sum(r["owner_attempt"] == "1" for r in owners) == 25
        assert sum(r["owner_attempt"] == "2" for r in owners) == 25
    result = OUT / "static_arm0_50_check.json"
    subprocess.run([sys.executable, str(AUDIT), "--result-dir", str(RAW),
                    "--output", str(result)], check=True,
                   capture_output=True, text=True)
    fixed_result = json.loads((RAW / "analysis/static_arm0_50_check.json").read_text())
    assert json.loads(result.read_text()) == fixed_result
    assert all(r["missing"] == r["same_attempt_dsr_rejections"] ==
               r["resident_entry_proven"] == 50 for r in fixed_result["results"])
    print("PASS: VTP1 and VTP2, 50/50 missing first-PHY attempts each; "
          "all 50 matched to distinct-packet DSR maintenance rejections")


if __name__ == "__main__":
    main()

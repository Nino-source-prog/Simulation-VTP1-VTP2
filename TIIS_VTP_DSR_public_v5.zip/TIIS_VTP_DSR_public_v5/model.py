#!/usr/bin/env python3
"""Analytic retransmission counts and conditional event-calendar validation.

The ideal model omits timer-scan quantization and source DSR admission. The
conditional replay adds 10-ms timer ticks and a *stated* implementation rule:
a paced submit 1 us after an original or late RTO on the same source tick
does not reach PHY, then its retry is checked 2.01 s later. A separate ARM=0
maintenance trace confirms DSR duplicate admission for all 50 such attempts
in static run 1 (T=5 ms); the rule is not a universal PHY collision law or
directly instrumented in the other 359 static runs.
Neither model predicts route mobility or MAC contention. The independent
no-gate value of d0 is carried over from the earlier analysis; its raw run is
not in this archive, so delay calibration is not fully independently auditable.
"""

from __future__ import annotations

import argparse
import csv
import math
import statistics
from pathlib import Path


def curve_counts(duration_s: float, rate_pps: float = 10.0,
                 cycles: int = 5) -> dict[str, float]:
    """Expected first-PHY retransmission counts for the ideal static calendar.

    Valid on 1 <= D <= 15 s, with RTO offsets 1, 3, 7, 15 s, a 30 s
    packet lifetime, and no DSR admission failures. The number of useful
    retransmissions equals the count of affected packets. Endpoints on a
    discrete generation grid depend on the exact gate-boundary convention.
    """
    if not (1.0 <= duration_s <= 15.0 and rate_pps > 0 and cycles > 0):
        raise ValueError("Curve assumes 1 <= D <= 15 s and positive rate/cycles")
    useful = cycles * rate_pps * duration_s
    wasted = cycles * rate_pps * sum(max(0.0, duration_s - t)
                                     for t in (1.0, 3.0, 7.0, 15.0))
    trad = useful + wasted
    return {"D_s": duration_s, "TRAD_phy_retx": trad,
            "VTP_phy_retx": useful, "TRAD_bad_retx": wasted,
            "VTP_gain_pct": 100.0 * (trad - useful) / trad}


def timeouts(rto: float, maximum: float, lifetime: float, attempts: int) -> list[float]:
    result = []
    elapsed = 0.0
    step = rto
    for _ in range(attempts - 1):
        elapsed += step
        if elapsed >= lifetime - 1e-10:
            break
        result.append(elapsed)
        step = min(2 * step, maximum)
    return result


def ideal_prediction(row: dict[str, str]) -> dict[str, float | int]:
    interval = float(row["generation_interval_s"])
    first = float(row["app_start_s"]) + interval
    n = int(row["generated"])
    gate = float(row["outage_first_start_s"])
    off = float(row["outage_off_duration_s"])
    period = off + float(row["outage_on_duration_s"])
    cycles = int(row["channel_outages"])
    T = float(row["recovery_pacing_s"])
    rto = float(row["rto_initial_s"])
    scheduled = timeouts(
        rto, float(row["rto_max_s"]), float(row["lifetime_s"]),
        int(row["max_attempts"]),
    )
    assert scheduled, "No retransmissions in the analytic timer model"
    policy = row["policy"]
    assert policy in ("TRAD", "VTP1", "VTP2")

    paced_position: dict[int, int] = {}
    transmissions: list[tuple[float, int, float]] = []
    bad_retransmissions = 0
    successful_retransmissions = 0
    expired_in_outage = 0
    initial_deferred = 0
    for i in range(n):
        created = round(first + i * interval, 9)
        e = math.floor((created - gate + 1e-9) / period)
        is_closed = (0 <= e < cycles and
                     gate + e * period - 1e-8 <= created <
                     gate + e * period + off - 1e-8)
        if not is_closed:
            first_success = created
        else:
            reopening = gate + e * period + off
            remaining = reopening - created
            if policy == "TRAD":
                bad_retransmissions += sum(s < remaining - 1e-8 for s in scheduled)
                next_rto = next((s for s in scheduled if s >= remaining - 1e-8), None)
                if next_rto is None:
                    expired_in_outage += 1
                    continue
                first_success = created + next_rto
            elif remaining > rto + 1e-8:
                rank = paced_position.get(e, 0)
                paced_position[e] = rank + 1
                initial_deferred += 1
                first_success = reopening + rank * T
            else:
                first_success = created + rto
            successful_retransmissions += 1
        transmissions.append((first_success, i, first_success - created))

    # The sink measures adjacent |delay differences| in receiver arrival order.
    # Use a stable source-sequence tie-break for the idealized zero-hop-delay model.
    transmissions.sort(key=lambda x: (round(x[0], 9), x[1]))
    delays = [x[2] for x in transmissions]
    return {
        "predicted_rx_unique": len(delays),
        "predicted_expired": expired_in_outage,
        "predicted_bad_retrans": bad_retransmissions,
        "predicted_phy_retrans": bad_retransmissions + successful_retransmissions,
        "predicted_initial_deferred": initial_deferred,
        "predicted_delay_ms": 1000 * statistics.mean(delays),
        "predicted_jitter_ms": 1000 * sum(abs(b - a) for a, b in zip(delays, delays[1:])) / (len(delays) - 1),
    }


def timed_prediction(row: dict[str, str], d0_ms: float) -> dict[str, float | int]:
    interval = float(row["generation_interval_s"])
    first = float(row["app_start_s"]) + interval
    n = int(row["generated"])
    created_times = [round(first + i * interval, 9) for i in range(n)]
    originals = {round(x, 6) for x in created_times}
    gate = float(row["outage_first_start_s"])
    off = float(row["outage_off_duration_s"])
    period = off + float(row["outage_on_duration_s"])
    cycles = int(row["channel_outages"])
    T = float(row["recovery_pacing_s"])
    rto = float(row["rto_initial_s"])
    scan = 0.010
    scheduled = [round(s + (i + 1) * scan, 9) for i, s in enumerate(
        timeouts(rto, float(row["rto_max_s"]),
                 float(row["lifetime_s"]), int(row["max_attempts"])))
        if s + (i + 1) * scan < float(row["lifetime_s"]) - 1e-8]
    assert scheduled and abs(scan - 0.01) < 1e-12
    policy = row["policy"]
    assert policy in ("TRAD", "VTP1", "VTP2")

    def outage(t: float) -> tuple[int, float] | None:
        e = math.floor((t - gate + 1e-9) / period)
        start = gate + e * period
        if 0 <= e < cycles and start - 1e-8 <= t < start + off - 1e-8:
            return e, start + off
        return None

    # Other source submissions on the release grid: all originals, plus
    # first RTOs of packets generated in the last RTO before reopening.
    late_rtos = set()
    if policy != "TRAD":
        for a in created_times:
            episode = outage(a)
            if episode and episode[1] - a <= scheduled[0] + 1e-8:
                late_rtos.add(round(a + scheduled[0], 6))

    ranks: dict[int, int] = {}
    deliveries: list[tuple[float, int, float]] = []
    bad = missed = expired = 0
    max_recovery = 0.0
    for i, a in enumerate(created_times):
        episode = outage(a)
        if episode is None:
            b = a
        else:
            e, up = episode
            remaining = up - a
            if policy == "TRAD":
                bad += sum(s < remaining - 1e-8 for s in scheduled)
                next_rto = next((s for s in scheduled if s >= remaining - 1e-8), None)
                if next_rto is None:
                    expired += 1
                    continue
                b = a + next_rto
            elif remaining > scheduled[0] + 1e-8:
                rank = ranks.get(e, 0)
                ranks[e] = rank + 1
                base = round(up + rank * T, 6)
                # The paced submit occurs 1 us after the other submit.
                collision_on_source_tick = (base in originals or base in late_rtos)
                if collision_on_source_tick:
                    missed += 1
                    b = base + rto * 2 + scan
                    first_phy = b + 0.000050
                else:
                    b = base + 0.000001
                    first_phy = b + 0.000050
                max_recovery = max(max_recovery, (first_phy - up) * 1000)
            else:
                b = a + scheduled[0]
        deliveries.append((round(b, 9), i, b - a))
    deliveries.sort(key=lambda x: (x[0], x[1]))
    d = [x[2] for x in deliveries]
    good_retrans = sum(1 for b, i, _ in deliveries if outage(created_times[i]) is not None)
    return {
        "timed_rx_unique": len(d),
        "timed_expired": expired,
        "timed_bad_retrans": bad,
        "timed_phy_retrans": bad + good_retrans,
        "timed_tx_retrans": bad + good_retrans + missed,
        "timed_without_first_phy": missed,
        "timed_recovery_max_ms": max_recovery if policy != "TRAD" else float("nan"),
        "timed_delay_ms_plus_d0": statistics.mean(d) * 1000 + d0_ms,
        "timed_jitter_ms": sum(abs(b - a) for a, b in zip(d, d[1:])) * 1000 / (len(d) - 1),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    root = Path(__file__).resolve().parent
    parser.add_argument("--data", type=Path, default=root / "data/static_episode")
    parser.add_argument("--output", type=Path, default=root / "reproduced/model_validation.csv")
    parser.add_argument("--d0-ms", type=float, default=0.681257827,
                        help="External no-gate 0 m/s run-8 mean (raw record not included)")
    args = parser.parse_args()
    results = []
    for scenario in "ABCD":
        for pace in (5, 10, 20):
            filename = args.data / f"run-{scenario}-pac{pace}ms.csv"
            with filename.open(newline="") as f:
                rows = list(csv.DictReader(f))
            assert len(rows) == 30, f"Expected 30 rows in {filename}"
            for row in rows:
                predicted = ideal_prediction(row)
                timed = timed_prediction(row, args.d0_ms)
                results.append({
                    "scenario": scenario, "T_ms": pace,
                    "D_s": row["outage_off_duration_s"],
                    "lambda_pps": row["lambda_generated_pps"],
                    "run": row["run"], "policy": row["policy"],
                    **predicted,
                    **timed,
                    "observed_rx_unique": row["rx_unique"],
                    "observed_expired": row["expired"],
                    "observed_bad_retrans": row["retransmissions_bad_channel"],
                    "observed_phy_retrans": row["phy_retrans_attempts"],
                    "observed_delay_ms": row["e2e_delay_ms"],
                    "observed_jitter_ms": row["jitter_ms"],
                    "observed_tx_retrans": row["tx_retrans_submissions"],
                    "observed_without_first_phy_gap": (
                        int(row["tx_original_submissions"]) +
                        int(row["tx_retrans_submissions"]) -
                        int(row["phy_original_attempts"]) -
                        int(row["phy_retrans_attempts"])),
                })
    assert len(results) == 360
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)
    print("scenario,T_ms,policy,model_PHY,observed_PHY_median,PHY_max_absolute_gap,timed_delay_ms,observed_delay_median_ms,timed_jitter_ms,observed_jitter_median_ms,predicted_misses,observed_misses_median")
    for scenario in "ABCD":
        for pace in (5, 10, 20):
            for policy in ("TRAD", "VTP1", "VTP2"):
                rows = [x for x in results if x["scenario"] == scenario and
                        x["T_ms"] == pace and x["policy"] == policy]
                print(",".join(map(str, (
                    scenario, pace, policy, rows[0]["predicted_phy_retrans"],
                    statistics.median(int(x["observed_phy_retrans"]) for x in rows),
                    max(abs(int(x["observed_phy_retrans"]) -
                            int(x["predicted_phy_retrans"])) for x in rows),
                    round(float(rows[0]["timed_delay_ms_plus_d0"]), 3),
                    round(statistics.median(float(x["observed_delay_ms"]) for x in rows), 2),
                    round(float(rows[0]["timed_jitter_ms"]), 3),
                    round(statistics.median(float(x["observed_jitter_ms"]) for x in rows), 2),
                    rows[0]["timed_without_first_phy"],
                    statistics.median(int(x["observed_without_first_phy_gap"]) for x in rows),
                ))))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Audit close-spaced transport submissions in the matched static run.

This script measures temporal association. The static trace does not export
DSR maintenance admission, so it cannot identify the reason for a PHY miss.
"""

import argparse
import bisect
import csv
import json
from collections import defaultdict
from pathlib import Path


def analyze(path, policy):
    with path.open(newline="") as handle:
        rows = list(csv.DictReader(handle))

    events = defaultdict(list)
    submissions = []
    for row in rows:
        key = (row["seq"], row["attempt_id"])
        events[key].append(row)
        if row["event"] == "transport_submit":
            submissions.append(row)

    submissions.sort(key=lambda row: int(row["time_ns"]))
    timestamps = [int(row["time_ns"]) for row in submissions]
    summary = {
        "policy": policy,
        "submissions": len(submissions),
        "first_phy_observed": 0,
        "first_phy_absent": 0,
        "phy_with_previous_lt_50us": 0,
        "no_phy_with_previous_lt_50us": 0,
        "no_phy_with_previous_exactly_1us": 0,
        "paced_release_count": 0,
        "paced_release_without_first_phy": 0,
    }
    missing = []
    for row in submissions:
        key = (row["seq"], row["attempt_id"])
        this_events = events[key]
        has_phy = any(event["event"] == "phy_first" for event in this_events)
        paced = any(event["event"] == "paced_release" for event in this_events)
        now = int(row["time_ns"])
        position = bisect.bisect_left(timestamps, now)
        previous = submissions[position - 1] if position else None
        delta = now - int(previous["time_ns"]) if previous else None
        summary["first_phy_observed" if has_phy else "first_phy_absent"] += 1
        if paced:
            summary["paced_release_count"] += 1
            summary["paced_release_without_first_phy"] += int(not has_phy)
        if delta is not None and delta < 50_000:
            field = ("phy_with_previous_lt_50us" if has_phy else
                     "no_phy_with_previous_lt_50us")
            summary[field] += 1
        if not has_phy and delta == 1_000:
            summary["no_phy_with_previous_exactly_1us"] += 1
        if has_phy:
            continue
        rto = [int(event["time_ns"]) for event in this_events
               if event["event"] == "rto_expired" and
               int(event["time_ns"]) > now]
        later = [(int(event["time_ns"]), event["attempt_id"])
                 for (seq, attempt), packet_events in events.items()
                 if seq == key[0] and attempt != key[1]
                 for event in packet_events
                 if event["event"] == "phy_first" and
                 int(event["time_ns"]) > now]
        later.sort()
        missing.append({
            "policy": policy,
            "time_ns": now,
            "seq": key[0],
            "attempt_id": key[1],
            "paced_release": int(paced),
            "previous_submit_ns": previous["time_ns"] if previous else "",
            "previous_seq": previous["seq"] if previous else "",
            "previous_attempt_id": previous["attempt_id"] if previous else "",
            "previous_retransmission": previous["retransmission"] if previous else "",
            "delta_previous_ns": delta if delta is not None else "",
            "next_rto_ns": min(rto) if rto else "",
            "next_phy_ns": later[0][0] if later else "",
            "next_phy_attempt_id": later[0][1] if later else "",
        })
    return summary, missing


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path,
                        default=root / "data/full_independent_0_run1/packet")
    parser.add_argument("--output", type=Path, default=root / "analysis")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    summaries, misses = [], []
    for policy in ("VTP1", "VTP2", "TRAD"):
        path = args.input / f"full-independent-0.000000000-1-{policy}.csv"
        summary, missing = analyze(path, policy)
        summaries.append(summary)
        misses.extend(missing)
    (args.output / "static_aliasing_summary.json").write_text(
        json.dumps(summaries, indent=2) + "\n", encoding="utf-8")
    with (args.output / "static_aliasing_missing.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=(
            "policy", "time_ns", "seq", "attempt_id", "paced_release",
            "previous_submit_ns", "previous_seq", "previous_attempt_id",
            "previous_retransmission", "delta_previous_ns", "next_rto_ns",
            "next_phy_ns", "next_phy_attempt_id"))
        writer.writeheader()
        writer.writerows(misses)
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()

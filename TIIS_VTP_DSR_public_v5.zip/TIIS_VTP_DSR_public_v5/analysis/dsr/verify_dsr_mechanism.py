#!/usr/bin/env python3
"""Verify the DSR maintenance-buffer finding without mixing simulation profiles.

Run from the reproducibility-package root:
    python3 analysis/verify_dsr_mechanism.py .
"""

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def one(rows, policy):
    found = [row for row in rows if row["policy"] == policy]
    assert len(found) == 1, (policy, len(found))
    return found[0]


def run(root):
    route = root / "data" / "route_only_20_run8"
    static = root / "data" / "full_independent_0_run1"
    name = "mobility-route-20.000000000-8-VTP2.csv"
    original = read_csv(route / "packet" / name)
    traced = read_csv(route / "packet_instrumented" / name)
    new_events = {"dsr_send_entry", "dsr_packet_new_route", "dsr_maintain_accepted",
                  "dsr_maintain_rejected", "dsr_network_accepted",
                  "dsr_network_rejected", "dsr_ipv4_downcall"}
    assert [row for row in traced if row["event"] not in new_events] == original, \
        "The instrumentation changed pre-existing event rows or their order"

    route_main = read_csv(route / "main.csv")
    static_main = read_csv(static / "main.csv")
    historical = read_csv(root / "base_snapshot" / "data" / "main" /
                          "vtp-v4.6.3-final-multispeed.csv")
    assert len(route_main) == 3
    assert all(row["scenario"] == "mobility-route" and row["speed"] == "20.000000000"
               and row["run"] == "8" and row["outage_cycles_requested"] == "0"
               for row in route_main)
    assert all(row["scenario"] == "full-independent" and row["speed"] == "0.000000000"
               and row["run"] == "1" and row["outage_cycles_requested"] == "5"
               for row in static_main)
    historical_run8 = [row for row in historical if row["scenario"] == "full-independent"
                       and row["speed"] == "20.000000000" and row["run"] == "8"]
    assert len(historical_run8) == 3
    assert all(one(route_main, p)["configuration_hash"] != one(historical_run8, p)["configuration_hash"]
               for p in ("TRAD", "VTP1", "VTP2"))
    historical_static = [row for row in historical if row["scenario"] == "full-independent"
                         and row["speed"] == "0.000000000" and row["run"] == "1"]
    assert len(historical_static) == 3
    for policy in ("TRAD", "VTP1", "VTP2"):
        new, old = one(static_main, policy), one(historical_static, policy)
        assert new["configuration_hash"] == old["configuration_hash"]
        assert new.keys() == old.keys()
        assert all(new[field] == old[field] for field in new if field != "campaign_id"), \
            (policy, "static row parity")

    events = defaultdict(set)
    at_time = defaultdict(list)
    for row in traced:
        key = (row["seq"], row["attempt_id"])
        events[key].add(row["event"])
        if row["event"] == "transport_submit":
            at_time[row["time_ns"]].append(row)
    attempts = [row for rows in at_time.values() for row in rows
                if row["retransmission"] == "1"]
    rejected = [row for row in traced if row["event"] == "dsr_maintain_rejected"]
    rejected_retx = {(row["seq"], row["attempt_id"]) for row in rejected
                     if row["retransmission"] == "1"}
    missing = {(row["seq"], row["attempt_id"]) for row in attempts
               if "phy_first" not in events[(row["seq"], row["attempt_id"])]}
    assert len(rejected) == 81 and len(rejected_retx) == len(missing) == 78
    assert rejected_retx == missing
    paced = [row for row in traced if row["event"] == "paced_release"]
    paced_rejected = [row for row in paced
                      if (row["seq"], row["attempt_id"]) in rejected_retx]
    assert len(paced) == 296 and len(paced_rejected) == 14

    ranks = Counter()
    gap_rows = []
    for time_ns, group in at_time.items():
        for rank, row in enumerate(group, 1):
            key = (row["seq"], row["attempt_id"])
            if key not in missing:
                continue
            assert rank > 1
            assert "dsr_maintain_accepted" in events[(group[0]["seq"], group[0]["attempt_id"])]
            assert "phy_first" in events[(group[0]["seq"], group[0]["attempt_id"])]
            ranks[(len(group), rank)] += 1
            gap_rows.append({"time_ns": time_ns, "seq": row["seq"],
                             "attempt_id": row["attempt_id"], "group_size": len(group),
                             "rank": rank, "first_seq": group[0]["seq"],
                             "first_attempt_id": group[0]["attempt_id"],
                             "paced_release": int(key in {(p["seq"], p["attempt_id"]) for p in paced})})
    assert len(gap_rows) == 78 and len(set(r["time_ns"] for r in gap_rows)) == 61

    static_trace = read_csv(static / "packet" / "full-independent-0.000000000-1-VTP2.csv")
    sample = [(row["time_ns"], row["event"], row["attempt_id"])
              for row in static_trace if row["seq"] == "486"]
    for expected in (("60910001000", "paced_release", "2"),
                     ("62920000000", "rto_expired", "2"),
                     ("62920050000", "phy_first", "3")):
        assert expected in sample, expected
    assert not any(event == "phy_first" and attempt == "2"
                   for _, event, attempt in sample)

    energy = read_csv(static / "radio_summary.csv")
    for row in energy:
        assert abs(float(row["idle_node_seconds"]) + float(row["cca_busy_node_seconds"])
                   + float(row["tx_node_seconds"]) + float(row["rx_node_seconds"])
                   + float(row["switching_node_seconds"]) + float(row["sleep_node_seconds"])
                   + float(row["off_node_seconds"]) - 15000) < 1e-4
        assert abs(float(row["energy_difference_j"])) < 0.001
        assert int(row["delivered_payload_bits"]) == int(row["rx_unique"]) * 512 * 8

    return {
        "main_full_independent_20_run8_PDR_pct": {p: one(historical_run8, p)["pdr_pct"]
                                                  for p in ("TRAD", "VTP1", "VTP2")},
        "auxiliary_route_only_20_run8_PDR_pct": {p: one(route_main, p)["pdr_pct"]
                                                for p in ("TRAD", "VTP1", "VTP2")},
        "route_only_retransmission_submissions": len(attempts),
        "route_only_no_phy_retransmissions": len(missing),
        "route_only_dsr_maintain_rejections": len(rejected),
        "route_only_retransmission_rejections": len(rejected_retx),
        "route_only_paced_releases": len(paced),
        "route_only_paced_releases_rejected": len(paced_rejected),
        "simultaneous_group_size_and_rank": {f"{n}:{r}": count
                                              for (n, r), count in sorted(ranks.items())},
        "distinct_simultaneous_groups": 61,
        "static_full_independent_run1_seq486": sample,
        "gap_rows": gap_rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path, nargs="?", default=Path("."))
    parser.add_argument("--out", type=Path, help="Write a concise JSON result")
    parser.add_argument("--gaps", type=Path, help="Write all 78 classified retransmissions")
    args = parser.parse_args()
    result = run(args.root)
    gaps = result.pop("gap_rows")
    if args.gaps:
        args.gaps.parent.mkdir(parents=True, exist_ok=True)
        with args.gaps.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(gaps[0]))
            writer.writeheader()
            writer.writerows(gaps)
    print(json.dumps(result, indent=2))
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

# VTP–DSR manuscript v5: reproducibility files

This package contains fixed ns-3.35 outputs, scenario source variants, an
event-calendar model, scripts, and the raw static DSR maintenance rerun. The
controlled intervention is a **receiver-application DATA acceptance gate**:
when C(t)=0, the sink refuses DATA after UDP reception. Radios and DSR remain
active. These files do not establish performance under a physical blackout.

The datasets have separate provenance. The main campaign has 450 runs (five
speeds × 30 independent RNG runs × three policies); the phase campaign has
180 runs (12 gate phases × five independent seeds × three policies); the
static queue-depth campaign has 360 runs (four conditions × three pacing
intervals × ten runs × three policies) and five recovery episodes per run.
A separate, coherent-current 450-run repetition and 22,500 per-radio state
records support the corrected energy results. The ARM=0 source-maintenance
rerun is **one static seed** for VTP1 and VTP2, which have identical event
chronologies; it is not another independent experimental campaign.

## One-command numeric reproduction

Requires Python 3.10+, NumPy, SciPy, pandas and Matplotlib. From the extracted
archive root:

```bash
python3 reproduce.py
```

This checks the internal SHA-256 manifest and campaign pairings, recreates the
timer model, Figures 1–7, Tables 4–11 and the ARM=0 maintenance analysis, then
checks each generated **numeric CSV** against its fixed `derived/` copy
(exact labels and counts; floating values within 1e-7 absolute or 1e-9
relative tolerance).
The plots go to `reproduced/figures/`. Figures 2–7 preserve the reported
numeric series and confidence-interval rules; their style and pixels need not
match the earlier Word images. The fixed Figure 1 and its script now represent
the *same* experiment described in the manuscript.

To run steps individually:

```bash
python3 verify_archive.py
python3 model.py --output reproduced/model_validation.csv
python3 make_fig1.py --figure reproduced/figures/Figure_1.png \
  --series reproduced/figure1_series.csv
python3 make_tables.py
python3 make_main_figures.py
python3 source/TIIS_energy_campaign_ns3_35_v1/analyze_energy_campaign.py \
  --data-dir data/energy/tiis-energy-wifi-v1 \
  --reference source/TIIS_energy_campaign_ns3_35_v1/reference/legacy-main-450.csv \
  --output-dir reproduced/energy_analysis
python3 reproduce_static_arm0.py
```

The main result and statistical source analyzer can also be run directly:

```bash
python3 source/main_v4.6.3/analyze-vtp-results.py \
  --input data/energy/tiis-energy-wifi-v1/main.csv \
  --output-dir reproduced/main_analysis \
  --primary-metrics phy_retrans_attempts,jitter_ms,e2e_delay_ms,network_energy_j \
  --bootstrap-reps 10000
```

The replay in `model.py` predicts the timer-expiry scan and same-tick
source-admission outcome **conditional on this implementation rule**: a
paced submission 1 µs after another source submission has no first PHY
start and its next backed-off RTO is checked 2.01 s later. This is supported
for the static ARM=0 run by the independent maintenance trace below. It is
not a general collision law or a delivery-latency bound.

## Manuscript-to-file map

| Item | Fixed source data | Script and generated evidence |
| --- | --- | --- |
| Figure 1, panels (a), (b) | `data/static_episode/episodes-{A,B,C,D}-pac{5,10,20}ms.csv`; matched `run-*.csv` | `make_fig1.py`, `model.py` → `derived/figure1_series.csv`, `figures/Figure_1.png`. Each point has 50 episodes **per VTP policy**; VTP1 and VTP2 coincide. Markers are observed means; lines are the paced-span equation and conditional calendar maximum. |
| Figure 2, PDR | `data/energy/tiis-energy-wifi-v1/main.csv` (`pdr_pct`) | `make_main_figures.py` → `derived/figure2to7_series.csv`, Figure 2; 30-run percentile bootstrap. |
| Figure 3, delivered delay | Same corrected main CSV (`e2e_delay_ms`) | Same script/series → Figure 3; 30-run Student t CI. |
| Figure 4, arrival-order jitter | Same CSV (`jitter_ms`) | Same script/series → Figure 4; 30-run Student t CI. |
| Figure 5, first PHY retransmissions | Same CSV (`phy_retrans_attempts`) | Same script/series → Figure 5; 30-run Student t CI. MAC retries and unmatched transport submissions are distinct. |
| Figure 6, corrected energy per delivered payload bit | Same CSV (`energy_uj_per_delivered_bit`); `data/energy/tiis-energy-wifi-v1/radio/*.csv` | Same script/series → Figure 6; `source/TIIS_energy_campaign_ns3_35_v1/analyze_energy_campaign.py` checks the per-radio energy calculation. |
| Figure 7, loss-penalized delay | Same CSV (`penalized_delay_ms`) | Same script/series → Figure 7; 30-run Student t CI. |
| Table 1, notation | `source/main_v4.6.3/vtp-dsr-comparison.cc`; manuscript definitions | Protocol definitions; no statistical reduction. |
| Table 2, settings | `source/main_v4.6.3/outage-phases-30.csv`, main/static launchers and config columns in raw CSVs | Inspect configuration and schedule hashes (`configuration_hash`, `outage_schedule_hash`, `rng_seed`, `rng_run`). |
| Table 3, measurement levels | Counter definitions in the relevant `source/` profile and the raw CSV columns | Separate transport submissions, first PHY starts, per-radio energy and payload denominator. |
| Table 4, static model check | `data/static_episode/run-B-pac{5,10,20}ms.csv`, `run=1` | `make_tables.py` + `model.py` → `derived/tables/Table_4.csv`: observed/model columns. VTP1 transport submissions are **550/590/590**. The external base-delay calibration is qualified below. |
| Table 5, static recovery | Twelve `data/static_episode/episodes-*.csv` files and corresponding `run-*.csv` | `make_tables.py` + `model.py` → `derived/tables/Table_5.csv`, 50 valid episodes per configuration and VTP policy, observed/model columns. |
| Table 6, 30-run medians | Corrected 450-run energy main CSV | `make_tables.py` → `derived/tables/Table_6.csv`. |
| Table 7, paired effects | Corrected 450-run energy main CSV, 30 complete seed trajectories | `make_tables.py`, exact Wilcoxon/Hodges–Lehmann functions in `source/main_v4.6.3/analyze-vtp-results.py` → `derived/tables/Table_7.csv`. See manuscript correction below. |
| Table 8, paired relative gains | Same corrected 450-run CSV, paired by speed and run | `make_tables.py` → `derived/tables/Table_8.csv`, bootstrap CI for first three metrics, t CI for energy/bit. Fix the manuscript CI rounding differences listed below. |
| Table 9, gate-phase PDR | `data/phase/*.csv`, all 180 rows | `make_tables.py` → `derived/tables/Table_9.csv`; 5^5 whole-seed ordered bootstrap resamples and pointwise 95% intervals. |
| Table 10, current and state durations | `data/energy/tiis-energy-wifi-v1/radio/full-independent-0.000000000-1-{TRAD,VTP1,VTP2}.csv` (50 nodes each) | `make_tables.py` → `derived/tables/Table_10.csv`. |
| Table 11, energy contrasts | `data/energy/tiis-energy-wifi-v1/analysis/paired_energy_by_speed.csv`, from the corrected 450-run campaign | `make_tables.py` → `derived/tables/Table_11.csv`; the energy source analyzer regenerates its paired input. |
| Algorithm 1 | `source/main_v4.6.3/vtp-dsr-comparison.cc` | Inspect the timeout decision and paced FIFO release in the scenario source; no numerical transform. |

`data/main/vtp-v4.6.3-final-multispeed.csv` is the historical main campaign
without the later coherent energy-current profile. Use the corrected main CSV
for Figures 2–7 and Tables 6–8/11. The source variants under `source/` serve
different profiles and must not be combined into an unnamed binary.

## Static ARM=0 mechanism audit

The original rerun files are under `data/diagnostics/static_arm0_run1/`:
`packet/`, `maintain/`, `runs/`, `logs/`, and saved `analysis/` for each VTP
policy. The diagnostic source, analysis code, installation instructions and
original static reference are under `source/static_arm0_check/`. This source
profile requires ns-3.35 and the exact DSR source fingerprints recorded in
the rerun manifest. The matching `dsr-routing.cc` is included in
`source/static_arm0_check/diagnostic_source/src/` for a complete source record.
For a **fresh, separate ns-3.35 tree**, install the recorded four-file
source profile, then use the guarded rerun launcher (absolute paths below
stand for the extracted archive root):

```bash
cd /path/to/ns-3.35
bash /path/to/TIIS_VTP_DSR_public_v5/source/static_arm0_check/install_exact_static_profile.sh
bash /path/to/TIIS_VTP_DSR_public_v5/source/static_arm0_check/run_static_arm0.sh
```

The installer verifies all archived source hashes and backs up existing
files before replacing them. The launcher verifies the exact DSR hashes
again and writes `tiis-static-run1-arm0-maintenance/`. Use the supplied
`source/static_arm0_check/README.md` for the phase reference-parity option.
The ns-3.35 executable is not bundled here.

`reproduce_static_arm0.py` recalculates occupancy and rejected-attempt owners
from the raw `maintain/` and `packet/` CSVs, compares all generated analysis
rows with the frozen outputs, and executes the event-level audit. Each policy
has 3,099 transport submissions, 3,049 distinct first PHY starts, and 50
paced attempts with no first PHY. All 50 match a DSR maintenance-buffer
rejection by an entry representing a *different* UID and packet sequence.
The resident's insertion precedes rejection by 1 µs; the next first PHY for
the refused sequence follows by about 2.010049 s. VTP1 and VTP2 represent
the same static event chronology. This proves the cause for this seed and
ARM=0 implementation, not for all mobile runs.

The separate `data/diagnostics/route_only_20_run8/` and `data/severe/`
files have different interventions. Do not pool their packet traces or infer
a DSR cause for the severe main-campaign run without its own matching trace.

## Measurement limits and manuscript synchronization

- Table 4's delay calculation uses `d0=0.681257827 ms`, reported as a
  separate **no-gate static run 8** calibration. The raw calibration run is
  not supplied here. `make_tables.py --d0-ms VALUE` and `model.py --d0-ms
  VALUE` expose it; PHY counts, submission counts and arrival-order jitter
  are independent of it. The manuscript's Data and Reproducibility
  Statement identifies this calibration run as not archived.
- Tables 4–11 of the manuscript print the values generated by this
  archive's scripts, rounded as displayed. For Table 7, VTP2−VTP1
  first-PHY, the defined exact test on 30 seed trajectories gives
  0.1297825575 (exact) and 0.5191302299 (Holm), printed as 0.130 and
  0.519. Table 8 intervals use the archived 10,000-resample bootstrap.
- The earlier timing plot, historical Table 4 transcription and the
  superseded analytic Figure 1 proposal are retained under `historical/`
  to make provenance changes inspectable. They are **not** Figures 1/Table 4
  in the current manuscript.
- No ARM=1 matched effect on VTP1−C_RTO, zero-window probe comparison,
  physical link failure, or imperfect-gate signal result is asserted here.

The corrected energy model uses 3 V; idle, CCA and switching each use
0.273 A, TX 0.380 A, RX 0.313 A, sleep 0.033 A and off 0 A. The bit
denominator is uniquely delivered DATA packets × 512 bytes × 8. The
current-specific scenario and per-radio state audit are documented in
`source/TIIS_energy_campaign_ns3_35_v1/README.md`.


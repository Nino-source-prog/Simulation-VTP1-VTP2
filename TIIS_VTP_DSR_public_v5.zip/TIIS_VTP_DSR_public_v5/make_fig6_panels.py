#!/usr/bin/env python3
"""Figure 6 as printed in the manuscript: (a) 0-20 m/s, (b) detail 0-15 m/s.
Reads derived/figure2to7_series.csv. Run from the archive root:
python3 make_fig6_panels.py --figure reproduced/figures/Figure_6_panels.png
"""
import argparse
import csv
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
STYLE = {"TRAD": dict(color="tab:blue", ls="-", marker="o"),
         "VTP1": dict(color="tab:orange", ls="--", marker="s"),
         "VTP2": dict(color="tab:green", ls=":", marker="^")}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--figure", type=Path, default=ROOT / "reproduced/figures/Figure_6_panels.png")
    args = ap.parse_args()
    rows = [r for r in csv.DictReader((ROOT / "derived/figure2to7_series.csv").open(newline=""))
            if r["figure"] == "6"]
    plt.rcParams["font.family"] = "DejaVu Sans"
    fig, axs = plt.subplots(1, 2, figsize=(9.9, 4.4), dpi=200)
    for ax, top in ((axs[0], 20), (axs[1], 15)):
        for pol in ("TRAD", "VTP1", "VTP2"):
            v = sorted((r for r in rows if r["policy"] == pol and float(r["speed_mps"]) <= top),
                       key=lambda r: float(r["speed_mps"]))
            x = [float(r["speed_mps"]) for r in v]; m = [float(r["mean"]) for r in v]
            err = [[mm - float(r["ci95_low"]) for mm, r in zip(m, v)],
                   [float(r["ci95_high"]) - mm for mm, r in zip(m, v)]]
            ax.errorbar(x, m, yerr=err, capsize=3, lw=1.8, ms=5, label=pol, **STYLE[pol])
        ax.set_xlabel("Speed (m/s)"); ax.grid(True, ls=":", alpha=0.6)
        ax.set_xticks([0, 5, 10, 15, 20] if top == 20 else [0, 5, 10, 15])
    axs[0].set_ylabel("Network energy per delivered payload bit (µJ/bit)")
    axs[0].set_title("(a) 0–20 m/s", fontsize=10); axs[1].set_title("(b) Detail, 0–15 m/s", fontsize=10)
    axs[0].legend(title="Policy", loc="upper left", fontsize=8, title_fontsize=9)
    fig.tight_layout(); args.figure.parent.mkdir(parents=True, exist_ok=True); fig.savefig(args.figure, dpi=200)
    print(args.figure)


if __name__ == "__main__":
    main()

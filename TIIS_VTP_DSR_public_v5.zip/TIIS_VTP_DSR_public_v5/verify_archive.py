#!/usr/bin/env python3
"""Check campaign coverage, pairing, and the archived radio-state records."""

import csv
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
POLICIES = {"TRAD", "VTP1", "VTP2"}


def load(path):
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


def exact_triplets(rows, key, expected):
    grouped = {}
    for row in rows:
        k = tuple(row[c] for c in key)
        grouped.setdefault(k, set())
        assert row["policy"] not in grouped[k], (k, row["policy"])
        grouped[k].add(row["policy"])
    assert len(grouped) == expected and all(p == POLICIES for p in grouped.values())


def main():
    main_rows = load(ROOT / "data/main/vtp-v4.6.3-final-multispeed.csv")
    assert len(main_rows) == 450
    exact_triplets(main_rows, ("speed", "run"), 150)
    assert {int(float(r["speed"])) for r in main_rows} == {0, 5, 10, 15, 20}
    assert {int(r["run"]) for r in main_rows} == set(range(1, 31))

    static_files = sorted((ROOT / "data/static_episode").glob("run-*-pac*ms.csv"))
    assert len(static_files) == 12
    static = []
    for p in static_files:
        one = load(p)
        assert len(one) == 30, (p, len(one))
        exact_triplets(one, ("run",), 10)
        static.extend(one)
    assert len(static) == 360
    assert len({(r["campaign_id"], r["recovery_pacing_s"], r["run"],
                 r["policy"]) for r in static}) == 360
    assert {r["scenario"] for r in static} == {"full-independent"}

    phase_files = sorted((ROOT / "data/phase").glob("*.csv"))
    assert len(phase_files) == 12
    phase = [r for p in phase_files for r in load(p)]
    assert len(phase) == 180
    exact_triplets(phase, ("outage_phase_s", "run"), 60)
    assert len({r["outage_phase_s"] for r in phase}) == 12

    energy_dir = ROOT / "data/energy/tiis-energy-wifi-v1"
    energy = load(energy_dir / "main.csv")
    assert len(energy) == 450
    exact_triplets(energy, ("speed", "run"), 150)
    radio_files = sorted((energy_dir / "radio").glob("*.csv"))
    assert len(radio_files) == 450
    counts = Counter()
    for p in radio_files:
        d = load(p)
        assert len(d) == 50, (p, len(d))
        assert {int(r["node"]) for r in d} == set(range(50))
        counts[d[0]["policy"]] += len(d)
    assert counts == Counter({p: 7500 for p in POLICIES}), counts

    for f in ("model.py", "make_fig1.py", "make_tables.py", "make_main_figures.py",
              "reproduce.py", "reproduce_static_arm0.py",
              "figures/Figure_1.png", "derived/figure1_series.csv",
              "derived/tables/Table_4.csv", "README.md", "SHA256SUMS.txt"):
        assert (ROOT / f).is_file(), f
    arm0 = ROOT / "data/diagnostics/static_arm0_run1"
    check = json.loads((arm0 / "analysis/static_arm0_50_check.json").read_text())
    assert {r["policy"] for r in check["results"]} == {"VTP1", "VTP2"}
    assert all(r["missing"] == r["same_attempt_dsr_rejections"] ==
               r["resident_entry_proven"] == 50 for r in check["results"])
    for policy in ("VTP1", "VTP2"):
        stem = f"speed0-run1-{policy}-phase0"
        for part in ("packet", "maintain", "runs"):
            assert (arm0 / part / f"{stem}.csv").is_file()
    with (ROOT / "derived/tables/Table_4.csv").open(newline="") as stream:
        table4 = list(csv.DictReader(stream))
    assert len(table4) == 4 and [int(r["tx_retrans_submissions_observed"])
                                 for r in table4] == [1450, 550, 590, 590]
    print("PASS: main=450; phase=180; static=360 (12 × 10 matched triplets); "
          "energy=450 and 22,500 radio-state records; ARM=0 static traces "
          "and manuscript Figure 1/Table 4 present")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Audit the 50 missing first PHY attempts in the static ARM=0 run 1.

Packet-only mode checks the pre-existing phase trace against the static
reference. Full mode additionally requires the six-field maintenance-buffer
trace and an identified resident entry for every missing attempt.
"""

import argparse
import csv
import json
from bisect import bisect_left
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EVENTS = ("transport_submit", "paced_release", "phy_first")


def load(path):
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def key(row):
    return row["seq"], row["attempt_id"]


def audit(policy, packet_path, run_path, analysis_dir, packet_only):
    packet = load(packet_path)
    submitted = {key(r) for r in packet if r["event"] == "transport_submit"}
    first_phy = {key(r) for r in packet if r["event"] == "phy_first"}
    paced = {key(r) for r in packet if r["event"] == "paced_release"}
    rejected = {key(r) for r in packet if r["event"] == "dsr_maintain_rejected"}
    missing = submitted - first_phy
    assert len(submitted) == 3099 and len(first_phy) == 3049
    assert len(missing) == 50 and missing == rejected == (paced & missing)
    assert all(r["C"] == r["P"] == "1" and r["attempt_id"] == "2"
               for r in packet if r["event"] == "dsr_maintain_rejected")

    original = load(ROOT / "reference/packet" /
                    f"full-independent-0.000000000-1-{policy}.csv")
    for event in EVENTS:
        selected = lambda rows: [(r["time_ns"], r["seq"], r["attempt_id"],
                                  r["retransmission"]) for r in rows
                                 if r["event"] == event]
        assert selected(packet) == selected(original), (policy, event)

    run = load(run_path)
    assert len(run) == 1 and run[0]["policy"] == policy
    historical = [r for r in load(ROOT / "reference/static_run1_main.csv")
                  if r["policy"] == policy][0]
    for field in ("rx_unique", "tx_retrans_submissions", "phy_retrans_attempts",
                  "e2e_delay_ms", "jitter_ms", "outage_schedule_hash"):
        assert run[0][field] == historical[field], (policy, field)
    assert run[0]["recovery_phase_s"] == "0.000000000"

    timestamps = sorted(int(r["time_ns"]) for r in packet
                        if r["event"] == "transport_submit")
    failed_rows = [r for r in packet if r["event"] == "dsr_maintain_rejected"]
    lags = []
    per_episode = Counter()
    for row in failed_rows:
        t = int(row["time_ns"])
        pos = bisect_left(timestamps, t)
        lags.append(t - timestamps[pos - 1])
        for episode in range(5):
            reopening_ns = int((60.5 + 30*episode) * 1e9)
            if reopening_ns <= t < reopening_ns + int(2e9):
                per_episode[episode + 1] += 1
                break
    assert set(lags) == {1000} and sorted(per_episode.values()) == [10]*5

    details = []
    if not packet_only:
        summary = json.loads((analysis_dir / "summary.json").read_text())
        owners = load(analysis_dir / "missing_first_phy_owners.csv")
        assert summary["source_uid_key_enabled"] == 0
        assert summary["missing_first_phy"] == 50
        assert summary["source_missing_with_owner"] == 50
        assert summary["source_missing_without_owner"] == 0
        assert len(owners) == 50
        assert {(r["attempt_seq"],r["attempt_id"]) for r in owners} == missing
        assert all(r["missing_first_phy_for_attempt"] == "1" and
                   r["first_phy_for_attempt"] == "0" and
                   r["owner_insert_ns"] and r["owner_seq"] and
                   r["owner_attempt"] and r["our_addr"] == "10.1.1.1"
                   for r in owners)
        details = owners
    return {"policy": policy, "submitted": len(submitted),
            "first_phy": len(first_phy), "missing": len(missing),
            "same_attempt_dsr_rejections": len(missing & rejected),
            "paced_missing": len(missing & paced),
            "episode_counts": dict(sorted(per_episode.items())),
            "previous_submit_lag_ns": sorted(set(lags)),
            "resident_entry_proven": len(details),
            "status": "maintenance confirmed" if details else "packet-level precheck"}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--result-dir", type=Path, required=True,
                   help="ARM=0 runner output with runs/, packet/, analysis/")
    p.add_argument("--packet-only", action="store_true",
                   help="Precheck without six-field maintenance trace")
    p.add_argument("--output", type=Path)
    args = p.parse_args()
    results = []
    for policy in ("VTP1", "VTP2"):
        stem = f"speed0-run1-{policy}-phase0"
        results.append(audit(policy, args.result_dir/"packet"/f"{stem}.csv",
                             args.result_dir/"runs"/f"{stem}.csv",
                             args.result_dir/"analysis"/stem,
                             args.packet_only))
    out = {"profile": "full-independent, 0 m/s, run 1, T=5 ms, ARM=0",
           "comparison": "event-level parity with fixed original static run 1",
           "results": results}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(out, indent=2, ensure_ascii=False)+"\n")
    print(json.dumps(out, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
set -euo pipefail

# Run only from a clean ns-3.35 root. This installs the four exact scenario/DSR
# source files recorded by the static ARM=0 rerun; previous files are backed up.
PACKAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$PACKAGE/diagnostic_source/src"
[[ -x ./ns3 || -x ./waf ]] || {
  echo 'Run from a clean ns-3.35 root (./ns3 or ./waf required).' >&2; exit 2;
}
source_files=(
  "$SRC/vtp-dsr-comparison.cc"
  "$SRC/dsr-routing.cc"
  "$SRC/dsr-routing.h"
  "$SRC/dsr-maintain-buff.cc"
)
targets=(
  scratch/vtp-dsr-static-arm0.cc
  src/dsr/model/dsr-routing.cc
  src/dsr/model/dsr-routing.h
  src/dsr/model/dsr-maintain-buff.cc
)
expected=(
  1cdb82a2dc62394a680d9d848a3a468b6abfdf1fba3660f1cb6261df5ac8379e
  091168646aba76142592eca1d1f01bb82db1880a0a141eeb1523de4925c632b6
  acfb0685b0719285786d1341ac27067617a7e651661b4a7f52e4fd1a0d291680
  c4e53c9b08b8dde7eb33b8ac2fb44e372fce4e0210bd6d847b728f053c2ee500
)
for i in "${!source_files[@]}"; do
  actual="$(sha256sum "${source_files[$i]}" | cut -d' ' -f1)"
  if [[ "$actual" != "${expected[$i]}" ]]; then
    echo "Diagnostic source hash mismatch: ${source_files[$i]}" >&2; exit 2
  fi
  [[ -d "$(dirname "${targets[$i]}")" ]] || {
    echo "Missing ns-3.35 directory: $(dirname "${targets[$i]}")" >&2; exit 2;
  }
  if [[ -e "${targets[$i]}" ]] && ! cmp -s "${targets[$i]}" "${source_files[$i]}"; then
    [[ ! -e "${targets[$i]}.before-static-arm0.bak" ]] || {
      echo "Backup already exists: ${targets[$i]}.before-static-arm0.bak" >&2; exit 2;
    }
  fi
done
for i in "${!source_files[@]}"; do
  if [[ -e "${targets[$i]}" ]] && cmp -s "${targets[$i]}" "${source_files[$i]}"; then
    continue
  fi
  if [[ -e "${targets[$i]}" ]]; then
    cp -p -- "${targets[$i]}" "${targets[$i]}.before-static-arm0.bak"
  fi
  cp -- "${source_files[$i]}" "${targets[$i]}"
done
echo 'Exact static ARM=0 diagnostic source installed.'

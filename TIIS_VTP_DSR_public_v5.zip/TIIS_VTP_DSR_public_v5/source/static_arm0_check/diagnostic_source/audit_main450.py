#!/usr/bin/env python3
"""Audit descriptif des 450 runs v4; ne deduit aucune cause paquet par paquet."""

import argparse
import csv
import statistics
from collections import defaultdict
from pathlib import Path

SPEEDS = (0, 5, 10, 15, 20)
POLICIES = ("TRAD", "VTP1", "VTP2")
ZERO_BALANCES = ("conservation_delta", "rto_balance_delta",
                 "bad_channel_split_delta", "no_route_split_delta",
                 "original_state_balance_delta",
                 "retransmission_state_balance_delta",
                 "rreq_timer_balance_delta")


def audit(source, destination):
    with Path(source).open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 450:
        raise ValueError(f"Attendu 450 lignes, obtenu {len(rows)}")
    expected = {(speed, run, policy) for speed in SPEEDS
                for run in range(1, 31) for policy in POLICIES}
    keys = [(int(float(r["speed"])), int(r["run"]), r["policy"]) for r in rows]
    if set(keys) != expected or len(keys) != len(set(keys)):
        raise ValueError("Grille vitesse/run/politique incomplete ou dupliquee")
    if any(r["schema_version"] != "4.7" or
           int(r["physical_channel_outage"]) != 0 or
           any(int(r[f]) != 0 for f in ZERO_BALANCES) for r in rows):
        raise ValueError("Schema, porte physique ou bilan interne inattendu")
    per_run, groups = [], defaultdict(list)
    for r in rows:
        speed, run, policy = int(float(r["speed"])), int(r["run"]), r["policy"]
        originals = int(r["tx_original_submissions"]) - int(r["phy_original_attempts"])
        retx = int(r["tx_retrans_submissions"]) - int(r["phy_retrans_attempts"])
        if originals < 0 or retx < 0 or int(r["generated"]) != int(r["tx_original_submissions"]):
            raise ValueError(f"Soumissions et premieres PHY incoherentes: {speed}/{run}/{policy}")
        item = dict(speed=speed, run=run, policy=policy,
                    missing_original=originals, missing_retransmission=retx,
                    missing_total=originals + retx,
                    attempts_without_route=int(r["attempts_without_route"]),
                    pi_p=float(r["pi_p"]), rx_unique=int(r["rx_unique"]),
                    generated=int(r["generated"]), pdr_pct=float(r["pdr_pct"]),
                    recovery_latency_max_ms=r["recovery_latency_max_ms"])
        per_run.append(item)
        groups[(speed, policy)].append(item)
    destination.mkdir(parents=True, exist_ok=True)
    with (destination / "per_run.csv").open("w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, list(per_run[0]))
        writer.writeheader(); writer.writerows(sorted(per_run, key=lambda r:
                                                      (r["speed"], r["policy"], r["run"])))
    summary = []
    for (speed, policy), subset in sorted(groups.items()):
        totals = [r["missing_total"] for r in subset]
        item = {"speed": speed, "policy": policy, "n_seeds": len(subset),
                "missing_total_30": sum(totals),
                "missing_mean": statistics.mean(totals),
                "missing_median": statistics.median(totals),
                "missing_min": min(totals), "missing_max": max(totals),
                "runs_with_missing": sum(x > 0 for x in totals),
                "missing_original_mean": statistics.mean(r["missing_original"]
                                                           for r in subset),
                "missing_retransmission_mean": statistics.mean(
                    r["missing_retransmission"] for r in subset),
                "without_route_mean": statistics.mean(r["attempts_without_route"]
                                                       for r in subset),
                "pi_p_mean": statistics.mean(r["pi_p"] for r in subset),
                "pdr_mean_pct": statistics.mean(r["pdr_pct"] for r in subset)}
        summary.append(item)
    with (destination / "by_speed_policy.csv").open("w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, list(summary[0]))
        writer.writeheader(); writer.writerows(summary)
    print(f"450 runs verifies; {len(summary)} groupes de 30; "
          f"bilan interne nul pour les {len(ZERO_BALANCES)} compteurs testes.")
    return per_run, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    audit(args.source, args.out_dir)


if __name__ == "__main__":
    main()

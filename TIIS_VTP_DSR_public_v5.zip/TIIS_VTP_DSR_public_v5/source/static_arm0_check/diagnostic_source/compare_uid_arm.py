#!/usr/bin/env python3
"""Compare le bras DSR UID aux graines de phase v1.1, sans postuler L_max."""

import argparse
import csv
import json
import math
import random
import statistics
from collections import defaultdict
from pathlib import Path


def single(path):
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 1:
        raise ValueError(f"Attendu exactement une ligne: {path}")
    return rows[0]


def missing(r):
    return (int(r["tx_original_submissions"]) + int(r["tx_retrans_submissions"]) -
            int(r["phy_original_attempts"]) - int(r["phy_retrans_attempts"]))


def bootstrap_ci(values, seed=20261026, n_boot=20000):
    if len(values) < 2:
        return [None, None]
    rng = random.Random(seed)
    n = len(values)
    estimates = sorted(sum(values[rng.randrange(n)] for _ in range(n)) / n
                       for _ in range(n_boot))
    return [estimates[int(0.025 * (n_boot - 1))],
            estimates[int(0.975 * (n_boot - 1))]]


def compare(result_dir, reference_dir):
    rows = []
    for path in sorted((result_dir / "runs").glob("*.csv")):
        new, old = single(path), single(reference_dir / "runs" / path.name)
        for field in ("scenario", "policy", "speed", "run", "rng_seed", "rng_run",
                      "outage_schedule_hash", "outage_phase_s", "recovery_pacing_s",
                      "recovery_phase_s", "energy_profile", "physical_channel_outage",
                      "generated", "outage_off_duration_s"):
            if new[field] != old[field]:
                raise ValueError(f"Paire de configurations incompatible {path.name}: "
                                 f"{field}={new[field]} contre {old[field]}")
        if new["configuration_hash"] == old["configuration_hash"]:
            raise ValueError(f"Bras UID sans changement de hash: {path.name}")
        o, n = missing(old), missing(new)
        om, nm = float(old["recovery_latency_max_ms"]), float(new["recovery_latency_max_ms"])
        row = {"policy": new["policy"], "run": int(new["run"]),
               "phase_s": float(new["recovery_phase_s"]),
               "missing_reference": o, "missing_uid": n, "delta_missing": n-o,
               "rx_unique_reference": int(old["rx_unique"]),
               "rx_unique_uid": int(new["rx_unique"]),
               "delta_rx_unique": int(new["rx_unique"])-int(old["rx_unique"]),
               "lmax_reference_ms": om, "lmax_uid_ms": nm,
               "delta_lmax_ms": nm-om,
               "e2e_reference_ms": float(old["e2e_delay_ms"]),
               "e2e_uid_ms": float(new["e2e_delay_ms"]),
               "delta_e2e_ms": float(new["e2e_delay_ms"])-float(old["e2e_delay_ms"]),
               "attempts_without_route_reference": int(old["attempts_without_route"]),
               "attempts_without_route_uid": int(new["attempts_without_route"])}
        rows.append(row)
    if not rows:
        raise ValueError("Aucun run du bras UID.")
    dest = result_dir / "analysis"
    dest.mkdir(exist_ok=True)
    with (dest / "uid_paired_by_seed.csv").open("w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    groups = defaultdict(list)
    for row in rows:
        groups[(row["policy"], row["phase_s"])].append(row)
    report = []
    for (policy, phase), subset in sorted(groups.items()):
        runs = [row["run"] for row in subset]
        if len(runs) != len(set(runs)):
            raise ValueError(f"Run duplique dans {policy} phase={phase}")
        deltas = {name: [r[f"delta_{name}"] for r in subset]
                  for name in ("missing", "rx_unique", "e2e_ms")}
        # CSV appelle 'delta_e2e_ms', alors que les autres suivent delta_<metric>.
        finite_lmax = [r["delta_lmax_ms"] for r in subset
                       if math.isfinite(r["delta_lmax_ms"])]
        result = {"policy": policy, "phase_s": phase, "n_independent_seeds": len(runs),
                  "runs": sorted(runs),
                  "missing_uid_total": sum(r["missing_uid"] for r in subset),
                  "zero_missing_runs": sum(r["missing_uid"] == 0 for r in subset),
                  "lmax_447_551_ms_runs": sum(math.isclose(r["lmax_uid_ms"], 447.551,
                                                      abs_tol=1e-6, rel_tol=0)
                                                for r in subset),
                  "rx_unique_non_decreased_runs": sum(r["delta_rx_unique"] >= 0
                                                        for r in subset),
                  "lmax_mean_delta_ms": statistics.mean(finite_lmax) if finite_lmax else None,
                  "lmax_mean_delta_bootstrap95_ms": bootstrap_ci(finite_lmax),
                  "lmax_n_finite_paired": len(finite_lmax)}
        for name, values in deltas.items():
            result[f"{name}_mean_delta"] = statistics.mean(values)
            result[f"{name}_mean_delta_bootstrap95"] = bootstrap_ci(values)
        report.append(result)
    with (dest / "uid_summary.json").open("w", encoding="utf-8") as out:
        json.dump(report, out, indent=2, ensure_ascii=False, allow_nan=False)
        out.write("\n")
    for group in report:
        print(f"{group['policy']} phase={group['phase_s']:g} n={group['n_independent_seeds']} "
              f"zero missing={group['zero_missing_runs']} "
              f"Lmax=447.551ms={group['lmax_447_551_ms_runs']} "
              f"rx non diminue={group['rx_unique_non_decreased_runs']}")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result-dir", type=Path, required=True)
    parser.add_argument("--reference-dir", type=Path, required=True)
    args = parser.parse_args()
    compare(args.result_dir, args.reference_dir)


if __name__ == "__main__":
    main()

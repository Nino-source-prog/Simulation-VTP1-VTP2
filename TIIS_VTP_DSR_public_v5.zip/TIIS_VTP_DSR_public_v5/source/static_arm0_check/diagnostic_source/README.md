# Diagnostic DSR ciblé sur la source applicative (ns-3.35, v2)

## Pourquoi cette version

Le pilote ARM=1 du paquet précédent s'est arrêté dans l'analyseur à une
insertion DSR d'adresse `10.1.1.50`. La condition C++ précédente
`ourAdd == src && ackId == 0` appliquait en réalité le traitement à toutes
les origines DSR, y compris le récepteur du flux. Modifier uniquement
l'analyseur aurait accepté cette intervention plus large. Cette version
restreint le changement à `ourAdd == src == sourceAddress`, où
`sourceAddress` est l'adresse attribuée au noeud source du flux étudié.
Ne pas reprendre ni mélanger les résultats ARM=1 du paquet v1 avec v2.
Conserver les dossiers v1 pour documenter l'incident.

## Intervention et portée

ARM=0 utilise le comparateur d'admission historique de ns-3.35. ARM=1
ajoute l'UID de paquet à la comparaison des six champs uniquement lors
de `DsrMaintainBuffer::Enqueue`, pour les entrées `ackId=0` issues de la
source applicative. Les fonctions de retrait du tampon restent inchangées.
Le diagnostic ne prétend pas corriger tous les appariements DSR. Les traces
horodatent les insertions, refus et retraits et enregistrent C(t) et P(t).
P(t) est l'état de route estimé par le scénario à la source, pas une preuve
de connectivité radio ou de chemin géométrique. Le scénario conserve la
porte de disponibilité au niveau de l'application réceptrice.

Le hash de configuration ARM=1 intègre `uidScope=applicationSource-v2` et
l'identifiant de campagne est `dsr-uid-app-source-v2`. ARM=0 garde le hash
et l'identifiant de la campagne de phase v1.1. Le script compare les 167
champs des CSV ARM=0 au même run de référence s'il reçoit REFERENCE_DIR.
Tous les fichiers de sortie v2 utilisent un nouveau dossier et un manifeste
avec les empreintes des fichiers de simulation. Ne pas copier des résultats
v1 dans un dossier v2.

## Installation et pilote

Décompresser `TIIS_dsr_source_uid_app_only_ns3_35_v2.zip` dans
`ns-allinone-3.35`, au même niveau que `ns-3.35` :

```bash
cd /root/ns-allinone-3.35/ns-3.35
bash ../TIIS_dsr_source_uid_app_only_ns3_35_v2/install.sh
```

L'installateur accepte seulement les trois fichiers du paquet UID v1,
ceux du paquet de maintenance précédent, ou ceux de phase v1.1. Il vérifie
les empreintes, sauvegarde les trois fichiers qu'il remplace et laisse
`dsr-routing.cc` inchangé. Si une source locale est différente, il s'arrête.

D'abord, contrôler une parité complète ARM=0 avec ce nouveau binaire :

```bash
ARM=0 OUT_DIR=tiis-uid-appsource-arm0-check-v2 \
RUNS="1" POLICIES="VTP1" PHASES="0" \
REFERENCE_DIR=tiis-phase-all-attempts-v1_1 \
bash ../TIIS_dsr_source_uid_app_only_ns3_35_v2/run_uid_diagnostic.sh
```

Le résultat attendu est une analyse sans exception et la mention
`Parite complete (167 colonnes)`. Puis relancer le pilote ARM=1 dans un
**nouveau** dossier :

```bash
ARM=1 OUT_DIR=tiis-uid-appsource-arm1-pilot-v2 \
REFERENCE_DIR=tiis-phase-all-attempts-v1_1 \
bash ../TIIS_dsr_source_uid_app_only_ns3_35_v2/run_uid_diagnostic.sh
```

Le pilote contient 8 simulations (graines 1, 2 ; VTP1, VTP2 ; phases
0 et 0,0025 s). Il génère `analysis/uid_paired_by_seed.csv` et
`analysis/uid_summary.json`, ainsi que `analysis/<run>/occupancy.csv`,
`rejections.csv`, `missing_first_phy_owners.csv` et `summary.json`.
Examiner la différence appariée des absences de premier PHY, les livraisons
`rx_unique`, le délai et L_max avant toute extension. `link_ack` dans
`summary.json` est le code de retrait de la méthode DSR `LinkEqual` ;
le libellé n'est pas à lui seul une preuve d'ACK MAC.

## Dix graines résiduelles et extension

Les dix graines résiduelles, sous ARM=0, ont été identifiées dans les 120
runs de phase. Si les 40 runs du dossier
`tiis-uid-arm0-ten-v1` sont déjà complets et avec parité, ces traces
observées demeurent valides : ARM=0 v2 ne change pas la logique DSR.
Sinon, produire les 40 traces sous v2 :

```bash
ARM=0 OUT_DIR=tiis-uid-appsource-arm0-ten-v2 \
RUNS="2 5 7 9 11 14 15 25 26 28" \
REFERENCE_DIR=tiis-phase-all-attempts-v1_1 \
bash ../TIIS_dsr_source_uid_app_only_ns3_35_v2/run_uid_diagnostic.sh
```

Après examen du pilote ARM=1 v2, 30 graines par politique à phase 2,5 ms :

```bash
ARM=1 OUT_DIR=tiis-uid-appsource-arm1-30-v2 \
RUNS="$(seq -s ' ' 1 30)" PHASES="0.0025" \
REFERENCE_DIR=tiis-phase-all-attempts-v1_1 \
bash ../TIIS_dsr_source_uid_app_only_ns3_35_v2/run_uid_diagnostic.sh
```

Le traitement peut modifier ultérieurement l'ordre du backoff et le cache
DSR. Une disparition des soumissions sans PHY montrerait l'effet causal
de **cette intervention ciblée dans ce scénario** ; elle ne prouverait pas
que le cadencement n'a aucune autre limite. La prédiction L_max=447,551 ms
est à tester, pas à imposer.

Le CSV principal des 450 runs historiques ne contient pas ces traces de
maintenance. `audit_main450.py` peut valider ses bilans et ses écarts
soumissions–PHY, sans attribuer à la clé UID une cause pour chaque run.

#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# Execute from ns-3.35; run pilot with ARM=0 before ARM=1.
PACKAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCENARIO_FILE="${SCENARIO_FILE:-scratch/vtp-dsr-comparison.cc}"
SCENARIO_RUN="${SCENARIO_FILE%.cc}"
ARM="${ARM:-0}"
OUT_DIR="${OUT_DIR:-tiis-uid-appsource-arm${ARM}-pilot-v2}"
RUNS="${RUNS:-1 2}"
POLICIES="${POLICIES:-VTP1 VTP2}"
PHASES="${PHASES:-0 0.0025}"
REFERENCE_DIR="${REFERENCE_DIR:-}"
die() { printf 'ERREUR: %s\n' "$*" >&2; exit 2; }
[[ "$ARM" == 0 || "$ARM" == 1 ]] || die "ARM doit etre 0 ou 1."
[[ -x ./ns3 || -x ./waf ]] || die "Se placer dans ns-3.35."
[[ "$OUT_DIR" != *' '* && "$OUT_DIR" != *','* && "$OUT_DIR" != *$'\n'* ]] ||
  die "OUT_DIR ne doit contenir ni espace, ni virgule, ni retour ligne."
for i in "$RUNS" "$POLICIES" "$PHASES"; do [[ -n "$i" ]] || die "Grille vide."; done
for run in $RUNS; do
  [[ "$run" =~ ^([1-9]|[12][0-9]|30)$ ]] || die "Numero de run hors 1..30: $run"
done
for policy in $POLICIES; do
  [[ "$policy" == VTP1 || "$policy" == VTP2 ]] || die "Politique invalide: $policy"
done
for phase in $PHASES; do
  [[ "$phase" == 0 || "$phase" == 0.0025 ]] || die "Phase invalide: $phase"
done
[[ -s "$PACKAGE/reference/outage-phases-30.csv" ]] || die "Table des coupures absente."
[[ "$SCENARIO_FILE" == scratch/*.cc && "$SCENARIO_FILE" != *' '* ]] ||
  die "SCENARIO_FILE doit designer un fichier .cc simple sous scratch/."
for pair in "$SCENARIO_FILE|$PACKAGE/src/vtp-dsr-comparison.cc" \
            "src/dsr/model/dsr-routing.h|$PACKAGE/src/dsr-routing.h" \
            "src/dsr/model/dsr-maintain-buff.cc|$PACKAGE/src/dsr-maintain-buff.cc"; do
  cmp -s "${pair%%|*}" "${pair#*|}" || die "Installation incomplete: ${pair%%|*}"
done
[[ "$(sha256sum src/dsr/model/dsr-routing.cc | cut -d' ' -f1)" == \
   091168646aba76142592eca1d1f01bb82db1880a0a141eeb1523de4925c632b6 ]] ||
  die "dsr-routing.cc inattendu."
[[ -z "$REFERENCE_DIR" || -d "$REFERENCE_DIR/runs" ]] ||
  die "REFERENCE_DIR doit contenir runs/*.csv de la campagne de phase precedente."

mkdir -p "$OUT_DIR/runs" "$OUT_DIR/packet" "$OUT_DIR/maintain" "$OUT_DIR/logs" "$OUT_DIR/analysis"
manifest_tmp="$(mktemp)"
trap 'rm -f -- "$manifest_tmp"' EXIT
{
  echo 'experiment=dsr-app-source-uid-admission-v2;receiver-app-gate;ns-3.35'
  echo "arm=$ARM;runs=$RUNS;policies=$POLICIES;phases=$PHASES"
  echo "scenario_sha256=$(sha256sum "$SCENARIO_FILE" | cut -d' ' -f1)"
  echo "phase_table_sha256=$(sha256sum "$PACKAGE/reference/outage-phases-30.csv" | cut -d' ' -f1)"
  find src/dsr/model -maxdepth 1 -type f \( -name '*.cc' -o -name '*.h' \) \
    -print0 | sort -z | xargs -0 sha256sum
} > "$manifest_tmp"
if [[ -e "$OUT_DIR/manifest.txt" ]]; then
  cmp -s "$manifest_tmp" "$OUT_DIR/manifest.txt" || die "Manifeste different; utiliser un autre OUT_DIR."
elif find "$OUT_DIR/runs" "$OUT_DIR/packet" "$OUT_DIR/maintain" "$OUT_DIR/logs" \
    -type f -print -quit | grep -q .; then
  die "Sorties orphelines sans manifeste."
else
  cp -- "$manifest_tmp" "$OUT_DIR/manifest.txt"
fi

if [[ -x ./ns3 ]]; then ./ns3 build; else ./waf build; fi
for run in $RUNS; do
  outage_phase="$(awk -F, -v n="$run" 'NR>1 && $1==n {print $2;exit}' "$PACKAGE/reference/outage-phases-30.csv")"
  [[ -n "$outage_phase" ]] || die "Phase de coupure absente pour run=$run"
  for policy in $POLICIES; do
    for phase in $PHASES; do
      stem="speed0-run${run}-${policy}-phase${phase}"
      main="$OUT_DIR/runs/$stem.csv"
      packet="$OUT_DIR/packet/$stem.csv"
      maintain="$OUT_DIR/maintain/$stem.csv"
      log="$OUT_DIR/logs/$stem.log"
      if [[ -s "$main" && -s "$packet" && -s "$maintain" && -s "$log" ]]; then
        echo "SKIP $stem"
      else
        for path in "$main" "$packet" "$maintain" "$log"; do
          [[ ! -e "$path" && ! -e "${path}.partial" ]] ||
            die "Run incomplet: $stem. Conserver les fichiers pour inspection."
        done
        echo "RUN $stem (outagePhase=$outage_phase)"
        campaign_id=phase-v1_1
        [[ "$ARM" == 0 ]] || campaign_id=dsr-uid-app-source-v2
        args="--policy=$policy --speed=0 --run=$run --seed=12345 --campaignId=$campaign_id --dsrSourceUidKey=$ARM --out=${main}.partial --packetTraceOut=${packet}.partial --maintainTraceOut=${maintain}.partial --scenario=full-independent --physicalChannelOutage=0 --forceRouteAvailable=0 --outStart=50 --outagePhase=$outage_phase --onDur=20 --offDur=10 --cycles=5 --recoveryPacing=0.005 --recoveryPhase=$phase --nodes=50 --pause=2 --areaX=500 --areaY=500 --range=300 --simTime=300 --appStart=10 --appStopMargin=35 --pktSize=512 --interval=0.1 --rto=1 --rtoMax=16 --lifetime=30 --maxAttempts=7 --routePoll=0.02 --dsrGrace=0.20 --graphPathDiagnostic=0 --graphPoll=0.10"
        if [[ -x ./ns3 ]]; then
          ./ns3 run "$SCENARIO_RUN $args" > "${log}.partial" 2>&1 || {
            tail -40 "${log}.partial" >&2; die "Run echoue: $stem";
          }
        else
          ./waf --run "$SCENARIO_RUN $args" > "${log}.partial" 2>&1 || {
            tail -40 "${log}.partial" >&2; die "Run echoue: $stem";
          }
        fi
        [[ -s "${main}.partial" && -s "${packet}.partial" && -s "${maintain}.partial" ]] ||
          die "Trace manquante: $stem"
        mv -- "${main}.partial" "$main"
        mv -- "${packet}.partial" "$packet"
        mv -- "${maintain}.partial" "$maintain"
        mv -- "${log}.partial" "$log"
      fi
      analyze_args=(--maintain "$maintain" --packet "$packet" --out-dir "$OUT_DIR/analysis/$stem")
      [[ "$ARM" == 0 ]] || analyze_args+=(--source-uid-key)
      python3 "$PACKAGE/analyze_maintenance.py" "${analyze_args[@]}"
      if [[ -n "$REFERENCE_DIR" && "$ARM" == 0 ]]; then
        python3 - "$main" "$REFERENCE_DIR/runs/$stem.csv" <<'PY' || die "Parite ancienne campagne echouee: $stem"
import csv, sys
from pathlib import Path
actual, ref = [list(csv.DictReader(Path(p).open(newline=""))) for p in sys.argv[1:]]
if len(actual) != 1 or len(ref) != 1 or actual[0] != ref[0]:
    changed = sorted(k for k in (actual[0].keys() & ref[0].keys())
                     if actual[0][k] != ref[0][k]) if actual and ref else []
    raise SystemExit(f"CSV principal different: {changed[:20]}")
print(f"Parite complete ({len(actual[0])} colonnes) avec la campagne de phase precedente.")
PY
      fi
    done
  done
done
if [[ "$ARM" == 1 && -n "$REFERENCE_DIR" ]]; then
  python3 "$PACKAGE/compare_uid_arm.py" --result-dir "$OUT_DIR" \
    --reference-dir "$REFERENCE_DIR"
fi
echo "Termine: $OUT_DIR"

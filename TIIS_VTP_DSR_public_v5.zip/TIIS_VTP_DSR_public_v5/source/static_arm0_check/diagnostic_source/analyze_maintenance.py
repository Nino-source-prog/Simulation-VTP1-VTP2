#!/usr/bin/env python3
"""Reconstitue l'occupation de chaque cle DSR et identifie l'entree bloquante.

Ne transforme jamais une entree encore presente en une duree de residence finie.
"""

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path


FIELDS = ["time_ns", "code", "our_addr", "next_hop", "src_addr",
          "dst_addr", "ack_id", "segs_left", "subject_uid", "subject_seq",
          "subject_attempt", "resident_uid", "resident_seq", "resident_attempt",
          "C", "P"]
KEY = ["our_addr", "next_hop", "src_addr", "dst_addr", "ack_id", "segs_left"]
REASONS = {1: "insert", 2: "duplicate_reject", 3: "capacity_eviction",
           4: "drop_next_hop", 5: "dequeue", 6: "exact_match",
           7: "network_ack", 8: "passive_ack", 9: "link_ack", 10: "expired"}
OUT_FIELDS = ["time_ns", *KEY, "attempt_uid", "attempt_seq", "attempt_id",
              "owner_uid", "owner_seq", "owner_attempt", "owner_insert_ns",
              "occupied_before_reject_ns", "owner_remove_ns",
              "remaining_until_remove_ns", "owner_remove_reason", "owner_censored",
              "P_at_reject", "route_down_after_reject_ns",
              "first_phy_for_attempt", "missing_first_phy_for_attempt"]
OCC_FIELDS = [*KEY, "owner_uid", "owner_seq", "owner_attempt",
              "insert_ns", "remove_ns", "residence_ns", "remove_reason",
              "P_at_insert", "P_at_remove", "route_down_overlap_ns",
              "route_down_fraction", "censored", "duplicate_rejections_while_present"]


def read_csv(path, fields):
    with Path(path).open(newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        if reader.fieldnames != fields:
            raise ValueError(f"Schema inattendu dans {path}: {reader.fieldnames}")
        yield from reader


def write_csv(path, rows, fields):
    with Path(path).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def analyze(maintain_path, packet_path, out_dir, source_address, source_uid_key=False):
    path_fields = ["time_ns", "event", "node", "seq", "attempt_id",
                   "retransmission", "detail", "C", "P"]
    submit, first_phy, path_rejected = set(), set(), Counter()
    route_states = []
    last_packet_time = 0
    for row in read_csv(packet_path, path_fields):
        last_packet_time = max(last_packet_time, int(row["time_ns"]))
        if row["event"] in {"route_state_initial", "route_state_up", "route_state_down"}:
            route_states.append((int(row["time_ns"]), int(row["P"]), row["event"]))
        identity = (row["seq"], row["attempt_id"])
        if row["event"] == "transport_submit":
            if identity in submit:
                raise ValueError(f"Soumission transport dupliquee: {identity}")
            submit.add(identity)
        elif row["event"] == "phy_first":
            first_phy.add(identity)
        elif row["event"] == "dsr_maintain_rejected":
            path_rejected[(row["time_ns"], *identity)] += 1
    missing = submit - first_phy
    if first_phy - submit:
        raise ValueError("Premier PHY sans soumission")
    if not route_states or route_states[0][2] != "route_state_initial":
        raise ValueError("Transition initiale de la route absente")

    active = {}
    occupancy, rejections, source_rejected = [], [], Counter()
    event_count = Counter()
    max_same_six_concurrent_source = 0
    distinct_source_uid_admissions = 0
    last_time = -1
    for row in read_csv(maintain_path, FIELDS):
        t, code = int(row["time_ns"]), int(row["code"])
        if t < last_time or code not in REASONS:
            raise ValueError(f"Chronologie ou code de maintenance invalide: {row}")
        last_time = t
        event_count[REASONS[code]] += 1
        base_key = tuple(row[field] for field in KEY)
        is_source_passive = (source_uid_key and
                             row["our_addr"] == source_address and
                             row["src_addr"] == source_address and
                             row["ack_id"] == "0")
        # Le traitement ne change que l'admission au point source; un
        # retrait est toujours associe au paquet effectivement retire.
        key = base_key + (row["subject_uid"],) if is_source_passive else base_key
        if code == 1:
            if key in active:
                raise ValueError(f"Insertion sans retrait pour la meme cle: {row}")
            if is_source_passive:
                already = sum(active_key[:6] == base_key for active_key in active)
                distinct_source_uid_admissions += int(already > 0)
                max_same_six_concurrent_source = max(max_same_six_concurrent_source,
                                                     already + 1)
            item = {**{field: row[field] for field in KEY},
                    "owner_uid": row["subject_uid"],
                    "owner_seq": row["subject_seq"],
                    "owner_attempt": row["subject_attempt"],
                    "insert_ns": t, "remove_ns": "", "residence_ns": "",
                    "remove_reason": "", "P_at_insert": int(row["P"]),
                    "P_at_remove": "", "route_down_overlap_ns": "",
                    "route_down_fraction": "", "censored": 1,
                    "duplicate_rejections_while_present": 0}
            active[key] = {"item": item, "rejections": []}
            occupancy.append(item)
        elif code == 2:
            if key not in active:
                raise ValueError(f"Refus sans cle preexistante: {row}")
            owner = active[key]["item"]
            if (row["resident_uid"] and owner["owner_uid"] and
                    row["resident_uid"] != owner["owner_uid"]):
                raise ValueError(f"UID du resident non apparie: {row} vs {owner}")
            if is_source_passive and row["resident_uid"] != row["subject_uid"]:
                raise ValueError(f"Refus UID mal explique a la source: {row}")
            if (row["resident_seq"] and owner["owner_seq"] and
                    (row["resident_seq"], row["resident_attempt"]) !=
                    (owner["owner_seq"], owner["owner_attempt"])):
                raise ValueError(f"Tags du resident non apparies: {row} vs {owner}")
            attempt = (row["subject_seq"], row["subject_attempt"])
            item = {"time_ns": t, **{field: row[field] for field in KEY},
                    "attempt_uid": row["subject_uid"],
                    "attempt_seq": row["subject_seq"],
                    "attempt_id": row["subject_attempt"],
                    "owner_uid": owner["owner_uid"],
                    "owner_seq": owner["owner_seq"],
                    "owner_attempt": owner["owner_attempt"],
                    "owner_insert_ns": owner["insert_ns"],
                    "occupied_before_reject_ns": t - owner["insert_ns"],
                    "owner_remove_ns": "", "remaining_until_remove_ns": "",
                    "owner_remove_reason": "", "owner_censored": 1,
                    "P_at_reject": int(row["P"]),
                    "route_down_after_reject_ns": "",
                    "first_phy_for_attempt": int(attempt in first_phy),
                    "missing_first_phy_for_attempt": int(attempt in missing)}
            rejections.append(item)
            active[key]["rejections"].append(item)
            owner["duplicate_rejections_while_present"] += 1
            if row["our_addr"] == source_address:
                if not all(attempt):
                    raise ValueError(f"Tags source absents sur un rejet: {row}")
                source_rejected[(row["time_ns"], *attempt)] += 1
        else:
            if key not in active:
                raise ValueError(f"Retrait sans insertion appariee: {row}")
            record = active.pop(key)
            owner = record["item"]
            if row["subject_uid"] and owner["owner_uid"] and \
                    row["subject_uid"] != owner["owner_uid"]:
                raise ValueError(f"UID du retrait non apparie: {row} vs {owner}")
            owner.update(remove_ns=t, residence_ns=t - owner["insert_ns"],
                         remove_reason=REASONS[code], P_at_remove=int(row["P"]),
                         censored=0)
            for rejected in record["rejections"]:
                rejected.update(owner_remove_ns=t, remaining_until_remove_ns=t - rejected["time_ns"],
                                owner_remove_reason=REASONS[code], owner_censored=0)
    if source_rejected != path_rejected:
        missing_from_buffer = list((path_rejected - source_rejected).items())[:5]
        extra_buffer = list((source_rejected - path_rejected).items())[:5]
        raise ValueError(f"Rejets source non apparies aux traces DsrPathEvent: "
                         f"absents={missing_from_buffer}; en_trop={extra_buffer}")

    # La borne finale ne sert qu'a fermer un intervalle P=0 pour des entrees
    # retirees avant la fin des traces. Aucune residence censuree n'est fermee.
    trace_end = max(last_packet_time, last_time)
    route_down = []
    previous_time, previous_state, _ = route_states[0]
    for state_time, state, label in route_states[1:]:
        if state_time < previous_time or state == previous_state or \
                (label == "route_state_up") != bool(state):
            raise ValueError(f"Transition P incoherente: {state_time}/{label}/{state}")
        if previous_state == 0:
            route_down.append((previous_time, state_time))
        previous_time, previous_state = state_time, state
    if previous_state == 0:
        route_down.append((previous_time, trace_end))

    def down_overlap(start, stop):
        return sum(max(0, min(stop, end) - max(start, begin))
                   for begin, end in route_down)

    for record in occupancy:
        if record["remove_ns"] != "" and record["our_addr"] == source_address:
            delta = down_overlap(record["insert_ns"], record["remove_ns"])
            record["route_down_overlap_ns"] = delta
            record["route_down_fraction"] = (delta / record["residence_ns"]
                                             if record["residence_ns"] else 0.0)
    for rejected in rejections:
        if rejected["owner_remove_ns"] != "" and rejected["our_addr"] == source_address:
            rejected["route_down_after_reject_ns"] = down_overlap(
                rejected["time_ns"], rejected["owner_remove_ns"])

    out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(out_dir / "occupancy.csv", occupancy, OCC_FIELDS)
    write_csv(out_dir / "rejections.csv", rejections, OUT_FIELDS)
    without_phy = [row for row in rejections if row["our_addr"] == source_address
                   and row["missing_first_phy_for_attempt"]]
    write_csv(out_dir / "missing_first_phy_owners.csv", without_phy, OUT_FIELDS)
    summary = {"transport_submissions": len(submit), "first_phy": len(first_phy),
               "source_uid_key_enabled": int(source_uid_key),
               "route_down_intervals_observed": len(route_down),
               "max_same_six_concurrent_source": max_same_six_concurrent_source,
               "distinct_source_uid_admissions": distinct_source_uid_admissions,
               "missing_first_phy": len(missing),
               "source_rejected_events": sum(source_rejected.values()),
               "source_missing_with_owner": len({(r["attempt_seq"], r["attempt_id"])
                                                 for r in without_phy}),
               "source_missing_without_owner": len(missing -
                   {(r["attempt_seq"], r["attempt_id"]) for r in without_phy}),
               "accepted_entries_all_nodes": event_count["insert"],
               "censored_entries_all_nodes": len(active),
               "maintenance_event_counts_all_nodes": dict(event_count),
               "retirement_reasons_for_source_missing":
                   dict(Counter(r["owner_remove_reason"] or "censored"
                                for r in without_phy))}
    with (out_dir / "summary.json").open("w", encoding="utf-8") as stream:
        json.dump(summary, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--maintain", type=Path, required=True)
    parser.add_argument("--packet", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--source-address", default="10.1.1.1")
    parser.add_argument("--source-uid-key", action="store_true")
    args = parser.parse_args()
    result = analyze(args.maintain, args.packet, args.out_dir,
                     args.source_address, args.source_uid_key)
    print(f"DSR: {result['maintenance_event_counts_all_nodes']}; "
          f"source sans PHY/entree identifiee: "
          f"{result['source_missing_with_owner']}/{result['missing_first_phy']}")


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
set -euo pipefail

# Depuis ns-3.35; accepte la phase v1.1, la trace de maintenance v1
# ou le premier bras UID v1. Refuse les etats partiellement modifies.
PACKAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
die() { printf 'ERREUR: %s\n' "$*" >&2; exit 2; }
[[ -x ./ns3 || -x ./waf ]] || die "Se placer dans ns-3.35."
[[ -s src/dsr/model/dsr-routing.cc ]] || die "DSR absent."
[[ "$(sha256sum src/dsr/model/dsr-routing.cc | cut -d' ' -f1)" == \
   091168646aba76142592eca1d1f01bb82db1880a0a141eeb1523de4925c632b6 ]] ||
   die "dsr-routing.cc different de la version de phase v1.1."
cd "$PACKAGE"
sha256sum -c SHA256SUMS.txt || die "Paquet modifie."
cd - >/dev/null
targets=(scratch/vtp-dsr-comparison.cc \
         src/dsr/model/dsr-routing.h \
         src/dsr/model/dsr-maintain-buff.cc)
sources=("$PACKAGE/src/vtp-dsr-comparison.cc" \
         "$PACKAGE/src/dsr-routing.h" \
         "$PACKAGE/src/dsr-maintain-buff.cc")
previous_maintain=(33bda24e3d41f348eb7112bdda996421c151cb7c786fbe7345df1805053d9874 \
          46694e370cdbe1f599c0ed09125347f3fd3215309b49e383ea8e0989d6c3e131 \
          faf094ec47e97b1adc4a39c03d1d2a247cbd71c41d06ebfb2564fa938e8e5fe4)
previous_phase=(37aaa3a4726ef4c0d99ee1529891f5cec493161345b821a68a8a5c9f34986e1f \
                c576a21ccbe46dee588184968e077af7618f9a8621d1ad8a99091629cadb87f7 \
                45cba91ef599e12b8eddb9b273a6fe27c41a9329dcafcb3138d96db7ed3318b2)
previous_uid=(39856c14e90bbd62cce6f8da016ecefd8849c035897bd08640841c8680d5e24b \
              cd12a51db62bce4cb5d6b12db924f1efa1a3f173849cb1611538f8427f1d852f \
              c95ea64d76edf6c86e2bbb4179f7153cb773d923f18a5e1706cd5940a175f330)
all_maintain=1; all_phase=1; all_uid=1; all_new=1
for i in 0 1 2; do
  [[ -s "${targets[i]}" ]] || die "Fichier manquant: ${targets[i]}"
  current="$(sha256sum "${targets[i]}" | cut -d' ' -f1)"
  [[ "$current" == "${previous_maintain[i]}" ]] || all_maintain=0
  [[ "$current" == "${previous_phase[i]}" ]] || all_phase=0
  [[ "$current" == "${previous_uid[i]}" ]] || all_uid=0
  cmp -s "${targets[i]}" "${sources[i]}" || all_new=0
done
if (( all_new )); then echo 'Bras UID cible v2 deja installe.'; exit 0; fi
(( all_maintain || all_phase || all_uid )) ||
  die "Source locale inconnue/melangee; aucun remplacement."
for i in 0 1 2; do
  [[ ! -e "${targets[i]}.before-source-uid-v2.bak" ]] ||
     die "Sauvegarde deja presente: ${targets[i]}.before-source-uid-v2.bak"
done
for i in 0 1 2; do
  cp -p -- "${targets[i]}" "${targets[i]}.before-source-uid-v2.bak"
  cp -- "${sources[i]}" "${targets[i]}"
done
echo 'Bras UID cible v2 installe; DSR standard reste disponible avec --dsrSourceUidKey=0.'

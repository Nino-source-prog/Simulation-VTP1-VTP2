#!/usr/bin/env bash
set -euo pipefail

# Execute from an already configured ns-3.35 tree with the exact UID-v2 DSR
# instrumentation. Stage the known diagnostic scenario under a separate name.
PACKAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIAG="$PACKAGE/diagnostic_source"
[[ -x ./ns3 || -x ./waf ]] || {
  echo 'Se placer dans ns-3.35 (./ns3 ou ./waf requis).' >&2; exit 2;
}
OUT_DIR="${OUT_DIR:-tiis-static-run1-arm0-maintenance}"
[[ "$OUT_DIR" != /* ]] || {
  echo 'OUT_DIR doit etre relatif a la racine ns-3.35.' >&2; exit 2;
}
expected_routing_cc=091168646aba76142592eca1d1f01bb82db1880a0a141eeb1523de4925c632b6
expected_routing_h=acfb0685b0719285786d1341ac27067617a7e651661b4a7f52e4fd1a0d291680
expected_maintain=c4e53c9b08b8dde7eb33b8ac2fb44e372fce4e0210bd6d847b728f053c2ee500
for triple in \
  "src/dsr/model/dsr-routing.cc|$expected_routing_cc" \
  "src/dsr/model/dsr-routing.h|$expected_routing_h" \
  "src/dsr/model/dsr-maintain-buff.cc|$expected_maintain"; do
  path="${triple%%|*}"; expected="${triple#*|}"
  [[ -f "$path" ]] || { echo "Fichier DSR absent: $path" >&2; exit 2; }
  actual="$(sha256sum "$path" | cut -d' ' -f1)"
  if [[ "$actual" != "$expected" ]]; then
    echo "Source DSR differente: $path" >&2
    echo "observe: $actual" >&2
    echo "attendu: $expected" >&2
    echo 'Aucun fichier du simulateur ne sera remplace.' >&2
    exit 2
  fi
done
SCENARIO_FILE=scratch/vtp-dsr-static-arm0.cc
if [[ -e "$SCENARIO_FILE" ]]; then
  cmp -s "$SCENARIO_FILE" "$DIAG/src/vtp-dsr-comparison.cc" || {
    echo "Scenario deja present mais different: $SCENARIO_FILE" >&2; exit 2;
  }
else
  cp -- "$DIAG/src/vtp-dsr-comparison.cc" "$SCENARIO_FILE"
fi
ARM=0 OUT_DIR="$OUT_DIR" RUNS="1" POLICIES="VTP1 VTP2" PHASES="0" \
REFERENCE_DIR="${REFERENCE_DIR:-}" SCENARIO_FILE="$SCENARIO_FILE" \
  bash "$DIAG/run_uid_diagnostic.sh"
python3 "$PACKAGE/audit_static_arm0.py" --result-dir "$OUT_DIR" \
  --output "$OUT_DIR/analysis/static_arm0_50_check.json"

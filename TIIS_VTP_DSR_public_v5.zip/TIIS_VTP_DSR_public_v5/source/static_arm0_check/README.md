# Vérification DSR ARM=0 — run statique 1

**Question :** les 50 tentatives cadencées sans premier événement PHY dans
`full-independent`, 0 m/s, run RNG 1, (T=5) ms, correspondent-elles à des
refus d'admission dans `DsrMaintainBuffer` ? Le refus de DATA est imposé à
l'application réceptrice ; la radio et le routage DSR restent actifs.

## Ce qui est déjà vérifié

La trace de phase `phase-v1_1`, run 1, `recoveryPhase=0`, utilise le comparateur
historique (ARM=0). Ses 3 099 soumissions, 3 049 premiers PHY et 450
libérations cadencées ont **exactement les mêmes événements, identifiants et
horodatages** que le run statique 1 de référence pour VTP1 et VTP2, malgré des
identifiants de campagne et empreintes de configuration différents. Les
principales métriques du CSV correspondent également.

Pour chaque politique, les 50 tentatives sans premier PHY sont les mêmes
50 tentatives que les événements `dsr_maintain_rejected`, toutes issues
d'une `paced_release`, au second attempt, `C=1`, `P=1`. Il y en a dix par
épisode, toutes exactement 1 µs après une autre soumission. Le résultat de
ce précontrôle est dans `preexisting_packet_check.json`. Cette trace de
parcours DSR identifie le refus, mais **ne donne pas les six champs de la clé
de maintenance ni l'entrée résidente** qui occupait cette clé.

## Relance avec la trace complète de maintenance

Cette archive contient la source diagnostique `app_only_ns3_35_v2`, ses
analyseurs et les traces statiques originales nécessaires au contrôle
événement par événement. La présente révision du lanceur accepte un scénario
comparatif plus récent dans `scratch/` : elle place le scénario diagnostique
sous le nom distinct `scratch/vtp-dsr-static-arm0.cc`, sans remplacer le
scénario déjà installé. Elle exige toutefois les trois fichiers DSR de la
version UID source v2, dont les empreintes sont contrôlées avant compilation.
Extraire ce dossier à côté de `ns-3.35` et, depuis le dossier `ns-3.35` :

```bash
cd /root/ns-allinone-3.35/ns-3.35
REFERENCE_DIR=tiis-phase-all-attempts-v1_1 \
  bash ../TIIS_static_ARM0_check_2026-10-31/run_static_arm0.sh
```

`REFERENCE_DIR` est recommandé s'il contient les résultats de la campagne de
phase v1.1 : le lanceur exige alors la parité exacte des 167 colonnes du
nouveau CSV principal. Si ce dossier n'est pas présent, omettre la variable :

```bash
bash ../TIIS_static_ARM0_check_2026-10-31/run_static_arm0.sh
```

Le lanceur conserve la logique DSR historique (`--dsrSourceUidKey=0`) et
fixe `RUNS=1`, `POLICIES="VTP1 VTP2"`, `PHASES=0`, vitesse 0, porte
réceptrice de 10 s, 5 épisodes, génération toutes les 100 ms et (T=5) ms.
Il vérifie les fichiers DSR et la source diagnostique, compile, puis
enregistre `runs/`, `packet/`, `maintain/` et `analysis/` dans
`tiis-static-run1-arm0-maintenance/`. Un répertoire préexistant doit avoir
un manifeste identique et des fichiers complets ; aucune sortie partielle
n'est silencieusement remplacée. On peut choisir un nouveau `OUT_DIR`.
Si les fichiers DSR ne correspondent pas, le script affiche leurs SHA-256
et s'arrête sans modifier l'installation. Ne pas contourner cette garde en
copiant les fichiers DSR à la main : ils peuvent appartenir à un autre
profil de simulation.

L'ancienne édition de ce paquet appelait directement l'installateur UID v2,
qui exigeait que le scénario courant appartienne au même ensemble que les
fichiers DSR. Elle pouvait donc s'arrêter avec « Source locale
inconnue/mélangée » lorsque seul le scénario `scratch/` avait été remplacé
par un banc plus récent. Cette révision laisse ce scénario en place.

Le contrôle final produit
`tiis-static-run1-arm0-maintenance/analysis/static_arm0_50_check.json`.
Pour chaque politique, le critère d'une confirmation complète est :

- `missing = same_attempt_dsr_rejections = paced_missing = 50` ;
- `resident_entry_proven = 50`, après appariement des six champs, de l'UID
  et de l'insertion de chaque entrée résidente par `analyze_maintenance.py` ;
- `source_missing_without_owner = 0` dans chaque `summary.json` ;
- parité des événements et horodatages avec les deux traces statiques fixes.

Lire également `analysis/speed0-run1-{VTP1,VTP2}-phase0/` :
`missing_first_phy_owners.csv` donne pour chaque refus la clé, la tentative,
le propriétaire réellement trouvé, sa durée d'occupation et le retrait
observé (ou une résidence censurée). Un échec de l'une des assertions doit
être conservé comme résultat, sans convertir une absence de preuve en
confirmation. Ce contrôle identifie une cause dans **ce run statique** ; il
ne démontre pas la même cause pour les cas sévères mobiles.

Le simulateur ns-3.35 n'est pas présent dans l'environnement utilisé pour
préparer ce paquet. Le précontrôle ci-dessus provient des traces déjà
fournies ; les colonnes de résidence ne seront renseignées qu'après cette
relance sur l'installation ns-3.35 de l'étude.

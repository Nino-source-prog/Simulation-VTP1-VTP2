#!/usr/bin/env python3
"""Build four audited ns-3.35 scenario variants from immutable local inputs."""

from pathlib import Path
import hashlib

PACKAGE = Path(__file__).resolve().parent
INPUTS = {
    "gap": ("reference/source_baselines/gap.cc",
            "603e35d39cda7d1e26f1b955ad0533e06805de1a58c40c82c48f80f139eba13f"),
    "gap_episodes": ("reference/source_baselines/gap_episodes.cc",
                     "e2a0080760ba83bab66862f467df7c47b8e482dfe6a89a237f912aaefde3f3c7"),
    "v1_1": ("reference/source_baselines/v1_1.cc",
             "16e7a1dffbd192dcee3129ff5c7eb5ed8a49b6bb7700c997007739f0b1ee7a7e"),
    "v1_1_episodes": ("reference/source_baselines/v1_1_episodes.cc",
                      "13ec28661b136ee4a52956bcd983d979052db23534d0ec1da927846dfd28f939"),
}


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise ValueError(f"Expected exactly one match ({source.count(old)}): {old[:100]!r}")
    return source.replace(old, new)


for name, (relative, expected_sha) in INPUTS.items():
    src = PACKAGE / relative
    raw = src.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_sha:
        raise ValueError(f"Input was modified unexpectedly: {src}")
    s = raw.decode("utf-8")
    s = replace_once(s, '  std::string campaignId = "manual";\n', '''  std::string campaignId = "manual";
  // ns-3.35 Wi-Fi radio-energy reference profile, explicitly pinned.
  const std::string energyProfile = "ns3-wifi-reference-3v-v1";
  const double radioVoltageV = 3.0;
  const double initialEnergyJ = 1000.0;
  const double iIdleA = 0.273;
  const double iCcaBusyA = 0.273;
  const double iTxA = 0.380;
  const double iRxA = 0.313;
  const double iSwitchingA = 0.273;
  const double iSleepA = 0.033;
''')
    s = replace_once(s, '    << "schema=4.6"\n', '    << "schema=4.7"\n')
    s = replace_once(s, '    << "|graphPoll=" << CanonicalDouble (graphPoll);', '''    << "|graphPoll=" << CanonicalDouble (graphPoll)
    << "|energyProfile=" << energyProfile
    << "|voltageV=" << CanonicalDouble (radioVoltageV)
    << "|initialEnergyJ=" << CanonicalDouble (initialEnergyJ)
    << "|idleA=" << CanonicalDouble (iIdleA)
    << "|ccaBusyA=" << CanonicalDouble (iCcaBusyA)
    << "|txA=" << CanonicalDouble (iTxA)
    << "|rxA=" << CanonicalDouble (iRxA)
    << "|switchingA=" << CanonicalDouble (iSwitchingA)
    << "|sleepA=" << CanonicalDouble (iSleepA);''')
    s = replace_once(s, '''  energyHelper.Set ("BasicEnergySourceInitialEnergyJ", DoubleValue (1000.0));
  EnergySourceContainer energySources = energyHelper.Install (nodes);

  WifiRadioEnergyModelHelper radioEnergy;
  radioEnergy.Set ("TxCurrentA", DoubleValue (0.0174));
  radioEnergy.Set ("RxCurrentA", DoubleValue (0.0197));
  radioEnergy.Set ("IdleCurrentA", DoubleValue (0.0002));
  radioEnergy.Install (devices, energySources);''', '''  energyHelper.Set ("BasicEnergySourceInitialEnergyJ", DoubleValue (initialEnergyJ));
  energyHelper.Set ("BasicEnergySupplyVoltageV", DoubleValue (radioVoltageV));
  EnergySourceContainer energySources = energyHelper.Install (nodes);

  WifiRadioEnergyModelHelper radioEnergy;
  radioEnergy.Set ("IdleCurrentA", DoubleValue (iIdleA));
  radioEnergy.Set ("CcaBusyCurrentA", DoubleValue (iCcaBusyA));
  radioEnergy.Set ("TxCurrentA", DoubleValue (iTxA));
  radioEnergy.Set ("RxCurrentA", DoubleValue (iRxA));
  radioEnergy.Set ("SwitchingCurrentA", DoubleValue (iSwitchingA));
  radioEnergy.Set ("SleepCurrentA", DoubleValue (iSleepA));
  radioEnergy.Install (devices, energySources);''')
    s = replace_once(s, '"diagnostic_version,campaign_id,configuration_hash,scenario,policy,"',
                     '"diagnostic_version,campaign_id,energy_profile,configuration_hash,scenario,policy,"')
    s = replace_once(s, 'states << "1," << campaignId << \',\' << configurationHash << \',\'\n',
                     'states << "2," << campaignId << \',\' << energyProfile << \',\'\n                 << configurationHash << \',\'\n')
    s = replace_once(s, '"schema_version,campaign_id,configuration_hash,outage_schedule_hash,"',
                     '"schema_version,campaign_id,energy_profile,configuration_hash,outage_schedule_hash,"')
    s = replace_once(s, '  csv << "4.6" << \',\' << campaignId << \',\' << configurationHash << \',\'\n',
                     '  csv << "4.7" << \',\' << campaignId << \',\' << energyProfile << \',\'\n      << configurationHash << \',\'\n')
    out = PACKAGE / 'src' / f'vtp-dsr-comparison-{name}.cc'
    out.write_text(s, encoding='utf-8')
    print(f'{name}: {expected_sha} -> {hashlib.sha256(out.read_bytes()).hexdigest()}')

#!/usr/bin/env bash
set -euo pipefail

# Run from ns-3.35 (inside ns-allinone-3.35), keeping the installed DSR patch.
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="scratch/vtp-dsr-comparison.cc"
if [[ -x ./ns3 ]]; then
  RUNNER='./ns3'
elif [[ -x ./waf ]]; then
  RUNNER='./waf'
else
  echo "Aucun lanceur ./ns3 ou ./waf executable dans: $PWD" >&2
  echo 'Se placer dans la racine ns-allinone-3.35/ns-3.35.' >&2
  exit 2
fi
[[ -d src/dsr/model ]] || { echo "Dossier DSR absent dans: $PWD" >&2; exit 2; }
if [[ ! -f "$TARGET" ]]; then
  echo "Scenario absent: $PWD/$TARGET" >&2
  echo 'Installer le scenario instrumente vtp-dsr-comparison.cc dans scratch/.' >&2
  echo 'Fichiers vtp-dsr actuellement dans scratch/ :' >&2
  find scratch -maxdepth 1 -type f -name '*vtp*dsr*' -print >&2
  exit 2
fi
[[ -f src/dsr/model/dsr-routing.cc ]] || { echo 'dsr-routing.cc introuvable.' >&2; exit 2; }

CURRENT="$(sha256sum "$TARGET" | cut -d' ' -f1)"
case "$CURRENT" in
  603e35d39cda7d1e26f1b955ad0533e06805de1a58c40c82c48f80f139eba13f) variant=gap ;;
  e2a0080760ba83bab66862f467df7c47b8e482dfe6a89a237f912aaefde3f3c7) variant=gap_episodes ;;
  16e7a1dffbd192dcee3129ff5c7eb5ed8a49b6bb7700c997007739f0b1ee7a7e) variant=v1_1 ;;
  13ec28661b136ee4a52956bcd983d979052db23534d0ec1da927846dfd28f939) variant=v1_1_episodes ;;
  f9b9c312653b6ab2dcb149c81ef7ec7bad2fc2ee6227d2b55b05dcc6e08aae99|d0340669e1aec91d1e923c516310a1d994ab073cfa0e7f4ff1ecb7185e633a1f|5c91fc187e7592259814a187bf6c3d9c5a078a5502ab9eac7536c327c7e3ca58|e82b2232fadd650ebe0ff40602c9cdd452bbe206b4e0b27c8007ec5518667396)
    echo "Profil energetique deja installe: $CURRENT"; exit 0 ;;
  *)
    echo "Source inconnue ($CURRENT): refus d'ecraser les modifications locales." >&2
    echo 'Conserver ce fichier et adapter le petit correctif du README manuellement.' >&2
    exit 2 ;;
esac

SOURCE="$PACKAGE_DIR/src/vtp-dsr-comparison-${variant}.cc"
[[ -s "$SOURCE" ]] || { echo "Source absente: $SOURCE" >&2; exit 2; }
cp -p -- "$TARGET" "${TARGET}.before-energy-${CURRENT:0:12}.bak"
cp -- "$SOURCE" "$TARGET"
echo "Scenario installe ($variant), ancien fichier sauvegarde: ${TARGET}.before-energy-${CURRENT:0:12}.bak"
echo "DSR inchange. Compiler: $RUNNER build"

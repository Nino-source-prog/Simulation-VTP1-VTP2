#!/usr/bin/env python3
"""Audit and summarize the TIIS ns-3.35 energy campaign (Python standard library)."""

import argparse
import csv
import math
from pathlib import Path
import statistics
import sys

PROFILE = "ns3-wifi-reference-3v-v1"
STATES = ("idle", "cca_busy", "tx", "rx", "switching", "sleep", "off")
NEW_CURRENTS = (0.273, 0.273, 0.380, 0.313, 0.273, 0.033, 0.0)
OLD_CURRENTS = (0.0002, 0.273, 0.0174, 0.0197, 0.273, 0.033, 0.0)
POLICIES = ("TRAD", "VTP1", "VTP2")
SPEEDS = (0, 5, 10, 15, 20)
T_975 = (None, 12.706205, 4.302653, 3.182446, 2.776445, 2.570582,
         2.446912, 2.364624, 2.306004, 2.262157, 2.228139, 2.200985,
         2.178813, 2.160369, 2.144787, 2.131450, 2.119905, 2.109816,
         2.100922, 2.093024, 2.085963, 2.079614, 2.073873, 2.068658,
         2.063899, 2.059539, 2.055529, 2.051831, 2.048407, 2.045230)


def ensure(condition, message):
    if not condition:
        raise ValueError(message)


def number(row, column):
    x = float(row[column])
    ensure(math.isfinite(x), f"Nonfinite {column}: {x}")
    return x


def close(a, b, tol, description):
    ensure(abs(a - b) <= tol, f"{description}: {a:.12g} != {b:.12g} (tol={tol})")


def records(path):
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        ensure(reader.fieldnames is not None and len(reader.fieldnames) == len(set(reader.fieldnames)),
               f"Header absent/duplique: {path}")
        result = list(reader)
    ensure(result and all(None not in r and all(v is not None for v in r.values())
                          for r in result), f"CSV incomplet: {path}")
    return result


def key(row):
    speed = number(row, "speed")
    ensure(speed in SPEEDS, f"Vitesse inattendue {speed}")
    run = int(number(row, "run"))
    ensure(1 <= run <= 30, f"Run hors limite: {run}")
    policy = row["policy"]
    ensure(policy in POLICIES, f"Politique inconnue: {policy}")
    return (int(speed), run, policy)


def check_main(row):
    k = key(row)
    ensure(row["schema_version"] == "4.7", f"Schema inattendu: {k}")
    ensure(row["energy_profile"] == PROFILE, f"Profil energetique: {k}")
    ensure(row["campaign_id"] == "tiis-energy-wifi-v1", f"Campagne: {k}")
    ensure(row["scenario"] == "full-independent", f"Scenario: {k}")
    for col, expected in (("physical_channel_outage", 0),
                          ("force_route_available", 0), ("nodes", 50),
                          ("sim_time_s", 300), ("packet_size_bytes", 512),
                          ("rng_seed", 12345), ("rng_run", k[1]),
                          ("outage_phase_s", k[1] - 0.5),
                          ("recovery_pacing_s", 0.005),
                          ("outage_cycles_requested", 5)):
        close(number(row, col), expected, 1e-7, f"{k} {col}")
    ensure(number(row, "rx_unique") <= number(row, "generated"), f"PDR impossible {k}")


def analyze_one(main_row, path):
    k = key(main_row)
    ensure(path.is_file(), f"Trace absente: {path}")
    rows = records(path)
    ensure(len(rows) == 50, f"{path}: {len(rows)} noeuds, 50 attendus")
    sums = {state + "_s": 0.0 for state in STATES}
    energies = {state + "_j": 0.0 for state in STATES}
    seen = set()
    measured_sum = 0.0
    source_energy = None
    recon_sum = 0.0
    legacy_sum = 0.0
    for r in rows:
        ensure(key(r) == k, f"Cle de trace incorrecte: {path}")
        ensure(r["diagnostic_version"] == "2" and r["energy_profile"] == PROFILE,
               f"Version/profil incorrects: {path}")
        for col in ("campaign_id", "configuration_hash", "scenario", "rng_seed"):
            ensure(r[col] == main_row[col], f"{path}: {col} incoherent")
        close(number(r, "outage_phase_s"), k[1] - .5, 1e-8, "outage phase")
        node = int(number(r, "node"))
        ensure(0 <= node < 50 and node not in seen, f"Index radio absent/duplique: {node} {path}")
        seen.add(node)
        close(number(r, "window_start_s"), 0, 1e-8, "window start")
        close(number(r, "window_end_s"), 300, 1e-8, "window end")
        for col in ("unaccounted_s", "overlap_s"):
            close(number(r, col), 0, 1e-8, f"{col} {path} noeud{node}")
        close(number(r, "voltage_v"), 3, 1e-9, "voltage")
        close(number(r, "rx_unique"), number(main_row, "rx_unique"), 1e-8, "rx")
        close(number(r, "payload_bytes"), 512, 1e-8, "payload")
        bits = number(main_row, "rx_unique") * 512 * 8
        close(number(r, "delivered_payload_bits"), bits, 1e-7, "delivered bits")
        durations = [number(r, state + "_s") for state in STATES]
        ensure(all(t >= -1e-9 for t in durations), f"Duree negative: {path} node={node}")
        close(sum(durations), 300, 1e-6, f"couverture radio node={node}")
        close(durations[-1], 0, 1e-8, "PHY OFF exclu dans receiver gate")
        current_cols = ("i_idle_a", "i_cca_busy_a", "i_tx_a", "i_rx_a",
                        "i_switching_a", "i_sleep_a")
        for col, expected in zip(current_cols, NEW_CURRENTS):
            close(number(r, col), expected, 1e-10, f"{col} node={node}")
        reconstructed = 3 * sum(t * current for t, current in zip(durations, NEW_CURRENTS))
        measured = number(r, "energy_source_j")
        close(reconstructed, number(r, "energy_reconstructed_j"), 1e-6, "state reconstruction")
        close(reconstructed, measured, 0.01, "EnergySource vs PHY states")
        close(number(r, "energy_delta_j"), reconstructed-measured, 1e-6, "energy delta")
        ensure(0 <= measured < 1000, "EnergySource depleted or negative")
        measured_sum += measured
        if node == 0:
            source_energy = measured
        recon_sum += reconstructed
        legacy_sum += 3 * sum(t * current for t, current in zip(durations, OLD_CURRENTS))
        for state, t, current in zip(STATES, durations, NEW_CURRENTS):
            sums[state + "_s"] += t
            energies[state + "_j"] += 3 * t * current
    ensure(seen == set(range(50)), f"50 node IDs incomplets: {path}")
    close(measured_sum, number(main_row, "network_energy_j"), 1e-5, "network energy")
    close(source_energy, number(main_row, "source_energy_j"), 1e-6, "source energy")
    bits = number(main_row, "rx_unique") * 512 * 8
    energy_per_bit = measured_sum * 1e6 / bits if bits else math.nan
    if bits:
        close(energy_per_bit, number(main_row, "energy_uj_per_delivered_bit"), 1e-6,
              "energy per delivered payload bit")
    close(recon_sum, sum(energies.values()), 1e-5, "sum state energies")
    return {
        "speed": k[0], "run": k[1], "policy": k[2],
        "configuration_hash": main_row["configuration_hash"],
        "outage_schedule_hash": main_row["outage_schedule_hash"],
        "outage_phase_s": number(main_row, "outage_phase_s"),
        "generated": int(number(main_row, "generated")),
        "rx_unique": int(number(main_row, "rx_unique")),
        "delivered_payload_bits": int(bits),
        "network_energy_j": measured_sum,
        "energy_uj_per_delivered_bit": energy_per_bit,
        "reconstructed_energy_j": recon_sum,
        "legacy_reweighted_j": legacy_sum,
        **sums, **energies,
    }


def mean_ci(values):
    n = len(values)
    mean = statistics.mean(values)
    half = statistics.stdev(values) / math.sqrt(n) * T_975[n - 1] if 2 <= n <= 30 else math.nan
    return mean, mean - half, mean + half


def write_rows(path, rows, fields):
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data-dir", type=Path, required=True)
    p.add_argument("--reference", type=Path, help="Historical 450-run baseline CSV")
    p.add_argument("--output-dir", type=Path,
                   help="Write regenerated analysis here instead of modifying the fixed data directory")
    p.add_argument("--allow-partial", action="store_true", help="Allow smoke runs or resume")
    p.add_argument("--check-only", action="store_true")
    args = p.parse_args()
    base = args.data_dir
    raw = records(base / "main.csv")
    indexed = {}
    results = {}
    for r in raw:
        check_main(r)
        k = key(r)
        ensure(k not in indexed, f"Run duplique: {k}")
        indexed[k] = r
        radio = base / "radio" / f"full-independent-{k[0]:.9f}-{k[1]}-{k[2]}.csv"
        results[k] = analyze_one(r, radio)
    for speed in SPEEDS:
        hashes = {indexed[k]["configuration_hash"] for k in indexed if k[0] == speed}
        ensure(len(hashes) <= 1, f"Parametres incoherents a {speed} m/s: {hashes}")
        for run in range(1, 31):
            schedules = {indexed[k]["outage_schedule_hash"] for k in indexed
                         if k[0] == speed and k[1] == run}
            ensure(len(schedules) <= 1, f"Phases non appariees: {speed} m/s run {run}")
    actual = {f.name for f in (base / "radio").glob("*.csv")}
    expected = {f"full-independent-{s:.9f}-{r}-{p}.csv" for s, r, p in indexed}
    ensure(actual == expected, f"Traces orphelines ou absentes: {sorted(actual ^ expected)[:10]}")
    all_keys = {(s, r, p) for s in SPEEDS for r in range(1, 31) for p in POLICIES}
    if not args.allow_partial:
        ensure(indexed.keys() == all_keys,
               f"Campagne incomplete: {len(indexed)}/450 runs, {len(all_keys-indexed.keys())} manquants")
    mismatches = []
    if args.reference:
        refs = {key(r): r for r in records(args.reference)}
        ensure(len(refs) == 450, "CSV historique: 450 runs distincts requis")
        fields = ("generated", "rx_unique", "tx_original_submissions", "tx_retrans_submissions",
                  "phy_original_attempts", "phy_retrans_attempts", "rto_expirations",
                  "outage_phase_s", "physical_channel_outage")
        for k, r in indexed.items():
            ensure(k in refs, f"Run absent de la reference: {k}")
            for field in fields:
                current, historical = number(r, field), number(refs[k], field)
                if abs(current - historical) > 1e-7:
                    mismatches.append((k, field, current, historical))
            results[k]["historical_energy_j"] = number(refs[k], "network_energy_j")
            results[k]["legacy_reweighted_minus_historical_j"] = (
                results[k]["legacy_reweighted_j"] - results[k]["historical_energy_j"])
    ensure(not mismatches, f"Trafic modifie vs historique, exemples: {mismatches[:10]}")
    print(f"Controle OK: {len(results)}/450 runs, {len(results)*50} lignes radio, "
          f"parite historique={'oui' if args.reference else 'non verifiee'}.")
    if args.check_only:
        return

    out = args.output_dir if args.output_dir else base / "analysis"
    out.mkdir(parents=True, exist_ok=True)
    run_rows = [results[k] for k in sorted(results)]
    run_fields = list(run_rows[0])
    write_rows(out / "per_run_energy.csv", run_rows, run_fields)
    joined = []
    metrics = ("network_energy_j", "energy_uj_per_delivered_bit", "legacy_reweighted_j",
               "idle_j", "cca_busy_j", "tx_j", "rx_j", "switching_j", "sleep_j", "off_j")
    for speed in SPEEDS:
        for policy in ("VTP1", "VTP2"):
            pairs = [(results[(speed, run, "TRAD")], results[(speed, run, policy)])
                     for run in range(1, 31) if (speed, run, "TRAD") in results
                     and (speed, run, policy) in results]
            for metric in metrics:
                usable = [(a[metric], b[metric]) for a, b in pairs
                          if math.isfinite(a[metric]) and math.isfinite(b[metric])]
                if not usable:
                    continue
                differences = [a - b for a, b in usable]
                percent = [100 * (a-b)/a for a,b in usable if a > 0]
                d_mean, d_lo, d_hi = mean_ci(differences)
                pct_mean, pct_lo, pct_hi = mean_ci(percent) if percent else (math.nan,) * 3
                joined.append({"speed": speed, "policy": policy, "metric": metric,
                               "n_paired_seeds": len(usable),
                               "trad_mean": statistics.mean(a for a,b in usable),
                               "policy_mean": statistics.mean(b for a,b in usable),
                               "paired_difference_mean": d_mean,
                               "difference_ci95_low": d_lo, "difference_ci95_high": d_hi,
                               "paired_reduction_pct_mean": pct_mean,
                               "reduction_pct_ci95_low": pct_lo,
                               "reduction_pct_ci95_high": pct_hi})
    write_rows(out / "paired_energy_by_speed.csv", joined,
               ("speed", "policy", "metric", "n_paired_seeds", "trad_mean", "policy_mean",
                "paired_difference_mean", "difference_ci95_low", "difference_ci95_high",
                "paired_reduction_pct_mean", "reduction_pct_ci95_low", "reduction_pct_ci95_high"))
    complete_speeds = sorted({s for s in SPEEDS if all((s,r,p) in results for r in range(1,31) for p in POLICIES)})
    print(f"Sorties: {out}; vitesses a 30 paires completes: {complete_speeds}")
    if complete_speeds:
        for row in joined:
            if row["speed"] in complete_speeds and row["metric"] == "network_energy_j":
                print(f"{row['speed']:2d} m/s {row['policy']}: "
                      f"reduction appariee {row['paired_reduction_pct_mean']:.4f}% "
                      f"[IC95 {row['reduction_pct_ci95_low']:.4f},"
                      f" {row['reduction_pct_ci95_high']:.4f}], n=30")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, TypeError, OSError, KeyError, ZeroDivisionError) as exc:
        print(f"ECHEC CONTROLE: {exc}", file=sys.stderr)
        sys.exit(2)

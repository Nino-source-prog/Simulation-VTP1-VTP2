#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# Execute from ns-allinone-3.35/ns-3.35. All scientific parameters are fixed.
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIAG_DIR="${DIAG_DIR:-tiis-energy-wifi-v1}"
CAMPAIGN_ID=tiis-energy-wifi-v1
RUN_START="${RUN_START:-1}"
RUN_END="${RUN_END:-30}"
SPEEDS="${SPEEDS:-0 5 10 15 20}"
MAIN="$DIAG_DIR/main.csv"
PHASE_TABLE="$PACKAGE_DIR/outage-phases-30.csv"
SCENARIO=scratch/vtp-dsr-comparison
SOURCE=scratch/vtp-dsr-comparison.cc

die() { echo "ERREUR: $*" >&2; exit 2; }
if [[ -x ./ns3 ]]; then
  RUNNER=ns3
elif [[ -x ./waf ]]; then
  RUNNER=waf
else
  die "Lanceur ./ns3 ou ./waf absent/non executable dans: $PWD"
fi
[[ -f "$SOURCE" ]] || die "Scenario absent: $PWD/$SOURCE"
[[ -f src/dsr/model/dsr-routing.cc ]] ||
  die "Source DSR absente: $PWD/src/dsr/model/dsr-routing.cc"
[[ "$RUN_START" =~ ^([1-9]|[12][0-9]|30)$ &&
   "$RUN_END" =~ ^([1-9]|[12][0-9]|30)$ ]] || die 'RUN_START/END: entiers 1..30.'
(( RUN_START <= RUN_END )) || die 'RUN_START doit etre <= RUN_END.'
[[ -n "${SPEEDS//[[:space:]]/}" ]] || die 'SPEEDS vide.'
[[ "$DIAG_DIR" != *','* && "$DIAG_DIR" != *' '* && "$DIAG_DIR" != *$'\n'* ]] ||
  die 'DIAG_DIR ne doit contenir ni espaces, virgule ni saut de ligne.'
for speed in $SPEEDS; do
  case "$speed" in 0|5|10|15|20) ;; *) die "Vitesse hors campagne: $speed" ;; esac
done

SOURCE_SHA="$(sha256sum "$SOURCE" | cut -d' ' -f1)"
case "$SOURCE_SHA" in
  f9b9c312653b6ab2dcb149c81ef7ec7bad2fc2ee6227d2b55b05dcc6e08aae99|d0340669e1aec91d1e923c516310a1d994ab073cfa0e7f4ff1ecb7185e633a1f|5c91fc187e7592259814a187bf6c3d9c5a078a5502ab9eac7536c327c7e3ca58|e82b2232fadd650ebe0ff40602c9cdd452bbe206b4e0b27c8007ec5518667396) ;;
  *) die "Source non reconnue ($SOURCE_SHA). Installer install_energy_profile.sh." ;;
esac

mkdir -p "$DIAG_DIR/radio"
manifest_tmp="$(mktemp)"
trap 'rm -f -- "$manifest_tmp"' EXIT
{
  echo 'campaign=tiis-energy-wifi-v1'
  echo 'profile=ns3-wifi-reference-3v-v1'
  echo 'scenario=full-independent;receiver-app-gate;physicalChannelOutage=0'
  echo 'speeds_target=0,5,10,15,20;runs_target=1..30;policies=TRAD,VTP1,VTP2'
  echo 'seed=12345;phase=run-0.5;pace=0.005'
  echo 'nodes=50;simTime=300;voltage=3;initialEnergy=1000'
  echo "scenario_sha256=$SOURCE_SHA"
  echo "phase_table_sha256=$(sha256sum "$PHASE_TABLE" | cut -d' ' -f1)"
  find src/dsr/model -maxdepth 1 -type f -name '*.cc' -print0 |
    sort -z | xargs -0 sha256sum
} > "$manifest_tmp"
if [[ -e "$DIAG_DIR/manifest.txt" ]]; then
  cmp -s "$manifest_tmp" "$DIAG_DIR/manifest.txt" ||
    die "Configuration/source/DSR modifies: choisir un autre DIAG_DIR."
elif [[ -e "$MAIN" ]] || find "$DIAG_DIR/radio" -type f -print -quit | grep -q .; then
  die 'Resultats existants sans manifest: choisir un autre DIAG_DIR.'
else
  cp -- "$manifest_tmp" "$DIAG_DIR/manifest.txt"
fi

# Reject bad existing rows or orphaned files before attempting a resumed run.
if [[ -s "$MAIN" ]]; then
  python3 "$PACKAGE_DIR/analyze_energy_campaign.py" --data-dir "$DIAG_DIR" \
    --allow-partial --check-only
elif find "$DIAG_DIR/radio" -type f -print -quit | grep -q .; then
  die 'Fichiers radio sans CSV principal: inspecter le run interrompu.'
fi

declare -A EXISTING=()
if [[ -s "$MAIN" ]]; then
  while IFS='|' read -r speed run policy; do
    EXISTING["$speed|$run|$policy"]=1
  done < <(python3 - "$MAIN" <<'PY'
import csv,sys
with open(sys.argv[1], newline='', encoding='utf-8') as h:
    for row in csv.DictReader(h):
        print(f"{float(row['speed']):.9f}|{int(row['run'])}|{row['policy']}")
PY
  )
fi

echo "Compilation de $SCENARIO dans ns-3.35..."
if [[ "$RUNNER" == ns3 ]]; then
  ./ns3 build
else
  ./waf build
fi

for speed in $SPEEDS; do
  speed_fmt="$(printf '%.9f' "$speed")"
  for run in $(seq "$RUN_START" "$RUN_END"); do
    phase="$(awk -F, -v r="$run" 'NR>1 && $1==r {print $2; exit}' "$PHASE_TABLE")"
    [[ -n "$phase" ]] || die "Phase absente pour le run $run."
    for policy in TRAD VTP1 VTP2; do
      key="$speed_fmt|$run|$policy"
      radio="$DIAG_DIR/radio/full-independent-${speed_fmt}-${run}-${policy}.csv"
      if [[ -n "${EXISTING[$key]+x}" ]]; then
        [[ -s "$radio" ]] || die "Run present sans trace radio: $key"
        echo "SKIP $key"
        continue
      fi
      [[ ! -e "$radio" ]] || die "Trace radio orpheline: $radio"
      echo "RUN $key  phase=$phase"
      args="--policy=$policy --speed=$speed --run=$run --seed=12345 --campaignId=$CAMPAIGN_ID --out=$MAIN --radioOut=$radio --scenario=full-independent --physicalChannelOutage=0 --forceRouteAvailable=0 --outStart=50 --outagePhase=$phase --onDur=20 --offDur=10 --cycles=5 --recoveryPacing=0.005 --nodes=50 --pause=2 --areaX=500 --areaY=500 --range=300 --simTime=300 --appStart=10 --appStopMargin=35 --pktSize=512 --interval=0.1 --rto=1 --rtoMax=16 --lifetime=30 --maxAttempts=7 --routePoll=0.02 --dsrGrace=0.20 --graphPathDiagnostic=0 --graphPoll=0.10"
      if [[ "$RUNNER" == ns3 ]]; then
        ./ns3 run "$SCENARIO $args"
      else
        ./waf --run "$SCENARIO $args"
      fi
      [[ -s "$MAIN" && -s "$radio" ]] || die "Run incomplet: $key"
      EXISTING["$key"]=1
    done
  done
done

echo 'Verification de tous les runs presents...'
python3 "$PACKAGE_DIR/analyze_energy_campaign.py" --data-dir "$DIAG_DIR" \
  --allow-partial --reference "$PACKAGE_DIR/reference/legacy-main-450.csv"
echo "Termine. Fichiers: $DIAG_DIR"

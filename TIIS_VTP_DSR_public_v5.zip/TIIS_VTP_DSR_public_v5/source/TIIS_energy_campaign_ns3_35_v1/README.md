# TIIS: nouvelle campagne énergétique ns-3.35

Cette campagne reprend **le même scénario** `full-independent` (coupure contrôlée
à l'application réceptrice, PHY/DSR actifs), les 30 seeds/phases par vitesse,
les trois politiques et les paramètres du CSV historique. Elle change le
profil de consommation radio et enregistre les durées de chaque état PHY des
50 nœuds. Le code DSR installé n'est jamais remplacé par ce paquet.

## 1. Profil fixé

| État | Ancien mélange (A) | Référence Wi-Fi ns-3 (A) |
|---|---:|---:|
| Idle | 0,0002 | 0,273 |
| CCA-busy | 0,273 | 0,273 |
| Tx | 0,0174 | 0,380 |
| Rx | 0,0197 | 0,313 |
| Switching | 0,273 | 0,273 |
| Sleep | 0,033 | 0,033 |
| Off | 0 | 0 |

Tension explicite : **3 V** ; énergie initiale : **1 000 J/nœud**.
Les six courants actifs sont fixés explicitement dans la source. `Off` est un
état à courant nul dans cette analyse; sa durée doit être nulle ici. La
référence Wi-Fi ns-3 constitue un modèle interne cohérent, **pas une mesure
d'une carte 802.11b physique**. La borne de consommation pour 300 s à
0,380 A et 3 V est 342 J/nœud, inférieure aux 1 000 J disponibles.

**Contrôle préalable, sans nouvelle simulation.** Avec les états PHY déjà
archivés pour `speed=0, run=1`, leur simple repondération donne environ
12 296,356 J (TRAD), 12 293,985 J (VTP1 et VTP2), soit **0,0193 %**
de différence TRAD–VTP au lieu des 13,41 % historiques. Ceci est un contrôle
arithmétique sur une seule répétition, pas le résultat de la campagne de
450 runs; il ne doit pas devenir une conclusion statistique du manuscrit.

## 2. Installer dans votre vrai ns-3.35

Décompresser `TIIS_energy_campaign_ns3_35_v1.zip` dans `ns-allinone-3.35`
(à côté du dossier `ns-3.35`), puis :

```bash
cd ns-allinone-3.35/ns-3.35
bash ../TIIS_energy_campaign_ns3_35_v1/install_energy_profile.sh
```

L'installateur reconnaît les quatre variantes instrumentées déjà partagées
(`gap`, `gap_episodes`, `v1_1`, `v1_1_episodes`), sauvegarde
`scratch/vtp-dsr-comparison.cc` avant remplacement et sélectionne la même
variante avec le profil radio corrigé. Il refuse de remplacer une variante
inconnue : conserver cette source et nous la fournir pour une adaptation
contrôlée. Il ne copie rien dans `src/dsr/`.
Les scripts reconnaissent les lanceurs `./waf` (ns-3.35 classique) et `./ns3` ;
le lancement compile automatiquement avant les simulations. Si un fichier
manque, le message indique désormais son chemin exact.

## 3. Exécuter

Faire d'abord un contrôle de compilation et de sortie (3 simulations) :

```bash
cd ns-allinone-3.35/ns-3.35
SPEEDS=0 RUN_START=1 RUN_END=1 \
  bash ../TIIS_energy_campaign_ns3_35_v1/run_energy_campaign.sh
```

Puis un contrôle sévère déjà repéré dans le travail précédent (3 simulations,
20 m/s, run 8), avant d'engager toute la grille :

```bash
SPEEDS=20 RUN_START=8 RUN_END=8 \
  bash ../TIIS_energy_campaign_ns3_35_v1/run_energy_campaign.sh
```

Puis la campagne entière, dans **le même** dossier de résultats :

```bash
cd ns-allinone-3.35/ns-3.35
bash ../TIIS_energy_campaign_ns3_35_v1/run_energy_campaign.sh
```

Le lanceur reprend ces six runs et poursuit les **450 simulations**
de la grille 5 vitesses (`0,5,10,15,20` m/s) × 30 RNG runs × 3 politiques.
Les phases fixes des runs sont `0,5, 1,5, ..., 29,5 s` : chaque trio est
strictement apparié. Paramètres radio, horaires, trafic, DSR et pacing 5 ms
sont transmis explicitement. La simulation ne produit que `main.csv` et
`radio/*.csv`, sans les volumineuses traces par paquet.

Les fichiers existants ne sont pas écrasés. Une trace orpheline ou une
modification de code/DSR déclenche un arrêt explicite. En cas d'interruption
pendant l'écriture d'un run, inspecter ou mettre de côté **uniquement** le
fichier radio orphelin et la ligne principale correspondante avant toute
reprise. Ne jamais mélanger avec l'ancien CSV ni supprimer des sorties sans
avoir conservé une copie.

## 4. Valider et analyser

Après les 450 runs (depuis `ns-3.35`) :

```bash
python3 ../TIIS_energy_campaign_ns3_35_v1/analyze_energy_campaign.py \
  --data-dir tiis-energy-wifi-v1 \
  --reference ../TIIS_energy_campaign_ns3_35_v1/reference/legacy-main-450.csv
```

Le contrôle final exige 450 lignes uniques et vérifie : 50 nœuds par run,
300 s/nœud sans lacune/recouvrement, aucun temps `OFF`, six courants et
3 V, énergie reconstruite par somme `V × I_état × durée_état`, énergie de
la source et du réseau, ainsi que
`bits livrés = rx_unique × packet_size_bytes × 8` (doublons exclus).
Il vérifie aussi que la génération, les livraisons, les soumissions,
les tentatives PHY et les expirations RTO sont identiques au CSV historique
pour chaque run. Si ce test échoue, l'analyse s'arrête :
**aucune comparaison causale à trafic identique n'est validée**. Il faut
examiner les hashes source/DSR et les fichiers de campagne.

Fichiers analytiques :

* `analysis/per_run_energy.csv` : durées et joules de chaque état, énergie
  mesurée, énergie repondérée avec l'ancien mélange, nombre exact de bits et
  comparaison énergétique historique.
* `analysis/paired_energy_by_speed.csv` : différence TRAD−VTP1/VTP2 et
  pourcentage **par seed**, moyennes et intervalles t à 95 % par vitesse;
  `n_paired_seeds=30` requis pour la comparaison définitive. Le `network_energy_j`
  total et les `energy_uj_per_delivered_bit` sont présentés séparément.
* `manifest.txt` : profil, hash scénario, hash table de phases, hashes DSR.

Les effets par état sont des *décompositions* du changement d'énergie,
pas des tests indépendants supplémentaires. La repondération historique
emploie les durées PHY de la **nouvelle** simulation; sa différence avec
`historical_energy_j` permet de repérer des évolutions de trafic ou de trace.
La comparaison publiée doit signaler que le profil est une référence ns-3
cohérente et que le scénario reste une disponibilité contrôlée côté application.

La source de la version initiale est identifiée par les hashes du script
`build_sources.py`; les quatre variantes corrigées sont livrées dans `src/`.
Le CSV historique est inclus dans `reference/` pour contrôler la parité.
`reference/static_radio/` contient les 3 traces PHY d'origine et
`reference/static-run1-precheck.csv` documente le contrôle de repondération.

#!/usr/bin/env bash
set -euo pipefail

if (( $# != 1 )); then
  echo "Usage: bash install_scripts.sh /chemin/vers/ns-3.35" >&2
  exit 2
fi
PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
NS3_ROOT="$(cd "$1" && pwd)"

# Both files are checked before any copy. No C++ file is modified.
declare -A PREVIOUS=(
  [run-tiis-diagnostics.sh]=71eb0ff3ff20497f0d874671f3e131e3f532b7236c2b0fdafc34ddb328ded2e8
  [analyze-tiis-diagnostics.py]=d0862d55228f712e5655dde1e818f69e16ef7b9cd93019a0d154411f5fef2247
)
declare -A UPDATED=(
  [run-tiis-diagnostics.sh]=e153cd83156744c027b3ef474c84726745b81aa176b2d41af03d3932913c5816
  [analyze-tiis-diagnostics.py]=5e20d3b12dbea863a45d7127edef73941508c493c6204a60ab1c668675164856
)

already=0
for name in run-tiis-diagnostics.sh analyze-tiis-diagnostics.py; do
  target="$NS3_ROOT/$name"
  if [[ ! -f "$target" ]]; then
    echo "Fichier absent: $target. Installer d'abord le paquet diagnostic v1.1." >&2
    exit 1
  fi
  actual="$(sha256sum "$target")"
  actual="${actual%% *}"
  if [[ "$actual" == "${UPDATED[$name]}" ]]; then
    (( already += 1 ))
  elif [[ "$actual" != "${PREVIOUS[$name]}" ]]; then
    echo "Version locale inconnue: $target ($actual). Refus d'ecraser." >&2
    exit 1
  fi
done

if (( already == 2 )); then
  echo "Scripts v1.2 deja installes."
  exit 0
fi

backup="$(mktemp -d "$NS3_ROOT/tiis-runner-backup.XXXXXX")"
for name in run-tiis-diagnostics.sh analyze-tiis-diagnostics.py; do
  cp "$NS3_ROOT/$name" "$backup/$name"
  cp "$PACKAGE_DIR/scripts/$name" "$NS3_ROOT/$name"
done
echo "Scripts v1.2 installes; sauvegarde: $backup"
echo "Les fichiers C++ ne sont pas modifies; aucune recompilation necessaire."

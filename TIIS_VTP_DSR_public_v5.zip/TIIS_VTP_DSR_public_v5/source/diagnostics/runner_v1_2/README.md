# TIIS — correctif du lanceur de diagnostic v1.2

Le dossier precedent appele `tiis-route20-run8` contient en realite trois runs
`mobility-route` a **0 m/s**. Il ne peut pas documenter le cas severe a 20 m/s.
Le lanceur v1.1 utilisait silencieusement `SPEEDS=0` lorsque la variable de
vitesse n'atteignait pas le processus `bash`. Cette version exige une valeur
explicite et affiche la configuration avant le premier run. Le validateur
accepte des identites attendues et les verifie avant d'afficher « valide ».

Placer ce dossier a cote de `ns-3.35`, puis, depuis leur dossier parent :

```bash
bash tiis_runner_v1_2/install_scripts.sh "$PWD/ns-3.35"
bash tiis_runner_v1_2/run-route20-run8.sh "$PWD/ns-3.35"
```

La premiere commande controle les empreintes des deux scripts installes par
v1.1, les sauvegarde et ne touche pas aux fichiers C++. La seconde fixe dans
le script le profil `mobility-route`, la vitesse `20 m/s`, le run `8` et la
phase equilibree correspondante, `7.5 s`. Elle execute les trois politiques,
verifie l'identite du CSV et produit `tiis-route20-run8-v1_2.tar.gz`.
Ne pas renommer l'ancien dossier en dossier 20 m/s.

Si l'installation refuse une empreinte inconnue, transmettre le message exact
pour fusionner vos modifications locales. Si un run est interrompu, ne pas
effacer les traces : transmettre la sortie du terminal avant de relancer.

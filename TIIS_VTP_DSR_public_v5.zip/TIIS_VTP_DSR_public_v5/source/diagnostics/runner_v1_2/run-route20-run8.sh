#!/usr/bin/env bash
set -euo pipefail

if (( $# != 1 )); then
  echo "Usage: bash run-route20-run8.sh /chemin/vers/ns-3.35" >&2
  exit 2
fi
NS3_ROOT="$(cd "$1" && pwd)"
cd "$NS3_ROOT"
for name in run-tiis-diagnostics.sh analyze-tiis-diagnostics.py; do
  actual="$(sha256sum "$name")"
  actual="${actual%% *}"
  case "$name:$actual" in
    run-tiis-diagnostics.sh:e153cd83156744c027b3ef474c84726745b81aa176b2d41af03d3932913c5816|analyze-tiis-diagnostics.py:5e20d3b12dbea863a45d7127edef73941508c493c6204a60ab1c668675164856)
      ;;
    *)
      echo "Installer d'abord les scripts v1.2; version inattendue de $name." >&2
      exit 1
      ;;
  esac
done
DIR=tiis-route20-run8-v1_2
if [[ -e "$DIR" || -e "$DIR.tar.gz" ]]; then
  echo "Le resultat $DIR existe deja. Refus de melanger deux essais." >&2
  exit 1
fi

env PROGRAM=scratch/vtp-dsr-comparison PROFILE=mobility-route SPEEDS=20 \
  RUNS=8 RUN_START=8 RUN_END=8 DIAG_DIR="$DIR" OUT="$DIR/main.csv" \
  CAMPAIGN_ID="$DIR" RNG_SEED=12345 RECOVERY_PACING=0.005 \
  OUTAGE_BASE_START=50.0 OUTAGE_PHASE_MODE=balanced \
  OUTAGE_PHASE_SPAN=30.0 OUTAGE_PHASE_BINS=30 OUTAGE_PHASE_TABLE= \
  GRAPH_PATH_DIAGNOSTIC=0 EXTRA_ARGS= RESET_RESULTS=0 SKIP_EXISTING=1 \
  bash ./run-tiis-diagnostics.sh

python3 ./analyze-tiis-diagnostics.py --diag-dir "$DIR" \
  --expect-scenario mobility-route --expect-speed 20 --expect-run 8 \
  --expect-policies TRAD,VTP1,VTP2
tar -czf "$DIR.tar.gz" "$DIR"
echo "Archive a transmettre: $NS3_ROOT/$DIR.tar.gz"

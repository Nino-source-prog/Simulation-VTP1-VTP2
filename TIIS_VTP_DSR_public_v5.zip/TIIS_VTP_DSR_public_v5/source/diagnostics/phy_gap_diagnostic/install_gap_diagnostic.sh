#!/usr/bin/env bash
set -euo pipefail

# Mise a niveau ciblee depuis le paquet TIIS radio/DSR v1.1 deja installe.
if (( $# != 1 )); then
  echo "Usage: bash install_gap_diagnostic.sh /chemin/vers/ns-3.35" >&2
  exit 2
fi
PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
NS3_ROOT="$(cd "$1" && pwd)"

declare -A EXPECTED=(
  ["src/dsr/model/dsr-routing.cc"]="9b6880fca3c2e77d10633da5327c762a0719659160a9fdea6a5d11acd88e19ad"
  ["src/dsr/model/dsr-routing.h"]="2769f09128d002a99945470d2b1493cce50d76a025b3974a0bd4696e2f24f789"
)
SCENARIO="scratch/vtp-dsr-comparison.cc"
SCENARIO_SOURCE=""

for path in "${!EXPECTED[@]}" "$SCENARIO"; do
  if [[ ! -f "$NS3_ROOT/$path" ]]; then
    echo "Absent: $NS3_ROOT/$path" >&2
    exit 1
  fi
done
if [[ -e "$NS3_ROOT/analyze_vtp2_phy_gap.py" ]]; then
  echo "Analyseur deja present: $NS3_ROOT/analyze_vtp2_phy_gap.py. Refus d'ecraser." >&2
  exit 1
fi

SCENARIO_HASH="$(sha256sum "$NS3_ROOT/$SCENARIO")"
SCENARIO_HASH="${SCENARIO_HASH%% *}"
case "$SCENARIO_HASH" in
  16e7a1dffbd192dcee3129ff5c7eb5ed8a49b6bb7700c997007739f0b1ee7a7e)
    SCENARIO_SOURCE="vtp-dsr-comparison.cc"
    ;;
  13ec28661b136ee4a52956bcd983d979052db23534d0ec1da927846dfd28f939)
    SCENARIO_SOURCE="vtp-dsr-comparison-episodes.cc"
    ;;
  *)
    echo "Scenario inconnu ($SCENARIO_HASH): refus d'ecraser les modifications locales." >&2
    exit 1
    ;;
esac

for path in "${!EXPECTED[@]}"; do
  actual="$(sha256sum "$NS3_ROOT/$path")"
  actual="${actual%% *}"
  if [[ "$actual" != "${EXPECTED[$path]}" ]]; then
    echo "DSR modifie: $path ($actual). Refus d'ecraser; une fusion ciblee est requise." >&2
    exit 1
  fi
done

BACKUP_DIR="$NS3_ROOT/tiis-gap-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR/scratch" "$BACKUP_DIR/src/dsr/model"
for path in "${!EXPECTED[@]}"; do
  cp "$NS3_ROOT/$path" "$BACKUP_DIR/$path"
done
cp "$NS3_ROOT/$SCENARIO" "$BACKUP_DIR/$SCENARIO"

cp "$PACKAGE_DIR/src/dsr-routing.cc" "$NS3_ROOT/src/dsr/model/dsr-routing.cc"
cp "$PACKAGE_DIR/src/dsr-routing.h" "$NS3_ROOT/src/dsr/model/dsr-routing.h"
cp "$PACKAGE_DIR/src/$SCENARIO_SOURCE" "$NS3_ROOT/$SCENARIO"
cp "$PACKAGE_DIR/analyze_vtp2_phy_gap.py" "$NS3_ROOT/analyze_vtp2_phy_gap.py"
echo "Sauvegarde des originaux: $BACKUP_DIR"

cd "$NS3_ROOT"
if [[ -x ./ns3 ]]; then
  ./ns3 build
elif [[ -x ./waf ]]; then
  ./waf build
else
  echo "Ni ./ns3 ni ./waf n'est executable. Compiler manuellement." >&2
  exit 1
fi
echo "Diagnostic compile. Relancer uniquement le run 8 a 20 m/s dans un nouveau dossier."

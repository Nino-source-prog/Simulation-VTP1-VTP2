#!/usr/bin/env python3
"""Audit missing VTP2 retransmission first-PHY events per (seq, attempt_id).

Usage: python3 analyze_vtp2_phy_gap.py packet/mobility-route-20.000000000-8-VTP2.csv
The input is the unmodified packet CSV from the diagnostic campaign.
"""
import argparse
import csv
from collections import Counter, defaultdict
from pathlib import Path
from typing import Optional


def analyze(path: Path, out: Optional[Path]):
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    if not rows or not {"time_ns", "event", "seq", "attempt_id"}.issubset(rows[0]):
        raise ValueError("packet CSV invalide ou vide")

    attempts = defaultdict(list)
    submissions = defaultdict(list)
    for row in rows:
        key = (row["seq"], row["attempt_id"])
        attempts[key].append(row)
        if row["event"] == "transport_submit":
            submissions[row["time_ns"]].append(row)

    missing = []
    for time_ns, simultaneous in submissions.items():
        for rank, submission in enumerate(simultaneous, start=1):
            if submission.get("retransmission") != "1":
                continue
            key = (submission["seq"], submission["attempt_id"])
            events = {row["event"] for row in attempts[key]}
            if "phy_first" in events:
                continue
            first = simultaneous[0]
            missing.append({
                "time_ns": time_ns,
                "seq": key[0],
                "attempt_id": key[1],
                "C": submission.get("C", ""),
                "P": submission.get("P", ""),
                "simultaneous_count": len(simultaneous),
                "submission_rank": rank,
                "first_seq": first["seq"],
                "first_attempt_id": first["attempt_id"],
                "first_has_phy": int("phy_first" in {
                    r["event"] for r in attempts[(first["seq"], first["attempt_id"])]
                }),
                "paced_release": int("paced_release" in events),
                "dsr_send_entry": int("dsr_send_entry" in events),
                "dsr_enqueue": int("dsr_enqueue" in events),
                "dsr_maintain_accepted": int("dsr_maintain_accepted" in events),
                "dsr_maintain_rejected": int("dsr_maintain_rejected" in events),
                "dsr_network_accepted": int("dsr_network_accepted" in events),
                "dsr_network_rejected": int("dsr_network_rejected" in events),
                "dsr_ipv4_downcall": int("dsr_ipv4_downcall" in events),
            })

    counts = Counter()
    for record in missing:
        counts[(record["simultaneous_count"], record["submission_rank"])] += 1
    print(f"Fichier: {path}")
    print(f"Retransmissions VTP2 sans premier PHY: {len(missing)}")
    print("Par groupe de soumissions simultanees (taille, rang):", dict(sorted(counts.items())))
    print("Premiere soumission du groupe avec PHY:", sum(x["first_has_phy"] for x in missing))
    print("Dont libérations cadencées:", sum(x["paced_release"] for x in missing))
    for name in ("dsr_send_entry", "dsr_enqueue", "dsr_maintain_accepted",
                 "dsr_maintain_rejected", "dsr_network_accepted",
                 "dsr_network_rejected", "dsr_ipv4_downcall"):
        print(f"{name}: {sum(x[name] for x in missing)}")
    if not any(r["event"] == "dsr_send_entry" for r in rows):
        print("Diagnostic DsrPathEvent absent: la cause dans DSR reste a confirmer.")
    if out:
        with out.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(missing[0]) if missing else
                                    ["time_ns", "seq", "attempt_id"])
            writer.writeheader()
            writer.writerows(missing)
        print(f"Details: {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("packet_csv", type=Path)
    parser.add_argument("--out", type=Path, help="CSV des retransmissions sans premier PHY")
    arguments = parser.parse_args()
    analyze(arguments.packet_csv, arguments.out)

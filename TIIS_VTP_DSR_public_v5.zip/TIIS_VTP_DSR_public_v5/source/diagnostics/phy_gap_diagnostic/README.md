# Diagnostic ciblé des retransmissions VTP2 sans émission PHY

## Constat tiré du run `mobility-route`, 20 m/s, graine/run 8

Le fichier `gaps_existing_run8.csv` est calculé directement depuis la trace
`packet/mobility-route-20.000000000-8-VTP2.csv` déjà fournie.

- Les 78 retransmissions VTP2 acceptées par le socket et sans premier PHY
  surviennent toutes à un instant qui contient **deux ou trois soumissions**.
- Elles ont le rang 2 dans 44 groupes de deux, le rang 2 dans 17 groupes de
  trois et le rang 3 dans ces mêmes 17 groupes. Dans les 78 cas, la première
  soumission du groupe atteint PHY ; les suivantes n'ont pas d'événement
  `dsr_enqueue` dans la trace existante.
- Quatorze des 78 cas sont des libérations cadencées. Par exemple, à
  254,900 s, l'original seq=2448 (tentative 1) et la reprise seq=2411
  (tentative 2) sont soumis au même instant. Seul seq=2448 est observé à PHY
  à 254,900050 s. La tentative 5 de seq=2411 atteint PHY à 268,900050 s.

**Hypothèse à vérifier :** le chemin DSR avec route disponible essaie
`m_maintainBuffer.Enqueue` avec une clé de maintenance qui peut traiter deux
paquets proches comme un doublon tant que le premier n'a pas été retiré.
La trace existante prouve la coïncidence temporelle, pas le lieu exact de
l'abandon. La nouvelle trace vérifie le résultat de cet `Enqueue` pour chaque
tentative, puis la file réseau et l'appel vers IPv4.

## Installation sur la copie ns-3.35 qui a produit le run

Ce paquet applique une mise à niveau du diagnostic TIIS **v1.1**. Le script
vérifie les empreintes des deux fichiers DSR et du scénario en place, conserve
des copies, refuse les versions inconnues, puis compile. Il n'écrase pas une
fusion locale différente.

```bash
bash install_gap_diagnostic.sh /chemin/vers/ns-3.35
```

Dans la racine `ns-3.35`, utiliser un **nouveau** répertoire de résultats :

```bash
DIAG_DIR=tiis-gap-route20-run8 PROFILE=mobility-route SPEEDS="20" \
  RUNS=8 RUN_START=8 RUN_END=8 CAMPAIGN_ID=tiis-gap-route20-run8 \
  bash ./run-tiis-diagnostics.sh

python3 ./analyze-tiis-diagnostics.py --diag-dir tiis-gap-route20-run8 \
  --reference-csv /chemin/vers/vtp-v4.6.3-run8-route-only.csv

python3 ./analyze_vtp2_phy_gap.py \
  tiis-gap-route20-run8/packet/mobility-route-20.000000000-8-VTP2.csv \
  --out tiis-gap-route20-run8/gaps_vtp2.csv
```

Le profil, la vitesse, le run, la phase et la cadence doivent rester identiques
au run de référence. La comparaison du CSV historique doit afficher la parité
des métriques, hormis `campaign_id` : les nouveaux événements sont uniquement
des sondes et n'ont pas vocation à modifier les décisions de retransmission.

## Lecture des nouveaux événements

Tous les événements conservent `(seq, attempt_id)` et l'heure en nanosecondes.

| Événement | Ce qu'il établit |
| --- | --- |
| `dsr_send_entry` | La tentative est entrée dans `DsrRouting::Send`. |
| `dsr_packet_new_route` | Elle a été renvoyée au traitement de découverte de route. |
| `dsr_maintain_accepted` / `dsr_maintain_rejected` | Résultat direct de `m_maintainBuffer.Enqueue`. |
| `dsr_network_accepted` / `dsr_network_rejected` | Résultat de l'insertion dans la file réseau DSR. |
| `dsr_ipv4_downcall` | La file DSR a appelé la couche IPv4 ; l'absence de PHY reste alors à localiser plus bas. |

Si les 78 tentatives sont `dsr_maintain_rejected`, inspecter sur **cette même
installation ns-3.35** `src/dsr/model/dsr-maintain-buff.cc`, fonction
`DsrMaintainBuffer::Enqueue`, pour qualifier formellement la raison du refus.
Une succession `dsr_maintain_accepted` → `dsr_network_rejected` indique au
contraire la file réseau ; `dsr_ipv4_downcall` sans PHY indique un autre étage.
Ne pas annoncer un mécanisme causal tant que les événements de confirmation ne
sont pas arrivés.

Ce diagnostic est un run unique destiné à expliquer une trajectoire sévère.
Les conclusions statistiques du manuscrit restent celles des campagnes
préalablement appariées ; il n'est pas nécessaire de refaire les 450 runs pour
localiser cette perte de tentative.

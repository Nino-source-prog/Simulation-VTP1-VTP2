#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# A copier avec le C++ instrumente et run-vtp-dsr-experiments.sh dans ns-3.35.
# Exécuter depuis la racine ns-3.35, apres compilation du programme scratch.
# B ajuste c; A et C testent c hors accumulation; D teste la sensibilite au debit.
# La duree de vie (30 s) autorise les coupures choisies de 5/10/20 s.
RUNS="${RUNS:-10}"
OUTDIR="${OUTDIR:-episodes-$(date +%Y%m%d-%H%M%S)-$$}"
if ! [[ "$RUNS" =~ ^[1-9][0-9]*$ ]]; then
  echo "RUNS doit etre un entier strictement positif." >&2
  exit 1
fi
if [[ "$OUTDIR" =~ [[:space:],] ]] || [[ -e "$OUTDIR" ]]; then
  echo "OUTDIR doit etre nouveau et sans espace ni virgule: $OUTDIR" >&2
  exit 1
fi
if [[ ! -f scratch/vtp-dsr-comparison.cc ]] ||
   ! grep -q '"episodeOut"' scratch/vtp-dsr-comparison.cc ||
   ! grep -q 'episode_max_paced_ms' scratch/vtp-dsr-comparison.cc; then
  echo "Installer le fichier C++ instrumente dans scratch/vtp-dsr-comparison.cc." >&2
  exit 1
fi
if [[ ! -f ./run-vtp-dsr-experiments.sh ]] ||
   { [[ ! -x ./ns3 ]] && [[ ! -x ./waf ]]; }; then
  echo "Lancer depuis ns-3.35 avec le lanceur de base et ./ns3 ou ./waf." >&2
  exit 1
fi
mkdir -p -- "$(dirname -- "$OUTDIR")"
mkdir -- "$OUTDIR"

# nom:offDur:interval:role. Meme calendrier de coupures et memes graines.
CONDS=(
  "B:10:0.1:calibration"
  "A:5:0.1:controle-duree"
  "C:20:0.1:controle-duree"
  "D:10:0.2:controle-debit"
)
PACINGS=(0.005 0.010 0.020)
echo "Campagne: 4 conditions x 3 cadences x $RUNS runs x 3 politiques."
echo "Dossier: $OUTDIR"
for cond in "${CONDS[@]}"; do
  IFS=: read -r name off interval role <<< "$cond"
  for pacing in "${PACINGS[@]}"; do
    pacing_ms="$(awk -v t="$pacing" 'BEGIN { printf "%d", t*1000+0.5 }')"
    out="$OUTDIR/run-${name}-pac${pacing_ms}ms.csv"
    episodes="$OUTDIR/episodes-${name}-pac${pacing_ms}ms.csv"
    log="$OUTDIR/log-${name}-pac${pacing_ms}ms.txt"
    echo "$name ($role): coupure=${off}s, intervalle=${interval}s, cadence=${pacing_ms}ms"
    if ! EXTRA_ARGS="--offDur=$off --onDur=20 --interval=$interval --episodeOut=$episodes" \
        RECOVERY_PACING="$pacing" PROFILE=full-independent \
        GRAPH_PATH_DIAGNOSTIC=0 SPEEDS="0" RUNS="$RUNS" \
        RUN_START=1 RUN_END="$RUNS" OUT="$out" \
        CAMPAIGN_ID="episodes-${name}-${pacing_ms}ms" \
        SKIP_EXISTING=0 RESET_RESULTS=1 \
        bash ./run-vtp-dsr-experiments.sh >"$log" 2>&1; then
      echo "Echec d'execution; derniers messages de $log :" >&2
      tail -n 15 -- "$log" >&2
      exit 1
    fi
    if [[ ! -s "$out" || ! -s "$episodes" ]]; then
      echo "CSV principal ou fichier d'episodes absent: $out / $episodes" >&2
      exit 1
    fi
  done
done

python3 - "$OUTDIR" "$RUNS" <<'PY_EPI'
import csv
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

folder, runs = Path(sys.argv[1]), int(sys.argv[2])
conditions = {'B': (10, 0.1), 'A': (5, 0.1),
              'C': (20, 0.1), 'D': (10, 0.2)}
pacings = (5, 10, 20)
policies = ('TRAD', 'VTP1', 'VTP2')
quality = []
run_data = {}
out_columns = ('condition', 'pacing_ms', 'run', 'episodes',
               'depth_mean', 'depth_min', 'depth_max',
               'pure_pacing_episodes', 'unpaced_recovery_share',
               'unpaced_max_episodes',
               'tmax_mean_ms', 'prediction_mean_ms',
               'error_mean_ms', 'mae_episode_ms')

def rows(path):
    with path.open(newline='', encoding='utf-8-sig') as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError(f"CSV vide: {path}")
        result = list(reader)
        if any(None in row for row in result):
            raise ValueError(f"Largeur CSV incoherente: {path}")
        return result

def number(row, column):
    value = float(row[column])
    if not math.isfinite(value):
        raise ValueError(f"{column} non fini: {row}")
    return value

def optional_number(row, column):
    return number(row, column) if row[column] else None

def write_csv(filename, fieldnames, items):
    with (folder / filename).open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(items)

for condition, (off, interval) in conditions.items():
    for pacing in pacings:
        main = rows(folder / f'run-{condition}-pac{pacing}ms.csv')
        epi = rows(folder / f'episodes-{condition}-pac{pacing}ms.csv')
        expected = {(policy, run) for policy in policies
                    for run in range(1, runs + 1)}
        seen = {}
        for row in main:
            key = (row['policy'], int(row['run']))
            if key in seen:
                raise ValueError(f"Run duplique: {condition}, {pacing}, {key}")
            if key not in expected:
                raise ValueError(f"Run inattendu: {condition}, {pacing}, {key}")
            if (abs(number(row, 'outage_off_duration_s') - off) > 1e-8
                    or abs(number(row, 'generation_interval_s') - interval) > 1e-8
                    or abs(number(row, 'recovery_pacing_s') - pacing / 1000) > 1e-8
                    or int(row['outage_cycles_requested']) != 5
                    or row['campaign_id'] != f'episodes-{condition}-{pacing}ms'
                    or number(row, 'speed') != 0):
                raise ValueError(f"Configuration divergente: {condition}, {pacing}, {key}")
            seen[key] = row
        if set(seen) != expected:
            raise ValueError(f"Runs manquants: {condition}, {pacing}, {expected-set(seen)}")
        for run in range(1, runs + 1):
            if len({seen[(policy, run)]['outage_phase_s'] for policy in policies}) != 1:
                raise ValueError(f"Phase de coupure non appariee: {condition}/{pacing}/{run}")
        per_run = defaultdict(list)
        for row in epi:
            required = ('episode_max_paced_ms', 'episode_max_unpaced_ms',
                        'unpaced_original_samples',
                        'unpaced_retransmission_samples',
                        'outside_initial_recovery_samples',
                        'episode_pure_pacing')
            if any(column not in row for column in required):
                raise ValueError("Ancien schema episodes: recompiler le C++ corrige "
                                 "et relancer dans un nouveau dossier.")
            key = (row['policy'], int(row['run']))
            if key not in expected or key[0] == 'TRAD':
                raise ValueError(f"Episode inattendu: {condition}, {pacing}, {key}")
            if (abs(number(row, 'outage_off_s') - off) > 1e-8
                    or abs(number(row, 'interval_s') - interval) > 1e-8
                    or abs(number(row, 'recovery_pacing_s') - pacing / 1000) > 1e-8
                    or row['campaign_id'] != seen[key]['campaign_id']
                    or row['rng_seed'] != seen[key]['rng_seed']
                    or abs(number(row, 'outage_phase_s') -
                           number(seen[key], 'outage_phase_s')) > 1e-8):
                raise ValueError(f"Parametres episode incoherents: {condition}, {pacing}, {key}")
            if (int(row['unpaced_original_samples']) +
                    int(row['unpaced_retransmission_samples']) !=
                    int(row['unpaced_recovery_samples'])):
                raise ValueError(f"Ventilation PHY incoherente: {condition}, {pacing}, {key}")
            if (row['episode_pure_pacing'] == '1' and
                (row['episode_valid'] != '1' or
                 int(row['unpaced_recovery_samples']) != 0)):
                raise ValueError(f"Pure pacing incoherent: {condition}, {pacing}, {key}")
            per_run[key].append(row)
        for policy in ('VTP1', 'VTP2'):
            for run in range(1, runs + 1):
                subset = per_run[(policy, run)]
                indexes = [int(r['episode_index']) for r in subset]
                if sorted(indexes) != [1, 2, 3, 4, 5]:
                    quality.append(f"{condition}/{pacing}ms/{policy}/run{run}: indices d'episode={indexes}")
                invalid = [r for r in subset if r['episode_valid'] != '1']
                if invalid:
                    flags = [(r['episode_index'], r['queue_depth_at_release'],
                              r['episode_released'], r['episode_phy_observed'],
                              r['episode_recovery_samples'], r['late_enqueued'],
                              r['unpaced_recovery_samples'],
                              r['outside_initial_recovery_samples'],
                              r['episode_interrupted'])
                             for r in invalid]
                    quality.append(f"{condition}/{pacing}ms/{policy}/run{run}: invalides={flags}")
                if policy == 'VTP1' and len(subset) == 5 and not invalid:
                    sample_count = sum(int(r['episode_recovery_samples']) for r in subset)
                    if sample_count > int(seen[(policy, run)]['recovery_samples']):
                        raise ValueError(f"Samples episode > samples run: {condition}/{pacing}/{run}")
                    run_data[(condition, pacing, run)] = subset

def measurement(row, pacing):
    n = int(row['queue_depth_at_release'])
    tmax = number(row, 'episode_max_recovery_ms')
    return n, tmax, tmax - (n - 1) * pacing

# Unite de repetition : le run entier (5 episodes), pas les 5 points correles.
calibration = [
    statistics.mean(measurement(r, pacing)[2] for r in run_data[('B', pacing, run)])
    for pacing in pacings for run in range(1, runs + 1)
    if ('B', pacing, run) in run_data
]
if not calibration:
    (folder / 'qualite-episodes.txt').write_text(
        "Aucun run B complet pour calibrer c.\n" + "\n".join(quality) + "\n",
        encoding='utf-8')
    raise SystemExit("Aucun run B valide; voir qualite-episodes.txt.")
c_ms = statistics.median(calibration)

per_episode = []
per_run = []
summary = []
maxima_unpaced = 0
maxima_total = 0
for condition, (off, interval) in conditions.items():
    for pacing in pacings:
        current_runs = []
        for run in range(1, runs + 1):
            subset = run_data.get((condition, pacing, run))
            if subset is None:
                continue
            errors = []
            depths = []
            tmaxes = []
            predictions = []
            unpaced_samples = 0
            pure_episodes = 0
            unpaced_max_episodes = 0
            for row in subset:
                n, tmax, _ = measurement(row, pacing)
                paced_max = optional_number(row, 'episode_max_paced_ms')
                unpaced_max = optional_number(row, 'episode_max_unpaced_ms')
                if paced_max is None and unpaced_max is None:
                    raise ValueError(f"Maximum sans origine PHY: {condition}/{pacing}/{run}")
                candidate_max = max(x for x in (paced_max, unpaced_max)
                                    if x is not None)
                if abs(tmax - candidate_max) > 1e-6:
                    raise ValueError(f"Maximum et origines discordants: {condition}/{pacing}/{run}")
                if paced_max is not None and unpaced_max is not None and (
                        abs(paced_max - unpaced_max) <= 1e-6):
                    origin = 'tie'
                elif unpaced_max is not None and (
                        paced_max is None or unpaced_max > paced_max):
                    origin = 'unpaced'
                else:
                    origin = 'paced'
                if origin in ('unpaced', 'tie'):
                    unpaced_max_episodes += 1
                    maxima_unpaced += 1
                maxima_total += 1
                pure_episodes += int(row['episode_pure_pacing'])
                unpaced_samples += int(row['unpaced_recovery_samples'])
                predicted = (n - 1) * pacing + c_ms
                err = tmax - predicted
                depths.append(n)
                tmaxes.append(tmax)
                predictions.append(predicted)
                errors.append(err)
                per_episode.append(dict(condition=condition, pacing_ms=pacing,
                                        run=run, episode_index=row['episode_index'],
                                        depth=n, tmax_ms=tmax,
                                        prediction_ms=predicted, error_ms=err,
                                        paced_max_ms=paced_max if paced_max is not None else '',
                                        unpaced_max_ms=unpaced_max if unpaced_max is not None else '',
                                        max_origin=origin,
                                        unpaced_recovery_samples=row['unpaced_recovery_samples'],
                                        unpaced_original_samples=row['unpaced_original_samples'],
                                        unpaced_retransmission_samples=row['unpaced_retransmission_samples'],
                                        episode_pure_pacing=row['episode_pure_pacing']))
            result = dict(condition=condition, pacing_ms=pacing, run=run,
                          episodes=len(subset), depth_mean=statistics.mean(depths),
                          depth_min=min(depths), depth_max=max(depths),
                          pure_pacing_episodes=pure_episodes,
                          unpaced_recovery_share=unpaced_samples / sum(depths),
                          unpaced_max_episodes=unpaced_max_episodes,
                          tmax_mean_ms=statistics.mean(tmaxes),
                          prediction_mean_ms=statistics.mean(predictions),
                          error_mean_ms=statistics.mean(errors),
                          mae_episode_ms=statistics.mean(map(abs, errors)))
            per_run.append(result)
            current_runs.append(result)
        summary.append(dict(condition=condition, offDur_s=off, interval_s=interval,
                            pacing_ms=pacing, complete_runs=len(current_runs),
                            pure_pacing_episodes=sum(r['pure_pacing_episodes']
                                                     for r in current_runs),
                            unpaced_recovery_share=(
                                statistics.mean(r['unpaced_recovery_share']
                                                for r in current_runs)
                                if current_runs else ''),
                            unpaced_max_episodes=sum(r['unpaced_max_episodes']
                                                       for r in current_runs),
                            depth_mean=(statistics.mean(r['depth_mean'] for r in current_runs)
                                        if current_runs else ''),
                            tmax_mean_ms=(statistics.mean(r['tmax_mean_ms'] for r in current_runs)
                                          if current_runs else ''),
                            error_mean_ms=(statistics.mean(r['error_mean_ms'] for r in current_runs)
                                           if current_runs else ''),
                            mae_episode_ms=(statistics.mean(r['mae_episode_ms'] for r in current_runs)
                                            if current_runs else '')))
write_csv('validation-par-episode.csv',
          ('condition', 'pacing_ms', 'run', 'episode_index', 'depth',
           'tmax_ms', 'prediction_ms', 'error_ms', 'paced_max_ms',
           'unpaced_max_ms', 'max_origin', 'unpaced_recovery_samples',
           'unpaced_original_samples', 'unpaced_retransmission_samples',
           'episode_pure_pacing'), per_episode)
write_csv('validation-par-run.csv', out_columns, per_run)
write_csv('synthese-episodes.csv', tuple(summary[0]), summary)
(folder / 'qualite-episodes.txt').write_text(
    f"c ajustee sur B seulement (mediane des residus moyens par run): {c_ms:.3f} ms\n"
    f"Observations B (run x cadence) utilisees: {len(calibration)}/{3*runs}\n"
    "A/C: validation sur d'autres accumulations. D: sensibilite au debit.\n"
    f"Maximum hors file cadencee: {maxima_unpaced}/{maxima_total} episodes VTP1 complets.\n"
    "La concordance numerique des residus ne prouve pas a elle seule une loi"
    " de vidange pure lorsque des reprises non cadencees contribuent au maximum.\n"
    f"Alertes: {len(quality)}\n" + "\n".join(quality) + "\n",
    encoding='utf-8')
print(f"c(B) = {c_ms:.3f} ms; calibration: {len(calibration)}/{3*runs} couples run-cadence.")
print("Condition, cadence, runs complets, N moyen, origine non cadencee du max, erreur, MAE:")
for row in summary:
    if row['complete_runs']:
        print(f"{row['condition']:>3} {row['pacing_ms']:>2}ms "
              f"{row['complete_runs']}/{runs} N={row['depth_mean']:.1f} "
              f"max_hors_file={row['unpaced_max_episodes']}/{5*row['complete_runs']} "
              f"erreur={row['error_mean_ms']:.1f}ms "
              f"MAE={row['mae_episode_ms']:.1f}ms")
    else:
        print(f"{row['condition']:>3} {row['pacing_ms']:>2}ms 0/{runs} runs complets")
print(f"Details: {folder}/synthese-episodes.csv, validation-par-run.csv, "
      "validation-par-episode.csv, qualite-episodes.txt")
if any(('VTP1/' in item) for item in quality):
    raise SystemExit("Episodes VTP1 incomplets: evaluation partielle; voir qualite-episodes.txt.")
PY_EPI

# Correctif d’installation v4.6.3
> **Compatibilité Python** — l’installateur v4.6.3 évite `Path.write_text(newline=...)` et fonctionne avec les versions Python plus anciennes couramment présentes avec ns-3.35.


La v4.6.3 remplace le patch contextuel de `dsr-rcache.cc` par un installateur idempotent fondé sur les symboles. Pour réparer une installation v4.6.1 interrompue, exécuter `repair-peekroute-v4.6.3.sh`. Voir `README-REPAIR-V4.6.3.md`.

# VTP/DSR v4.6.3 — installation robuste pour ns-3.35

## Correctif v4.6.3 — installation robuste

`DsrRouting::PeekRoute()` dépend de `DsrRouteCache::PeekRoute()`. Copier uniquement
`dsr-routing.cc/.h` et le scénario provoque l’erreur de compilation « DsrRouteCache
has no member named PeekRoute ». Utiliser `apply-v4.6.3.sh`, qui installe aussi la méthode du cache par recherche de symboles stables et vérifie les quatre déclarations/définitions avant de lancer le build. Pour réparer une installation v4.6 déjà copiée, utiliser `repair-peekroute-v4.6.3.sh`.


Ce paquet compare les politiques **TRAD**, **VTP1** et **VTP2** avec un transport SCTP-like construit sur UDP et DSR instrumenté. Il conserve les corrections v4.4/v4.5 et intègre les corrections issues de l'audit complet.

## Contenu

- `vtp-dsr-comparison.cc` : scénario principal ;
- `dsr-routing.cc`, `dsr-routing.h` : DSR avec traces exactes et accès `PeekRoute()` ;
- `install-peekroute-v4.6.3.py` : installation idempotente et non contextuelle de `PeekRoute` ;
- `apply-v4.6.3.sh` : installation, sauvegarde et compilation ;
- `run-vtp-dsr-experiments.sh` : lanceur générique reprenable ;
- `run-vtp-dsr-presets.sh` : campagnes prédéfinies ;
- `outage-phases-30.csv` : table immuable des 30 phases nominales ;
- `analyze-vtp-results.py` : analyse descriptive, appariée et validation stricte ;
- `patches/` : différences par rapport aux fichiers v4.5 audités ;
- `VALIDATION.txt` et `SHA256SUMS.txt`.

## 1. Installation

Depuis la racine de ns-3.35 :

```bash
/path/vtp-dsr-full-independent-v4.6.3/apply-v4.6.3.sh "$(pwd)"
```

Le script :

1. sauvegarde les fichiers DSR et le scénario existant ;
2. installe `PeekRoute()` dans `dsr-rcache.h/.cc` sans dépendre des numéros de ligne ;
3. installe `dsr-routing.h/.cc` et `scratch/vtp-dsr-comparison.cc` ;
4. lance `./waf clean && ./waf build`, ou l'équivalent `./ns3`.

Installation sans compilation :

```bash
NO_BUILD=1 /path/vtp-dsr-full-independent-v4.6.3/apply-v4.6.3.sh "$(pwd)"
```

## 2. Signal de route non mutateur

La v4.5 utilisait périodiquement `LookupRoute()`. Dans ns-3.35, cette fonction peut purger le cache, reconstruire des données du cache de liens et insérer une sous-route. La branche v4.6 utilise :

```cpp
DsrRouting::PeekRoute(destination, entry)
```

`PeekRoute()` :

- ne purge aucune entrée ;
- ne reconstruit aucune table ;
- n'insère aucune sous-route ;
- rejette les entrées expirées ;
- vérifie la stabilité positive de chaque lien lorsqu'un LinkCache est utilisé.

Le forwarding DSR continue d'utiliser `LookupRoute()` normalement. Le nouveau mécanisme sert uniquement à l'observation cross-layer de `P(t)`.

## 3. Comptage PHY exact

Les événements `PhyTxBegin` sont dédupliqués globalement par :

```text
(sequence, attemptId)
```

Le comptage reste donc correct lorsque :

- plusieurs retries MAC correspondent à la même tentative transport ;
- une copie atteint tardivement le PHY après retrait du chunk de `m_pending`.

Colonnes :

```text
phy_original_attempts
phy_retrans_attempts
phy_late_attempts
```

## 4. Calendrier des outages

Le C++ reçoit explicitement :

```text
--outStart
--outagePhase
--onDur
--offDur
--cycles
```

Le lanceur applique par défaut :

```bash
OUTAGE_PHASE_MODE=balanced
OUTAGE_PHASE_BINS=30
OUTAGE_PHASE_SPAN=30.0
```

La phase du run `r` dépend d'une classe fixe parmi 30, jamais du nombre de runs effectivement lancés. Les runs 1 à 11 d'une campagne peuvent donc être prolongés jusqu'au run 30 sans changer leurs phases.

Les presets combinés utilisent directement la table immuable fournie :

```text
outage-phases-30.csv
```

Une autre table externe immuable peut aussi être utilisée :

```bash
OUTAGE_PHASE_TABLE=phases.csv
```

Format :

```csv
run,outage_phase_s
1,0.5
2,1.5
```

## 5. Reprise d'une campagne

Le lanceur ne supprime plus les résultats par défaut :

```bash
RESET_RESULTS=0
SKIP_EXISTING=1
```

Exemple pour reprendre les runs 13 à 30 :

```bash
PROFILE=full-independent \
RUNS=30 RUN_START=13 RUN_END=30 \
SPEEDS="20" RECOVERY_PACING=0.005 \
OUTAGE_PHASE_TABLE=/path/outage-phases-30.csv \
OUT=vtp-v4.6.1-combined-30-20.csv \
CAMPAIGN_ID=vtp-v4.6.1-combined-30-20 \
RESET_RESULTS=0 SKIP_EXISTING=1 \
/path/run-vtp-dsr-experiments.sh
```

Le lanceur refuse d'ajouter des lignes v4.6.1 à un ancien CSV sans `schema_version`.

## 6. Métadonnées du CSV

Le schéma v4.6.1 exporte notamment :

```text
schema_version
campaign_id
configuration_hash
outage_schedule_hash
rng_seed
rng_run
route_cache_probe_mode
```

Il exporte également les paramètres de topologie, mobilité, trafic, RTO, durée de vie, pacing, calendrier et diagnostic. `configuration_hash` exclut uniquement la politique, le numéro de run et la phase propre au run.

## 7. Diagnostic topologique

Le diagnostic reste désactivé par défaut :

```bash
GRAPH_PATH_DIAGNOSTIC=0
```

Lorsqu'il est activé, le CSV contient deux matrices de confusion :

1. cache instantané non mutateur contre graphe de portée ;
2. signal `P(t)` effectivement conservé par VTP2 contre graphe de portée.

Colonnes principales :

```text
cache_graph_tp, cache_graph_tn, cache_graph_fp, cache_graph_fn
policy_graph_tp, policy_graph_tn, policy_graph_fp, policy_graph_fn
```

Les colonnes `*_false_positive_fraction` et `*_false_negative_fraction` sont des parts de tous les échantillons. Les colonnes `*_false_positive_rate` et `*_false_negative_rate` sont les taux conditionnels usuels.

Le graphe indique seulement la connectivité géométrique du modèle de portée. Il ne représente ni la contention, ni les collisions, ni la réussite MAC et n'est jamais utilisé comme oracle par VTP2.

La fenêtre du diagnostic est maintenant exactement :

```text
app_start_s → generation_stop_s
```

comme les statistiques topologiques utilisées dans le modèle analytique.

## 8. Traces DSR exactes

Les traces utilisent la clé :

```text
(source, destination, requestId)
```

Traces :

```text
RreqInit
RouteDiscoveryCompleted
RouteDiscoveryFailed
RreqTimerArmed
RreqTimeout
```

Les épisodes ouverts à la fin de la fenêtre d'observation sont censurés. Les timers RREQ satisfont l'identité :

```text
armed = expired_exact + cancelled + incomplete
```

avec :

```text
rreq_timer_balance_delta = 0
```

## 9. Invariants obligatoires

Pour chaque ligne v4.6.1 :

```text
conservation_delta = 0
rto_balance_delta = 0
bad_channel_split_delta = 0
no_route_split_delta = 0
original_state_balance_delta = 0
retransmission_state_balance_delta = 0
rreq_timer_balance_delta = 0
cache_graph_balance_delta = 0
policy_graph_balance_delta = 0
rreq_timer_match_misses = 0
discovery_completion_match_misses = 0
pending_end = 0
socket_errors = 0
```

Pour chaque graine et configuration, l'analyse exige exactement un triplet TRAD/VTP1/VTP2 avec la même phase, le même `outage_schedule_hash` et le même `rng_run`.

## 10. Analyse statistique

```bash
python3 analyze-vtp-results.py \
  --input vtp-v4.6.1-combined-30-20.csv \
  --output-dir analysis-v4.6.1-20mps
```

La validation stricte est active par défaut et bloque les statistiques si les invariants ou l'appariement sont invalides.

Mode exploratoire pour un ancien fichier ou un test à une seule politique :

```bash
python3 analyze-vtp-results.py --input ancien.csv --output-dir exploration --no-strict
```

Sorties :

```text
vtp-dsr-summary.csv
vtp-dsr-paired-values.csv
vtp-dsr-paired-statistics.csv
vtp-dsr-mcnemar.csv
vtp-dsr-model-paired.csv
vtp-dsr-statistical-report.md
```

Méthodes :

- Wilcoxon bilatéral exact par distribution des signes et mid-ranks ;
- Hodges–Lehmann ;
- bootstrap apparié ;
- McNemar exact ;
- Holm global par configuration par défaut : quatre métriques primaires × trois contrastes.

Portée de Holm alternative :

```bash
--holm-scope contrast
```

Les résumés incluent moyenne, médiane, écart-type, min, quartiles, p90, p95, max et demi-largeur de l'intervalle de Student à 95 %.

Crises par défaut :

```text
PDR < 99 %
expired > 20
penalized_delay_ms > 2000
retransmissions > 900
route_mean_outage_ms > 10000
```

## 11. Campagne nominale

Le pacing nominal reste :

```text
recoveryPacing = 0.005 s
```

Lancement conseillé :

```bash
/path/run-vtp-dsr-presets.sh combined-30-20
```

Puis :

```bash
python3 analyze-vtp-results.py \
  --input vtp-v4.6.1-combined-30-20.csv \
  --output-dir analysis-v4.6.1-combined-30-20
```

## 12. Validation locale du paquet

```bash
python3 validate-package.py
```

Ce contrôle valide la syntaxe Python/Bash, l'équilibre des colonnes CSV, les fonctions statistiques et une analyse synthétique v4.6.1. La compilation réelle doit être confirmée dans votre installation ns-3.35.

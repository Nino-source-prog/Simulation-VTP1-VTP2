# Changelog v4.6.3

- Correction de l'installateur `PeekRoute` pour Python 3.7, 3.8 et 3.9.
- Remplacement de `Path.write_text(..., newline="")`, non pris en charge par
  ces versions, par une écriture atomique via `Path.open()` et `os.replace()`.
- Conservation des permissions du fichier source lors du remplacement.
- Nettoyage garanti du fichier temporaire en cas d'erreur.
- Scripts `apply` et `repair` renommés et synchronisés avec la v4.6.3.

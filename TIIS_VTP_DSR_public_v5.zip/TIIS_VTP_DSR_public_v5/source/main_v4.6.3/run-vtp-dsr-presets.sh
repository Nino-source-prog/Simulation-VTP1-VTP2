#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUNNER_SCRIPT="${HERE}/run-vtp-dsr-experiments.sh"
PRESET="${1:-}"

case "$PRESET" in
  static-control)
    PROFILE=static-on RUNS=5 RUN_START=1 RUN_END=5 SPEEDS="0" \
      RECOVERY_PACING=0.005 OUT=vtp-v4.6.1-static-control.csv \
      CAMPAIGN_ID=vtp-v4.6.1-static-control RESET_RESULTS=1 "$RUNNER_SCRIPT"
    ;;
  route-only-10)
    PROFILE=mobility-route RUNS=10 RUN_START=1 RUN_END=10 \
      SPEEDS="2 5 10 15 20" RECOVERY_PACING=0.005 \
      OUT=vtp-v4.6.1-route-only-10.csv CAMPAIGN_ID=vtp-v4.6.1-route-only-10 \
      RESET_RESULTS=1 "$RUNNER_SCRIPT"
    ;;
  route-only-30)
    PROFILE=mobility-route RUNS=30 RUN_START=1 RUN_END=30 SPEEDS="20" \
      RECOVERY_PACING=0.005 OUT=vtp-v4.6.1-route-only-30.csv \
      CAMPAIGN_ID=vtp-v4.6.1-route-only-30 RESET_RESULTS=1 "$RUNNER_SCRIPT"
    ;;
  combined-11-20)
    PROFILE=full-independent RUNS=30 RUN_START=1 RUN_END=11 SPEEDS="20" \
      RECOVERY_PACING=0.005 OUTAGE_PHASE_TABLE="${HERE}/outage-phases-30.csv" OUT=vtp-v4.6.1-combined-30-20.csv \
      CAMPAIGN_ID=vtp-v4.6.1-combined-30-20 RESET_RESULTS=1 "$RUNNER_SCRIPT"
    ;;
  combined-resume-12-30)
    PROFILE=full-independent RUNS=30 RUN_START=12 RUN_END=30 SPEEDS="20" \
      RECOVERY_PACING=0.005 OUTAGE_PHASE_TABLE="${HERE}/outage-phases-30.csv" OUT=vtp-v4.6.1-combined-30-20.csv \
      CAMPAIGN_ID=vtp-v4.6.1-combined-30-20 RESET_RESULTS=0 SKIP_EXISTING=1 \
      "$RUNNER_SCRIPT"
    ;;
  combined-30-20)
    PROFILE=full-independent RUNS=30 RUN_START=1 RUN_END=30 SPEEDS="20" \
      RECOVERY_PACING=0.005 OUTAGE_PHASE_TABLE="${HERE}/outage-phases-30.csv" OUT=vtp-v4.6.1-combined-30-20.csv \
      CAMPAIGN_ID=vtp-v4.6.1-combined-30-20 RESET_RESULTS=1 "$RUNNER_SCRIPT"
    ;;
  combined-30-5)
    PROFILE=full-independent RUNS=30 RUN_START=1 RUN_END=30 SPEEDS="5" \
      RECOVERY_PACING=0.005 OUTAGE_PHASE_TABLE="${HERE}/outage-phases-30.csv" OUT=vtp-v4.6.1-combined-30-5.csv \
      CAMPAIGN_ID=vtp-v4.6.1-combined-30-5 RESET_RESULTS=1 "$RUNNER_SCRIPT"
    ;;
  graph-diagnostic-20)
    PROFILE=full-independent RUNS=5 RUN_START=1 RUN_END=5 SPEEDS="20" \
      RECOVERY_PACING=0.005 GRAPH_PATH_DIAGNOSTIC=1 GRAPH_POLL=0.10 \
      OUTAGE_PHASE_TABLE="${HERE}/outage-phases-30.csv" \
      OUT=vtp-v4.6.1-graph-diagnostic-20.csv \
      CAMPAIGN_ID=vtp-v4.6.1-graph-diagnostic-20 RESET_RESULTS=1 "$RUNNER_SCRIPT"
    ;;
  pacing-calibration)
    output="vtp-v4.6.1-pacing-calibration.csv"
    first=1
    for pacing in 0.005 0.010 0.020 0.050; do
      PROFILE=full-independent RUNS=10 RUN_START=1 RUN_END=10 SPEEDS="20" \
        RECOVERY_PACING="$pacing" OUTAGE_PHASE_TABLE="${HERE}/outage-phases-30.csv" OUT="$output" \
        CAMPAIGN_ID=vtp-v4.6.1-pacing-calibration RESET_RESULTS="$first" \
        SKIP_EXISTING=1 "$RUNNER_SCRIPT"
      first=0
    done
    ;;
  *)
    echo "Usage: $0 {static-control|route-only-10|route-only-30|combined-11-20|combined-resume-12-30|combined-30-20|combined-30-5|pacing-calibration|graph-diagnostic-20}" >&2
    exit 2
    ;;
esac

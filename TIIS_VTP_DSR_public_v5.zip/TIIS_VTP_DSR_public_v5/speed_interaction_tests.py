#!/usr/bin/env python3
"""Speed effect and policy x speed interaction tests of Section 5.2.

Speed effect: Friedman test, runs as blocks, five speeds as treatments, on the
values averaged over TRAD, VTP1 and VTP2 within each run; Holm over 4 metrics.
Interaction: for each contrast, Friedman test of the paired differences across
the five speeds, runs as blocks; Holm over the 12 interaction tests.
Run from the archive root: python3 speed_interaction_tests.py
"""
import csv
from pathlib import Path
import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data/energy/tiis-energy-wifi-v1/main.csv"
SPEEDS = [0, 5, 10, 15, 20]
RUNS = range(1, 31)
METRICS = {"first PHY retransmissions": "phy_retrans_attempts", "jitter": "jitter_ms",
           "end-to-end delay": "e2e_delay_ms", "network energy": "network_energy_j"}
CONTRASTS = [("VTP1", "TRAD"), ("VTP2", "TRAD"), ("VTP2", "VTP1")]


def holm(p):
    order = np.argsort(p); m = len(p); out = [0.0] * m; running = 0.0
    for i, idx in enumerate(order):
        running = max(running, (m - i) * p[idx]); out[idx] = min(1.0, running)
    return out


def main():
    value = {}
    for r in csv.DictReader(DATA.open(newline="")):
        value[(r["policy"], int(float(r["speed"])), int(r["run"]))] = r
    get = lambda p, s, n, c: float(value[(p, s, n)][c])
    raw = [stats.friedmanchisquare(*np.array(
        [[np.mean([get(p, s, n, c) for p in ("TRAD", "VTP1", "VTP2")]) for s in SPEEDS] for n in RUNS]).T).pvalue
        for c in METRICS.values()]
    print("Speed effect (Friedman, runs as blocks; Holm over 4 metrics)")
    for name, p, h in zip(METRICS, raw, holm(raw)):
        print(f"  {name:28s} p = {p:.3g}   p_Holm = {h:.3g}")
    keys, raw = [], []
    for name, c in METRICS.items():
        for a, b in CONTRASTS:
            x = np.array([[get(a, s, n, c) - get(b, s, n, c) for s in SPEEDS] for n in RUNS])
            keys.append((name, f"{a}-{b}")); raw.append(stats.friedmanchisquare(*x.T).pvalue)
    print("Policy x speed interaction (Friedman on paired differences; Holm over 12 tests)")
    for (name, con), p, h in zip(keys, raw, holm(raw)):
        print(f"  {name:28s} {con:10s} p = {p:.3g}   p_Holm = {h:.3g}")


if __name__ == "__main__":
    main()

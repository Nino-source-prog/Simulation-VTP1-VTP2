#!/usr/bin/env python3
"""Create machine-readable results behind manuscript Tables 4–11.

Table 4 uses static condition B, independent run 1, and the conditional
calendar model. Table 5 reduces the individual static episode records.
Table 7 reuses the exact Wilcoxon/Hodges–Lehmann routines in
source/main_v4.6.3/analyze-vtp-results.py. Values are unrounded.
"""

import argparse
import csv
import importlib.util
import itertools
import math
import random
import statistics
import sys
from collections import defaultdict
from pathlib import Path

from scipy.stats import t
from model import timed_prediction

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reproduced/tables"
POLICIES = ("TRAD", "VTP1", "VTP2")
SPEEDS = (0, 5, 10, 15, 20)


def load(path):
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


def emit(name, rows):
    if not rows:
        raise ValueError(name)
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / name).open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(OUT / name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--d0-ms", type=float, default=0.681257827,
                        help="External no-gate calibration; raw run absent")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    table4 = []
    for pace, policy in ((5, "TRAD"), (5, "VTP1"), (10, "VTP1"),
                         (20, "VTP1")):
        run = next(r for r in load(ROOT / "data/static_episode" /
                                  f"run-B-pac{pace}ms.csv")
                   if r["policy"] == policy and int(r["run"]) == 1)
        model = timed_prediction(run, args.d0_ms)
        assert int(run["tx_retrans_submissions"]) == model["timed_tx_retrans"]
        assert int(run["phy_retrans_attempts"]) == model["timed_phy_retrans"]
        table4.append({
            "policy": policy, "T_ms": "" if policy == "TRAD" else pace,
            "tx_retrans_submissions_observed": run["tx_retrans_submissions"],
            "tx_retrans_submissions_model": model["timed_tx_retrans"],
            "first_phy_retx_observed": run["phy_retrans_attempts"],
            "first_phy_retx_model": model["timed_phy_retrans"],
            "delivered_delay_ms_observed": run["e2e_delay_ms"],
            "delivered_delay_ms_model": model["timed_delay_ms_plus_d0"],
            "jitter_ms_observed": run["jitter_ms"],
            "jitter_ms_model": model["timed_jitter_ms"],
            "Lmax_ms_observed": "" if policy == "TRAD" else
                                 run["recovery_latency_max_ms"],
            "Lmax_ms_model": "" if policy == "TRAD" else
                              model["timed_recovery_max_ms"],
            "d0_ms_external": args.d0_ms,
        })
    emit("Table_4.csv", table4)

    table5 = []
    for case in "ABCD":
        for pace in (5, 10, 20):
            episodes = load(ROOT / "data/static_episode" /
                            f"episodes-{case}-pac{pace}ms.csv")
            by_policy = {p: [r for r in episodes if r["policy"] == p]
                         for p in ("VTP1", "VTP2")}
            assert all(len(v) == 50 for v in by_policy.values())
            assert all(r["episode_valid"] == "1" for r in episodes)
            values = {}
            for policy, rows in by_policy.items():
                values[policy] = (
                    statistics.mean(float(r["queue_depth_at_release"])
                                    for r in rows),
                    statistics.mean(float(r["episode_max_paced_ms"])
                                    for r in rows),
                    statistics.mean(float(r["episode_max_recovery_ms"])
                                    for r in rows),
                    100 * sum(int(r["unpaced_recovery_samples"]) for r in rows)
                    / sum(int(r["episode_recovery_samples"]) for r in rows),
                )
            assert values["VTP1"] == values["VTP2"], (case, pace)
            n, paced, overall, share = values["VTP1"]
            reference = next(r for r in load(ROOT / "data/static_episode" /
                                            f"run-{case}-pac{pace}ms.csv")
                             if r["policy"] == "VTP1" and int(r["run"]) == 1)
            model = timed_prediction(reference, d0_ms=0.0)
            paced_model = (n-1)*pace + .051
            overall_model = model["timed_recovery_max_ms"]
            share_model = (100 * model["timed_without_first_phy"] /
                           (n * int(reference["channel_outages"])))
            assert math.isclose(paced, paced_model, abs_tol=1e-6)
            assert math.isclose(overall, overall_model, abs_tol=1e-6)
            assert math.isclose(share, share_model, abs_tol=1e-6)
            table5.append({"condition": case,
                           "D_s": reference["outage_off_duration_s"],
                           "rate_pps": 1/float(reference["generation_interval_s"]),
                           "N": n, "T_ms": pace,
                           "paced_max_ms": paced,
                           "paced_max_model_ms": paced_model,
                           "overall_max_ms": overall,
                           "overall_max_model_ms": overall_model,
                           "other_phy_pct": share,
                           "other_phy_pct_model": share_model,
                           "runs_per_policy": 10, "episodes_per_policy": 50})
    emit("Table_5.csv", table5)

    main_rows = load(ROOT / "data/energy/tiis-energy-wifi-v1/main.csv")
    assert len(main_rows) == 450
    by_key = {(int(float(r["speed"])), int(r["run"]), r["policy"]): r
              for r in main_rows}
    assert len(by_key) == 450
    metrics = {"pdr_pct": "PDR_pct", "phy_retrans_attempts": "PHY_retx",
               "e2e_delay_ms": "delay_ms", "jitter_ms": "jitter_ms",
               "energy_uj_per_delivered_bit": "energy_per_bit_uJ"}
    table6 = []
    for speed in SPEEDS:
        for policy in POLICIES:
            rows = [by_key[(speed, i, policy)] for i in range(1, 31)]
            table6.append({"speed_mps": speed, "policy": policy, **{
                name: statistics.median(float(r[k]) for r in rows)
                for k, name in metrics.items()}})
    emit("Table_6.csv", table6)

    analysis_path = ROOT / "source/main_v4.6.3/analyze-vtp-results.py"
    spec = importlib.util.spec_from_file_location("vtp_original_analysis", analysis_path)
    analysis = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = analysis
    spec.loader.exec_module(analysis)
    table7 = []
    for key, name in [("phy_retrans_attempts", "PHY_retx"),
                      ("jitter_ms", "jitter"), ("e2e_delay_ms", "delay"),
                      ("network_energy_j", "network_energy")]:
        for first, second in (("VTP1", "TRAD"), ("VTP2", "TRAD"),
                              ("VTP2", "VTP1")):
            differences = [statistics.mean(
                float(by_key[(s, run, first)][key]) -
                float(by_key[(s, run, second)][key]) for s in SPEEDS)
                for run in range(1, 31)]
            pvalue, nonzero, wplus = analysis.exact_wilcoxon_signed_rank(differences)
            table7.append({"metric": name, "contrast": f"{first}-{second}",
                           "independent_seed_trajectories": 30,
                           "hodges_lehmann": analysis.hodges_lehmann(differences),
                           "wilcoxon_exact_p": pvalue,
                           "nonzero_pairs": nonzero, "w_plus": wplus})
    adjusted = analysis.holm_adjust([r["wilcoxon_exact_p"] for r in table7])
    for row, value in zip(table7, adjusted):
        row["holm_adjusted_p"] = value
    emit("Table_7.csv", table7)

    table8 = []
    for key, name in [("phy_retrans_attempts", "PHY_retx"),
                      ("jitter_ms", "jitter"),
                      ("e2e_delay_ms", "delivered_delay"),
                      ("energy_uj_per_delivered_bit", "energy_per_bit")]:
        for speed in SPEEDS:
            for policy in ("VTP1", "VTP2"):
                vals = [100 * (float(by_key[(speed, i, "TRAD")][key]) -
                               float(by_key[(speed, i, policy)][key])) /
                        float(by_key[(speed, i, "TRAD")][key])
                        for i in range(1, 31)]
                avg = statistics.mean(vals)
                if key == "energy_uj_per_delivered_bit":
                    half = t.ppf(.975, 29)*statistics.stdev(vals)/math.sqrt(30)
                    lower, upper = avg-half, avg+half
                    method = "paired seed t"
                else:
                    rng = random.Random(12345 + 100*speed +
                                        (0 if policy == "VTP1" else 1))
                    boot = sorted(statistics.mean([vals[rng.randrange(30)]
                                                   for _ in vals]) for _ in range(10000))
                    lower, upper = boot[249], boot[9749]
                    method = "paired seed percentile bootstrap, 10000"
                table8.append({"metric": name, "speed_mps": speed,
                               "policy": policy, "paired_gain_mean_pct": avg,
                               "ci95_low_pct": lower, "ci95_high_pct": upper,
                               "method": method})
    emit("Table_8.csv", table8)

    phase_dir = ROOT / "data/phase"
    phase_rows = [r for p in sorted(phase_dir.glob("*.csv")) for r in load(p)]
    assert len(phase_rows) == 180
    by_phase = {(float(r["outage_phase_s"]), int(r["run"]), r["policy"]): r
                for r in phase_rows}
    assert len(by_phase) == 180
    phases = sorted({k[0] for k in by_phase})
    seeds = sorted({k[1] for k in by_phase})
    assert len(phases) == 12 and len(seeds) == 5
    table9 = []
    for phase in phases:
        means = {p: statistics.mean(float(by_phase[(phase, seed, p)]["pdr_pct"])
                                    for seed in seeds) for p in POLICIES}
        diffs = [float(by_phase[(phase, seed, "VTP2")]["pdr_pct"]) -
                 float(by_phase[(phase, seed, "VTP1")]["pdr_pct"])
                 for seed in seeds]
        bs = sorted(statistics.mean(diffs[i] for i in indexes)
                    for indexes in itertools.product(range(5), repeat=5))
        table9.append({"phase_s": phase, "TRAD_mean_PDR_pct": means["TRAD"],
                       "VTP1_mean_PDR_pct": means["VTP1"],
                       "VTP2_mean_PDR_pct": means["VTP2"],
                       "VTP2_minus_VTP1_pp": statistics.mean(diffs),
                       "ci95_low_pp": bs[math.floor(.025*(len(bs)-1))],
                       "ci95_high_pp": bs[math.ceil(.975*(len(bs)-1))],
                       "independent_seeds": 5})
    emit("Table_9.csv", table9)

    states = [("idle_s", "i_idle_a"), ("cca_busy_s", "i_cca_busy_a"),
              ("tx_s", "i_tx_a"), ("rx_s", "i_rx_a"),
              ("switching_s", "i_switching_a"),
              ("sleep_s", "i_sleep_a"), ("off_s", None)]
    summary = defaultdict(list)
    radio_dir = ROOT / "data/energy/tiis-energy-wifi-v1/radio"
    for p in POLICIES:
        summary[p] = load(radio_dir / f"full-independent-0.000000000-1-{p}.csv")
        assert len(summary[p]) == 50
    table10 = []
    for state, current in states:
        table10.append({"state": state, "current_A":
                        summary["TRAD"][0][current] if current else 0,
                        **{p + "_node_seconds": sum(float(r[state])
                                                    for r in summary[p])
                           for p in POLICIES}})
    table10.append({"state": "total_node_seconds", "current_A": "",
                    **{p + "_node_seconds":
                       sum(float(r[state]) for r in summary[p] for state, _ in states)
                       for p in POLICIES}})
    emit("Table_10.csv", table10)

    paired_energy = load(ROOT / "data/energy/tiis-energy-wifi-v1/analysis/paired_energy_by_speed.csv")
    table11 = []
    for r in paired_energy:
        if r["metric"] in ("network_energy_j", "energy_uj_per_delivered_bit"):
            table11.append({k: r[k] for k in
                            ("speed", "policy", "metric", "n_paired_seeds",
                             "paired_reduction_pct_mean", "reduction_pct_ci95_low",
                             "reduction_pct_ci95_high")})
    assert len(table11) == 20
    emit("Table_11.csv", table11)


if __name__ == "__main__":
    main()

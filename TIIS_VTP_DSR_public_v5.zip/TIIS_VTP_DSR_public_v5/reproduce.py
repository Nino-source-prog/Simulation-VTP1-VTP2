#!/usr/bin/env python3
"""Run the archived figure, table, timer-model and DSR analyses end to end."""

from __future__ import annotations

import csv
import hashlib
import math
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reproduced"


def run(*args: str) -> None:
    subprocess.run([sys.executable, str(ROOT / args[0]), *args[1:]],
                   check=True, cwd=ROOT)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_manifest() -> None:
    for line in (ROOT / "SHA256SUMS.txt").read_text().splitlines():
        expected, rel = line.split("  ", 1)
        actual = digest(ROOT / rel)
        if actual != expected:
            raise AssertionError(f"SHA-256 mismatch: {rel}")
    print("PASS: archived file SHA-256 manifest")


def check_series(name: str, expected: Path, actual: Path) -> None:
    fixed, new = rows(expected), rows(actual)
    assert len(fixed) == len(new), name
    for index, (a, b) in enumerate(zip(fixed, new)):
        assert a.keys() == b.keys(), (name, index, "columns")
        for key in a:
            try:
                x, y = float(a[key]), float(b[key])
            except ValueError:
                if a[key] != b[key]:
                    raise AssertionError((name, index, key, a[key], b[key]))
            else:
                if not (math.isclose(x, y, rel_tol=1e-9, abs_tol=1e-7)
                        or math.isnan(x) and math.isnan(y)):
                    raise AssertionError((name, index, key, a[key], b[key]))


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def main() -> None:
    verify_manifest()
    run("verify_archive.py")
    run("model.py", "--output", str(OUT / "model_validation.csv"))
    run("make_fig1.py", "--figure", str(OUT / "figures/Figure_1.png"),
        "--series", str(OUT / "figure1_series.csv"))
    run("make_tables.py")
    run("make_main_figures.py")
    energy = ROOT / "data/energy/tiis-energy-wifi-v1"
    run("source/TIIS_energy_campaign_ns3_35_v1/analyze_energy_campaign.py",
        "--data-dir", str(energy), "--reference",
        str(ROOT / "source/TIIS_energy_campaign_ns3_35_v1/reference/legacy-main-450.csv"),
        "--output-dir", str(OUT / "energy_analysis"))
    run("reproduce_static_arm0.py")

    check_series("model", ROOT / "derived/model_validation.csv",
                 OUT / "model_validation.csv")
    check_series("Figure 1", ROOT / "derived/figure1_series.csv",
                 OUT / "figure1_series.csv")
    check_series("Figures 2–7", ROOT / "derived/figure2to7_series.csv",
                 OUT / "figure2to7_series.csv")
    check_series("paired energy", energy / "analysis/paired_energy_by_speed.csv",
                 OUT / "energy_analysis/paired_energy_by_speed.csv")
    for n in range(4, 12):
        check_series(f"Table {n}", ROOT / "derived/tables" / f"Table_{n}.csv",
                     OUT / "tables" / f"Table_{n}.csv")
    b20 = next(r for r in rows(OUT / "tables/Table_4.csv")
               if r["policy"] == "VTP1" and r["T_ms"] == "20")
    assert b20["tx_retrans_submissions_observed"] == "590"
    assert b20["tx_retrans_submissions_model"] == "590"
    print("PASS: fixed numeric series reproduce within declared tolerance; "
          "Table 4 B/20 ms=590")


if __name__ == "__main__":
    main()

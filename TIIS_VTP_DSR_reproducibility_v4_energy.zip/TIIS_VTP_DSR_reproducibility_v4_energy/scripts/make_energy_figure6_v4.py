#!/usr/bin/env python3
"""Figure 6 for the 450-run corrected 3 V ns-3 radio profile."""

import csv
import math
import statistics
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import t as student_t

INPUT = Path("review_energy_full/tiis-energy-wifi-v1/main.csv")
OUTPUT = Path("Figure_6_energy_corrected_v4.png")

with INPUT.open(newline="") as handle:
    records = list(csv.DictReader(handle))

speeds = [0, 5, 10, 15, 20]
series = {}
for policy in ("TRAD", "VTP1", "VTP2"):
    means, halfwidths = [], []
    for speed in speeds:
        values = [float(row["energy_uj_per_delivered_bit"]) for row in records
                  if row["policy"] == policy and float(row["speed"]) == speed]
        assert len(values) == 30 and all(math.isfinite(x) for x in values)
        means.append(statistics.mean(values))
        halfwidths.append(student_t.ppf(.975, 29) * statistics.stdev(values) / math.sqrt(30))
    series[policy] = (means, halfwidths)

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                     "axes.spines.top": False, "axes.spines.right": False})
fig, ax = plt.subplots(figsize=(9, 5.6), dpi=220)
styling = {"TRAD": ("#1f77b4", "o", "-"),
           "VTP1": ("#e36d24", "s", "--"),
           "VTP2": ("#25804a", "^", ":")}
for policy in styling:
    color, marker, line = styling[policy]
    means, halfwidths = series[policy]
    ax.errorbar(speeds, means, yerr=halfwidths, label=policy, color=color,
                fmt=marker+line, linewidth=2, markersize=5.4, capsize=3)
ax.set(xlabel="Speed (m/s)",
       ylabel="Network energy per delivered payload bit (µJ/bit)",
       xlim=(-.7, 20.9), ylim=(1125, 1320), xticks=speeds)
ax.grid(alpha=.32, axis="y", linestyle="--")
ax.legend(title="Policy", frameon=True, loc="upper left")

# Give the reader a readable scale for typical results without suppressing
# the large dispersion caused by the severe run at 20 m/s.
inset = ax.inset_axes((.20, .15, .51, .42))
for policy in styling:
    color, marker, line = styling[policy]
    means, halfwidths = series[policy]
    inset.errorbar(speeds[:4], means[:4], yerr=halfwidths[:4],
                   color=color, fmt=marker+line, linewidth=1.2, markersize=3,
                   capsize=2)
inset.set(xlim=(-.4, 15.5), ylim=(1175, 1185), xticks=[0, 5, 10, 15])
inset.set_title("Detail: 0–15 m/s", fontsize=9)
inset.tick_params(labelsize=8)
inset.grid(alpha=.22, linestyle="--")
fig.text(.5, .01, "95% t confidence intervals over 30 independent runs per speed",
         ha="center", fontsize=9)
fig.subplots_adjust(bottom=.16, left=.16, right=.98, top=.96)
fig.savefig(OUTPUT)
print(OUTPUT)

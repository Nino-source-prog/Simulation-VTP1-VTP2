import csv,importlib.util,statistics,random,math,sys
from scipy.stats import friedmanchisquare
from pathlib import Path
p=Path('review_energy_full/tiis-energy-wifi-v1/main.csv')
with p.open() as f:rows=list(csv.DictReader(f))
row={(int(float(x['speed'])),int(x['run']),x['policy']):x for x in rows}
metrics=[('PHY retx','phy_retrans_attempts'),('Jitter (ms)','jitter_ms'),('E2E delay (ms)','e2e_delay_ms'),('Energy (J)','network_energy_j')]
sp=importlib.util.spec_from_file_location('v4_analysis','TIIS_VTP_DSR_reproducibility_v3/base_snapshot/source/main_v4.6.3/analyze-vtp-results.py')
a=importlib.util.module_from_spec(sp);sys.modules[sp.name]=a;sp.loader.exec_module(a)
contrasts=[('VTP1','TRAD'),('VTP2','TRAD'),('VTP2','VTP1')]
records=[]
for name,field in metrics:
 for first,second in contrasts:
  d=[statistics.mean(float(row[(s,run,first)][field])-float(row[(s,run,second)][field]) for s in (0,5,10,15,20)) for run in range(1,31)]
  pp,n,w=a.exact_wilcoxon_signed_rank(d)
  records.append((name,first,second,pp,a.hodges_lehmann(d),statistics.mean(d),min(d),max(d)))
holm=a.holm_adjust([r[3] for r in records])
print('MAIN POLICY: metric | contrast | p | Holm | HL | mean difference | min/max')
for x,padj in zip(records,holm):print(x[:3],f'{x[3]:.8g}',f'{padj:.8g}',f'{x[4]:.6g}',f'{x[5]:.6g}',f'{x[6]:.5g}/{x[7]:.5g}')
print('SPEED FRIEDMAN (policy-averaged per seed; Holm across 4)')
speeds=[]
for name,field in metrics:
 v=[[statistics.mean(float(row[(s,run,pol)][field]) for pol in ('TRAD','VTP1','VTP2')) for run in range(1,31)] for s in (0,5,10,15,20)]
 test=friedmanchisquare(*v)
 speeds.append((name,test.statistic,test.pvalue))
for x,padj in zip(speeds,a.holm_adjust([x[2] for x in speeds])):print(x,padj)
print('INTERACTION FRIEDMAN (paired contrast differences across speeds; Holm 12)')
inter=[]
for name,field in metrics:
 for first,second in contrasts:
  v=[[float(row[(s,run,first)][field])-float(row[(s,run,second)][field]) for run in range(1,31)] for s in (0,5,10,15,20)]
  test=friedmanchisquare(*v)
  inter.append((name,first,second,test.statistic,test.pvalue))
for x,padj in zip(inter,a.holm_adjust([x[4] for x in inter])):print(x,padj)
print('MEDIAN ENERGY/BIT BY SPEED')
for s in [0,5,10,15,20]:
 for pol in ['TRAD','VTP1','VTP2']:
  m=statistics.median(float(row[(s,i,pol)]['energy_uj_per_delivered_bit']) for i in range(1,31))
  print(s,pol,round(m,3))
print('BOOTSTRAP MEAN PAIRED ENERGY/BIT % 95%')
for s in [0,5,10,15,20]:
 for k,pol in enumerate(['VTP1','VTP2']):
  v=[100*(float(row[(s,i,'TRAD')]['energy_uj_per_delivered_bit'])-float(row[(s,i,pol)]['energy_uj_per_delivered_bit']))/float(row[(s,i,'TRAD')]['energy_uj_per_delivered_bit']) for i in range(1,31)]
  rng=random.Random(12345+100*s+k);n=len(v)
  boot=sorted(statistics.mean(v[rng.randrange(n)] for _ in v) for _ in range(10000))
  print(s,pol,'mean',round(statistics.mean(v),5),'CI',round(boot[249],5),round(boot[9749],5),'median',round(statistics.median(v),5))

# TIIS VTP–DSR supplementary evidence, energy correction v4

This fixed supplement preserves the earlier `TIIS_VTP_DSR_reproducibility_v3.zip`
unchanged and adds the coherent 3 V ns-3.35 Wi-Fi energy campaign.

| Item | Corresponding evidence |
|---|---|
| `source/TIIS_VTP_DSR_reproducibility_v3.zip` | Original 450-run non-energy metrics, 180-run phase experiment, 360 static queue-depth runs, Figures 1–5 and 7, DSR diagnostics; see its own README for claim-to-file mapping. Its old radio energies use a mixed and physically inconsistent current profile and must **not** be used to claim a 12–14% energy saving. |
| `source/TIIS_energy_campaign_ns3_35_v1.zip` | Complete audited instrumented ns-3.35 scenario variants, six explicitly fixed radio currents, launcher, per-node state-duration instrumentation, reference CSV and validation/paired-analysis code. |
| `data/tiis-energy-wifi-v1-complet.tar.gz` | 450 new main rows and 22,500 per-node state records, pinned configuration and DSR source fingerprints, and derived per-run and paired summaries for Table 6 (energy column), Table 7 (energy rows), Table 8 (energy rows), Table 10, Figure 6, Sections 4.2 and 5.6. |
| `figures/Figure_6.png` | Revised figure using the coherent-profile mean network energy per uniquely delivered payload bit and seed-level t intervals (30 independent runs per speed/policy). |
| `scripts/` | Plotting and cross-checking calculations used to prepare the revised manuscript; source paths in these scripts reflect the author's top-level extracted project tree. |

All 450 historical/new non-energy CSV fields (159 shared fields other than
schema/energy identification and energy outputs) match exactly. The setting is
the five-cycle externally imposed **receiver-application DATA acceptance gate**:
the radio and DSR remain on. Policies are compared on 30 matched RNG runs per
speed (0, 5, 10, 15 and 20 m/s); each run's gate phase is run − 0.5 s.

## Model and calculations

The 3 V radio currents in amperes are idle = CCA busy = switching = 0.273,
TX = 0.380, RX = 0.313 and sleep = 0.033. Off draws zero and was not entered.
The initial energy is 1000 J per node; no node depleted its source. The
50 × 300 s always-idle reference is 12,285 J. Because CCA busy and idle have
equal current, reductions in their durations cancel at fixed total time;
relative to this reference, only TX and RX contribute in these runs:

`E_state - 12285 J = 3 V × [0.107 A × D_TX + 0.040 A × D_RX]`.

The source-reported network total differs from state reweighting by at most
0.139 J per run; paired mean source/state effect differences are under
0.003 J for each speed/policy. Source-reported energy is the primary endpoint.
Delivered payload bits are exactly `rx_unique × 512 bytes × 8`; duplicates
are excluded. A policy may use fewer network joules while using more joules
per delivered bit if its delivery falls. In the 20 m/s run 8, TRAD/VTP1/VTP2
deliver 1219/2549/1481 packets respectively. Do not assign this outcome to a
particular DSR event from these aggregate energy records.

The old radio-current mixture (idle 0.0002 A, TX 0.0174 A, RX 0.0197 A,
CCA busy 0.273 A) generated the paper's previous 12–14% claim. These
same-new-trace legacy reweightings are diagnostic only; they are not a valid
new physical radio profile or an alternative efficacy claim. The coherent
profile yields approximately 0.02–0.03% less *total modeled network energy*
for VTP policies relative to TRAD. State durations and currents are available
for every run, not only the original static example. Values are ns-3 model
outputs; they are not calibrated to a specific physical 802.11b radio.

## Verify

Extract both new archives, then from their common parent directory run:

```bash
python3 TIIS_energy_campaign_ns3_35_v1/analyze_energy_campaign.py \
  --data-dir tiis-energy-wifi-v1 \
  --reference TIIS_energy_campaign_ns3_35_v1/reference/legacy-main-450.csv
```

The strict check (without `--allow-partial`) requires 450 matched runs, all
22,500 per-node rows, duration conservation, the six actual currents and 3 V,
reconstruction/source agreement, and parity in generated/delivered traffic,
first PHY attempts, submission and timer counters with the historical CSV.
Results are written under `tiis-energy-wifi-v1/analysis/`. The accompanying
`manifest.txt` pins the precise energy scenario and installed DSR `.cc` files.

`source/TIIS_VTP_DSR_reproducibility_v3.zip` carries the historical Figure 1
and Table 4 with their documented provenance limitations. None of the new
energy interpretation depends on the unmatched historical 94.1674 J datum.
The archive hash, rather than the repository landing page alone, identifies
the exact source/data revision. A public versioned release URL should be
associated with these same bytes for journal submission.
